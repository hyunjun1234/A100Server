import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void conv3d_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int D, int H, int W, int kernel_size) {
    int b = blockIdx.x / (out_channels * D * H * W);
    int oc = (blockIdx.x % (out_channels * D * H * W)) / (D * H * W);
    int d = ((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) / (H * W);
    int h = (((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) % (H * W)) / W;
    int w = (((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) % (H * W)) % W;

    if (b < batch_size && oc < out_channels && d < D && h < H && w < W) {
        float sum = 0.0f;
        for (int ic = 0; ic < in_channels; ++ic) {
            for (int kd = 0; kd < kernel_size; ++kd) {
                for (int kh = 0; kh < kernel_size; ++kh) {
                    for (int kw = 0; kw < kernel_size; ++kw) {
                        int di = d + kd - kernel_size / 2;
                        int hi = h + kh - kernel_size / 2;
                        int wi = w + kw - kernel_size / 2;
                        if (di >= 0 && di < D && hi >= 0 && hi < H && wi >= 0 && wi < W) {
                            int input_idx = b * in_channels * D * H * W + ic * D * H * W + di * H * W + hi * W + wi;
                            int weight_idx = oc * in_channels * kernel_size * kernel_size * kernel_size + ic * kernel_size * kernel_size * kernel_size + kd * kernel_size * kernel_size + kh * kernel_size + kw;
                            sum += input[input_idx] * weight[weight_idx];
                        }
                    }
                }
            }
        }
        int output_idx = b * out_channels * D * H * W + oc * D * H * W + d * H * W + h * W + w;
        output[output_idx] = sum;
    }
}

torch::Tensor conv3d_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int D, int H, int W, int kernel_size) {
    auto output = torch::zeros({batch_size, out_channels, D, H, W}, input.options());
    int threads = 256;
    int blocks = (batch_size * out_channels * D * H * W + threads - 1) / threads;
    conv3d_kernel<<<blocks, threads>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, out_channels, D, H, W, kernel_size);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, num_groups):
        super().__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size)
        self.group_norm = nn.GroupNorm(num_groups, out_channels)

    def forward(self, x):
        weight = self.conv.weight.view(-1)
        x = _get_mod().conv3d_cuda(x, weight, x.size(0), x.size(1), self.conv.out_channels, x.size(2), x.size(3), x.size(4), self.conv.kernel_size[0])
        x = self.group_norm(x)
        x = x.mean(dim=[1, 2, 3, 4])
        return x
