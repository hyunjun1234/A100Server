import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <math.h>

__global__ void rms_norm_kernel(const float* input, float* output, const float* weight, int batch_size, int num_features, int dim1, int dim2, float eps) {
    int b = blockIdx.x / (num_features * dim1 * dim2);
    int f = (blockIdx.x / (dim1 * dim2)) % num_features;
    int d1 = (blockIdx.x / dim2) % dim1;
    int d2 = blockIdx.x % dim2;

    int idx = b * num_features * dim1 * dim2 + f * dim1 * dim2 + d1 * dim2 + d2;
    float sum = 0.0f;
    for (int i = 0; i < batch_size; ++i) {
        float val = input[i * num_features * dim1 * dim2 + idx];
        sum += val * val;
    }
    float rms = sqrtf(sum / batch_size + eps);
    output[idx] = input[idx] / rms * weight[f];
}

torch::Tensor rms_norm_cuda(torch::Tensor input, torch::Tensor weight, int num_features, int dim1, int dim2, float eps) {
    auto output = torch::empty_like(input);
    int total_elements = input.numel();
    rms_norm_kernel<<<(total_elements + 255) / 256, 256>>>(
        input.data_ptr<float>(), output.data_ptr<float>(), weight.data_ptr<float>(), input.size(0), num_features, dim1, dim2, eps);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "rms_norm_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, num_features: int, eps: float = 1e-5):
        super(ModelNew, self).__init__()
        self.num_features = num_features
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(num_features))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _get_mod().rms_norm_cuda(x, self.weight, self.num_features, x.size(2), x.size(3), self.eps)
