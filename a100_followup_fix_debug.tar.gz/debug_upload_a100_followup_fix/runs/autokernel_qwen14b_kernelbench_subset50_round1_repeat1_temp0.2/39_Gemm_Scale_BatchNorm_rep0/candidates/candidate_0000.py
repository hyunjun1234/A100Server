import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void gemm_kernel(const float* input, const float* weight, float* output, int M, int N, int K) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += input[row * K + k] * weight[k * N + col];
        }
        output[row * N + col] = sum;
    }
}

__global__ void scale_kernel(const float* input, const float* scale, float* output, int M, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < M * N) {
        output[idx] = input[idx] * scale[idx % N];
    }
}

__global__ void bn_kernel(const float* input, float* output, float* running_mean, float* running_var, float* scale, float* bias, int M, int N, float eps) {
    extern __shared__ float shared[];
    int tid = threadIdx.x;
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float x = input[row * N + col];
        float mean = running_mean[col];
        float var = running_var[col];
        float norm = (x - mean) / sqrt(var + eps);
        output[row * N + col] = norm * scale[col] + bias[col];
    }
}

torch::Tensor gemm_cuda(torch::Tensor input, torch::Tensor weight, int M, int N, int K) {
    auto output = torch::empty({M, N}, input.options());
    gemm_kernel<<<(M + 15) / 16, (N + 15) / 16>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), M, N, K);
    return output;
}

torch::Tensor scale_cuda(torch::Tensor input, torch::Tensor scale, int M, int N) {
    auto output = torch::empty_like(input);
    scale_kernel<<<(M * N + 255) / 256, 256>>>(input.data_ptr<float>(), scale.data_ptr<float>(), output.data_ptr<float>(), M, N);
    return output;
}

torch::Tensor bn_cuda(torch::Tensor input, torch::Tensor running_mean, torch::Tensor running_var, torch::Tensor scale, torch::Tensor bias, int M, int N, float eps) {
    auto output = torch::empty_like(input);
    bn_kernel<<<(M * N + 255) / 256, 256, N * sizeof(float)>>>(input.data_ptr<float>(), output.data_ptr<float>(), running_mean.data_ptr<float>(), running_var.data_ptr<float>(), scale.data_ptr<float>(), bias.data_ptr<float>(), M, N, eps);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "gemm_cuda", "scale_cuda", "bn_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scale_shape, eps=1e-5, momentum=0.1):
        super(ModelNew, self).__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.scale = nn.Parameter(torch.randn(scale_shape))
        self.bn = nn.BatchNorm1d(out_features, eps=eps, momentum=momentum)

    def forward(self, x):
        M, K = x.size(0), x.size(1)
        N = self.gemm.weight.size(0)
        
        x = _get_mod().gemm_cuda(x, self.gemm.weight, M, N, K)
        x = _get_mod().scale_cuda(x, self.scale, M, N)
        x = _get_mod().bn_cuda(x, self.bn.running_mean, self.bn.running_var, self.bn.weight, self.bn.bias, M, N, self.bn.eps)
        
        return x
