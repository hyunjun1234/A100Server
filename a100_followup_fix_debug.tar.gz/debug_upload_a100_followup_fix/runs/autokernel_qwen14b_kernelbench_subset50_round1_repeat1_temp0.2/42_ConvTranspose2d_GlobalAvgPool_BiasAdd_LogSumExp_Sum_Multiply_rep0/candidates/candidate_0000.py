import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void conv_transpose_kernel(const float* input, float* output, const float* weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size) {
    int b = blockIdx.x / (out_channels * height);
    int c = (blockIdx.x % (out_channels * height)) / height;
    int h = (blockIdx.x % height);
    int w = threadIdx.x;

    if (b < batch_size && c < out_channels && h < height && w < width) {
        float sum = 0.0f;
        for (int ic = 0; ic < in_channels; ++ic) {
            for (int kh = 0; kh < kernel_size; ++kh) {
                for (int kw = 0; kw < kernel_size; ++kw) {
                    int ih = h + kh;
                    int iw = w + kw;
                    if (ih >= 0 && ih < height && iw >= 0 && iw < width) {
                        sum += input[b * in_channels * height * width + ic * height * width + ih * width + iw] *
                               weight[c * in_channels * kernel_size * kernel_size + ic * kernel_size * kernel_size + kh * kernel_size + kw];
                    }
                }
            }
        }
        output[b * out_channels * height * width + c * height * width + h * width + w] = sum;
    }
}

__global__ void global_avg_pool_kernel(const float* input, float* output, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x / out_channels;
    int c = blockIdx.x % out_channels;
    int h = threadIdx.x / width;
    int w = threadIdx.x % width;

    if (b < batch_size && c < out_channels && h < height && w < width) {
        float sum = 0.0f;
        for (int i = 0; i < height; ++i) {
            for (int j = 0; j < width; ++j) {
                sum += input[b * out_channels * height * width + c * height * width + i * width + j];
            }
        }
        output[b * out_channels + c] = sum / (height * width);
    }
}

__global__ void add_bias_kernel(const float* input, float* output, const float* bias, int batch_size, int out_channels) {
    int b = blockIdx.x / out_channels;
    int c = blockIdx.x % out_channels;

    if (b < batch_size && c < out_channels) {
        output[b * out_channels + c] = input[b * out_channels + c] + bias[c];
    }
}

__global__ void logsumexp_kernel(const float* input, float* output, int batch_size, int out_channels) {
    int b = blockIdx.x;
    int c = threadIdx.x;

    if (b < batch_size && c < out_channels) {
        float max_val = -INFINITY;
        for (int i = 0; i < out_channels; ++i) {
            max_val = fmaxf(max_val, input[b * out_channels + i]);
        }

        float sum = 0.0f;
        for (int i = 0; i < out_channels; ++i) {
            sum += expf(input[b * out_channels + i] - max_val);
        }

        output[b] = max_val + logf(sum);
    }
}

__global__ void sum_kernel(const float* input, float* output, int batch_size, int out_channels) {
    int b = blockIdx.x;
    int c = threadIdx.x;

    if (b < batch_size && c < out_channels) {
        float sum = 0.0f;
        for (int i = 0; i < out_channels; ++i) {
            sum += input[b * out_channels + i];
        }
        output[b] = sum;
    }
}

__global__ void multiply_kernel(float* input, float scalar, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        input[idx] *= scalar;
    }
}

torch::Tensor conv_transpose_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size) {
    auto output = torch::zeros({batch_size, out_channels, height, width}, input.options());
    conv_transpose_kernel<<<(batch_size * out_channels * height + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), weight.data_ptr<float>(), batch_size, in_channels, out_channels, height, width, kernel_size);
    return output;
}

torch::Tensor global_avg_pool_cuda(torch::Tensor input, int batch_size, int out_channels, int height, int width) {
    auto output = torch::zeros({batch_size, out_channels}, input.options());
    global_avg_pool_kernel<<<(batch_size * out_channels + 255) / 256, height * width>>>(input.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_channels, height, width);
    return output;
}

torch::Tensor add_bias_cuda(torch::Tensor input, torch::Tensor bias, int batch_size, int out_channels) {
    auto output = torch::zeros({batch_size, out_channels}, input.options());
    add_bias_kernel<<<(batch_size * out_channels + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), bias.data_ptr<float>(), batch_size, out_channels);
    return output;
}

torch::Tensor logsumexp_cuda(torch::Tensor input, int batch_size, int out_channels) {
    auto output = torch::zeros({batch_size}, input.options());
    logsumexp_kernel<<<batch_size, out_channels>>>(input.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_channels);
    return output;
}

torch::Tensor sum_cuda(torch::Tensor input, int batch_size, int out_channels) {
    auto output = torch::zeros({batch_size}, input.options());
    sum_kernel<<<batch_size, out_channels>>>(input.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_channels);
    return output;
}

void multiply_cuda(torch::Tensor input, float scalar) {
    multiply_kernel<<<(input.numel() + 255) / 256, 256>>>(input.data_ptr<float>(), scalar, input.numel());
}

"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose_cuda", "global_avg_pool_cuda", "add_bias_cuda", "logsumexp_cuda", "sum_cuda", "multiply_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape):
        super().__init__()
        self.conv_transpose_weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size, kernel_size))
        self.bias = nn.Parameter(torch.randn(bias_shape))

    def forward(self, x):
        mod = _get_mod()
        x = mod.conv_transpose_cuda(x, self.conv_transpose_weight, x.size(0), x.size(1), self.conv_transpose_weight.size(0), x.size(2), x.size(3), self.conv_transpose_weight.size(2))
        x = mod.global_avg_pool_cuda(x, x.size(0), self.conv_transpose_weight.size(0), x.size(2), x.size(3))
        x = mod.add_bias_cuda(x, self.bias, x.size(0), self.bias.size(0))
        x = mod.logsumexp_cuda(x, x.size(0), self.bias.size(0))
        x = mod.sum_cuda(x, x.size(0), self.bias.size(0))
        mod.multiply_cuda(x, 10.0)
        return x
