import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv3d_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int height, int width, int depth, int kernel_size, int stride, int padding, int dilation, int groups) {
    int b = blockIdx.x / (out_channels * (height + 2 * padding) / stride * (width + 2 * padding) / stride);
    int out_c = (blockIdx.x / ((height + 2 * padding) / stride * (width + 2 * padding) / stride)) % out_channels;
    int oh = (blockIdx.x / ((width + 2 * padding) / stride)) % (height + 2 * padding) / stride;
    int ow = blockIdx.x % (width + 2 * padding) / stride;

    if (b < batch_size && out_c < out_channels && oh < (height + 2 * padding) / stride && ow < (width + 2 * padding) / stride) {
        float sum = 0.0f;
        for (int g = 0; g < groups; ++g) {
            int in_c_start = g * in_channels / groups;
            int out_c_start = g * out_channels / groups;
            for (int kh = 0; kh < kernel_size; ++kh) {
                for (int kw = 0; kw < kernel_size; ++kw) {
                    for (int kd = 0; kd < 1; ++kd) {
                        int ih = oh * stride + kh * dilation - padding;
                        int iw = ow * stride + kw * dilation - padding;
                        int id = 0;
                        if (ih >= 0 && ih < height && iw >= 0 && iw < width && id >= 0 && id < depth) {
                            int input_idx = b * in_channels * height * width * depth + (in_c_start + (out_c - out_c_start) % (in_channels / groups)) * height * width * depth + ih * width * depth + iw * depth + id;
                            int weight_idx = out_c_start * in_channels / groups * kernel_size * kernel_size * 1 + (out_c - out_c_start) % (in_channels / groups) * kernel_size * kernel_size * 1 + kh * kernel_size * 1 + kw * 1 + kd;
                            sum += input[input_idx] * weight[weight_idx];
                        }
                    }
                }
            }
        }
        int output_idx = b * out_channels * (height + 2 * padding) / stride * (width + 2 * padding) / stride + out_c * (height + 2 * padding) / stride * (width + 2 * padding) / stride + oh * (width + 2 * padding) / stride + ow;
        output[output_idx] = sum;
    }
}

torch::Tensor conv3d_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int height, int width, int depth, int kernel_size, int stride, int padding, int dilation, int groups) {
    auto output = torch::zeros({batch_size, out_channels, (height + 2 * padding) / stride, (width + 2 * padding) / stride, 1});
    int num_blocks = batch_size * out_channels * (height + 2 * padding) / stride * (width + 2 * padding) / stride;
    conv3d_kernel<<<num_blocks, 1>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, out_channels, height, width, depth, kernel_size, stride, padding, dilation, groups);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv3d = nn.Conv3d(in_channels, out_channels, (kernel_size, kernel_size, 1), stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.weight = self.conv3d.weight
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, _, height, width, depth = x.size()
        return _get_mod().conv3d_cuda(x, self.weight, batch_size, self.in_channels, self.out_channels, height, width, depth, self.kernel_size, self.stride, self.padding, self.dilation, self.groups)
