import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv2d_kernel(
    const float* input, const float* weight, float* output,
    int batch_size, int in_channels, int out_channels, int height, int width,
    int kernel_size, int stride, int padding, int dilation, int groups) {
    
    int b = blockIdx.x / (out_channels * (height + 2 * padding) / stride);
    int oc = (blockIdx.x % (out_channels * (height + 2 * padding) / stride)) / ((height + 2 * padding) / stride);
    int oh = (blockIdx.x % (out_channels * (height + 2 * padding) / stride)) % ((height + 2 * padding) / stride);
    int ow = threadIdx.x;

    int ih = oh * stride - padding;
    int iw = ow * stride - padding;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kh = 0; kh < kernel_size; ++kh) {
            for (int kw = 0; kw < kernel_size; ++kw) {
                if (ih + kh * dilation >= 0 && ih + kh * dilation < height && iw + kw * dilation >= 0 && iw + kw * dilation < width) {
                    sum += input[b * in_channels * height * width + ic * height * width + (ih + kh * dilation) * width + (iw + kw * dilation)] *
                           weight[oc * in_channels * kernel_size * kernel_size + ic * kernel_size * kernel_size + kh * kernel_size + kw];
                }
            }
        }
    }

    output[b * out_channels * (height + 2 * padding) / stride * (width + 2 * padding) / stride + oc * (height + 2 * padding) / stride * (width + 2 * padding) / stride + oh * (width + 2 * padding) / stride + ow] = sum;
}

torch::Tensor conv2d_cuda(
    torch::Tensor input, torch::Tensor weight,
    int batch_size, int in_channels, int out_channels, int height, int width,
    int kernel_size, int stride, int padding, int dilation, int groups) {
    
    auto output = torch::zeros({batch_size, out_channels, (height + 2 * padding) / stride, (width + 2 * padding) / stride}, input.options());
    int threads = 256;
    int blocks = (batch_size * out_channels * (height + 2 * padding) / stride * (width + 2 * padding) / stride + threads - 1) / threads;
    conv2d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(),
        batch_size, in_channels, out_channels, height, width,
        kernel_size, stride, padding, dilation, groups);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv2d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv2d = nn.Conv2d(in_channels, out_channels, (kernel_size, kernel_size), stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv2d.weight
        bias = self.conv2d.bias if self.conv2d.bias is not None else torch.zeros(weight.size(0), device=x.device)
        batch_size, in_channels, height, width = x.size()
        kernel_size = weight.size(2)
        stride = self.conv2d.stride[0]
        padding = self.conv2d.padding[0]
        dilation = self.conv2d.dilation[0]
        groups = self.conv2d.groups
        
        output = _get_mod().conv2d_cuda(
            x, weight,
            batch_size, in_channels, out_channels, height, width,
            kernel_size, stride, padding, dilation, groups)
        
        if bias is not None:
            output += bias.view(1, -1, 1, 1)
        
        return output
