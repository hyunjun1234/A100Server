import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void conv2d_kernel(const float* input, const float* weight, float* output, int N, int C, int H, int W, int K, int S) {
    int n = blockIdx.x;
    int c = blockIdx.y;
    int h = blockIdx.z;
    int w = threadIdx.x;

    if (n < N && c < C && h < H && w < W) {
        float sum = 0.0f;
        for (int kc = 0; kc < C; ++kc) {
            for (int kh = 0; kh < K; ++kh) {
                for (int kw = 0; kw < K; ++kw) {
                    int input_idx = (n * C + kc) * H * W + (h * S + kh) * W + (w * S + kw);
                    int weight_idx = (c * C + kc) * K * K + kh * K + kw;
                    sum += input[input_idx] * weight[weight_idx];
                }
            }
        }
        output[n * C * H * W + c * H * W + h * W + w] = sum;
    }
}

__global__ void avg_pool2d_kernel(const float* input, float* output, int N, int C, int H, int W, int KH, int KW, int SH, int SW) {
    int n = blockIdx.x;
    int c = blockIdx.y;
    int h = blockIdx.z;
    int w = threadIdx.x;

    if (n < N && c < C && h < H && w < W) {
        float sum = 0.0f;
        for (int kh = 0; kh < KH; ++kh) {
            for (int kw = 0; kw < KW; ++kw) {
                int input_idx = (n * C + c) * H * W + (h * SH + kh) * W + (w * SW + kw);
                sum += input[input_idx];
            }
        }
        output[n * C * H * W + c * H * W + h * W + w] = sum / (KH * KW);
    }
}

__global__ void sigmoid_kernel(const float* input, float* output, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        output[idx] = 1.0f / (1.0f + expf(-input[idx]));
    }
}

__global__ void sum_kernel(const float* input, float* output, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        atomicAdd(output, input[idx]);
    }
}

torch::Tensor conv2d_cuda(torch::Tensor input, torch::Tensor weight, int C, int H, int W, int K, int S) {
    auto output = torch::zeros({input.size(0), C, (H - K + S) / S, (W - K + S) / S});
    int N = input.size(0);
    int H_out = (H - K + S) / S;
    int W_out = (W - K + S) / S;
    conv2d_kernel<<<dim3(N, C, H_out), W_out>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), N, C, H, W, K, S);
    return output;
}

torch::Tensor avg_pool2d_cuda(torch::Tensor input, int KH, int KW, int SH, int SW) {
    auto output = torch::zeros({input.size(0), input.size(1), (input.size(2) - KH) / SH + 1, (input.size(3) - KW) / SW + 1});
    int N = input.size(0);
    int C = input.size(1);
    int H_out = (input.size(2) - KH) / SH + 1;
    int W_out = (input.size(3) - KW) / SW + 1;
    avg_pool2d_kernel<<<dim3(N, C, H_out), W_out>>>(input.data_ptr<float>(), output.data_ptr<float>(), N, C, input.size(2), input.size(3), KH, KW, SH, SW);
    return output;
}

torch::Tensor sigmoid_cuda(torch::Tensor input) {
    auto output = torch::zeros_like(input);
    int N = input.numel();
    sigmoid_kernel<<<(N + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), N);
    return output;
}

float sum_cuda(torch::Tensor input) {
    auto output = torch::zeros({1});
    int N = input.numel();
    sum_kernel<<<(N + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), N);
    return output.item<float>();
}

"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv2d_cuda", "avg_pool2d_cuda", "sigmoid_cuda", "sum_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, pool_kernel_size):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size)
        self.avg_pool = nn.AvgPool2d(pool_kernel_size)

    def forward(self, x):
        weight = self.conv.weight.view(self.conv.out_channels, self.conv.in_channels, self.conv.kernel_size[0], self.conv.kernel_size[1])
        x = _get_mod().conv2d_cuda(x, weight, self.conv.out_channels, x.size(2), x.size(3), self.conv.kernel_size[0], self.conv.stride[0])
        x = _get_mod().avg_pool2d_cuda(x, self.avg_pool.kernel_size[0], self.avg_pool.kernel_size[1], self.avg_pool.stride[0], self.avg_pool.stride[1])
        x = _get_mod().sigmoid_cuda(x)
        result = _get_mod().sum_cuda(x)
        return torch.tensor([result], device=x.device)
