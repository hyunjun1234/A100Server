import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv3d_kernel(
    const float* input, const float* weight, float* output,
    int batch_size, int in_channels, int out_channels,
    int depth, int height, int width,
    int kernel_size_d, int kernel_size_h, int kernel_size_w,
    int stride_d, int stride_h, int stride_w,
    int padding_d, int padding_h, int padding_w,
    int dilation_d, int dilation_h, int dilation_w,
    int groups, int bias) {
    
    int b = blockIdx.x / (out_channels * (depth_out * height_out * width_out));
    int oc = (blockIdx.x / (depth_out * height_out * width_out)) % out_channels;
    int d_out = (blockIdx.x / (height_out * width_out)) % depth_out;
    int h_out = (blockIdx.x / width_out) % height_out;
    int w_out = blockIdx.x % width_out;

    int d_in = d_out * stride_d - padding_d;
    int h_in = h_out * stride_h - padding_h;
    int w_in = w_out * stride_w - padding_w;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ic++) {
        for (int kd = 0; kd < kernel_size_d; kd++) {
            int d = d_in + kd * dilation_d;
            if (d < 0 || d >= depth) continue;
            for (int kh = 0; kh < kernel_size_h; kh++) {
                int h = h_in + kh * dilation_h;
                if (h < 0 || h >= height) continue;
                for (int kw = 0; kw < kernel_size_w; kw++) {
                    int w = w_in + kw * dilation_w;
                    if (w < 0 || w >= width) continue;
                    int input_idx = b * in_channels * depth * height * width +
                                    ic * depth * height * width +
                                    d * height * width +
                                    h * width +
                                    w;
                    int weight_idx = oc * in_channels * kernel_size_d * kernel_size_h * kernel_size_w +
                                     ic * kernel_size_d * kernel_size_h * kernel_size_w +
                                     kd * kernel_size_h * kernel_size_w +
                                     kh * kernel_size_w +
                                     kw;
                    sum += input[input_idx] * weight[weight_idx];
                }
            }
        }
    }

    if (bias) {
        int bias_idx = oc;
        sum += weight[out_channels * in_channels * kernel_size_d * kernel_size_h * kernel_size_w + bias_idx];
    }

    int output_idx = b * out_channels * depth_out * height_out * width_out +
                      oc * depth_out * height_out * width_out +
                      d_out * height_out * width_out +
                      h_out * width_out +
                      w_out;
    output[output_idx] = sum;
}

torch::Tensor conv3d_cuda(
    torch::Tensor input, torch::Tensor weight, int kernel_size_d, int kernel_size_h, int kernel_size_w,
    int stride_d, int stride_h, int stride_w, int padding_d, int padding_h, int padding_w,
    int dilation_d, int dilation_h, int dilation_w, int groups, int bias) {
    
    auto output = torch::zeros_like(input);
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int out_channels = weight.size(0);
    int depth = input.size(2);
    int height = input.size(3);
    int width = input.size(4);
    int depth_out = (depth + 2 * padding_d - dilation_d * (kernel_size_d - 1) - 1) / stride_d + 1;
    int height_out = (height + 2 * padding_h - dilation_h * (kernel_size_h - 1) - 1) / stride_h + 1;
    int width_out = (width + 2 * padding_w - dilation_w * (kernel_size_w - 1) - 1) / stride_w + 1;

    dim3 threads(256);
    dim3 blocks((batch_size * out_channels * depth_out * height_out * width_out + threads.x - 1) / threads.x);

    conv3d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        depth, height, width,
        kernel_size_d, kernel_size_h, kernel_size_w,
        stride_d, stride_h, stride_w,
        padding_d, padding_h, padding_w,
        dilation_d, dilation_h, dilation_w,
        groups, bias);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1, 1), padding: tuple = (0, 0, 0), dilation: tuple = (1, 1, 1), groups: int = 1, bias: bool = False):
        super().__init__()
        self.conv3d = nn.Conv3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv3d.weight
        bias = self.conv3d.bias is not None
        return _get_mod().conv3d_cuda(x, weight, self.conv3d.kernel_size[0], self.conv3d.kernel_size[1], self.conv3d.kernel_size[2],
                                      self.conv3d.stride[0], self.conv3d.stride[1], self.conv3d.stride[2],
                                      self.conv3d.padding[0], self.conv3d.padding[1], self.conv3d.padding[2],
                                      self.conv3d.dilation[0], self.conv3d.dilation[1], self.conv3d.dilation[2],
                                      self.conv3d.groups, bias)
