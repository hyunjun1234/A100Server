import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose2d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int height_in, int width_in, int height_out, int width_out,
    int kernel_h, int kernel_w, int stride_h, int stride_w,
    int padding_h, int padding_w, int output_padding_h, int output_padding_w,
    int dilation_h, int dilation_w, int groups) {
    
    int b = blockIdx.x / (out_channels * height_out * width_out);
    int oc = (blockIdx.x / (height_out * width_out)) % out_channels;
    int h_out = (blockIdx.x / width_out) % height_out;
    int w_out = blockIdx.x % width_out;

    int h_in_start = h_out * stride_h - padding_h;
    int w_in_start = w_out * stride_w - padding_w;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kh = 0; kh < kernel_h; ++kh) {
            for (int kw = 0; kw < kernel_w; ++kw) {
                int h_in = h_in_start + kh * dilation_h;
                int w_in = w_in_start + kw * dilation_w;
                if (h_in >= 0 && h_in < height_in && w_in >= 0 && w_in < width_in) {
                    int input_idx = ((b * in_channels + ic) * height_in + h_in) * width_in + w_in;
                    int weight_idx = ((oc * in_channels + ic) * kernel_h + kh) * kernel_w + kw;
                    sum += input[input_idx] * weight[weight_idx];
                }
            }
        }
    }

    int output_idx = ((b * out_channels + oc) * height_out + h_out) * width_out + w_out;
    output[output_idx] = sum + bias[oc];
}

torch::Tensor conv_transpose2d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int height_in, int width_in, int height_out, int width_out,
    int kernel_h, int kernel_w, int stride_h, int stride_w,
    int padding_h, int padding_w, int output_padding_h, int output_padding_w,
    int dilation_h, int dilation_w, int groups) {
    
    auto output = torch::zeros({batch_size, out_channels, height_out, width_out}, input.options());
    int num_threads = 256;
    int num_blocks = (batch_size * out_channels * height_out * width_out + num_threads - 1) / num_threads;
    conv_transpose2d_kernel<<<num_blocks, num_threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        height_in, width_in, height_out, width_out,
        kernel_h, kernel_w, stride_h, stride_w,
        padding_h, padding_w, output_padding_h, output_padding_w,
        dilation_h, dilation_w, groups);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose2d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1), padding: tuple = (0, 0), output_padding: tuple = (0, 0), dilation: tuple = (1, 1), groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv_transpose2d = nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, dilation=dilation, groups=groups, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv_transpose2d.weight
        bias = self.conv_transpose2d.bias if self.conv_transpose2d.bias is not None else torch.zeros(self.conv_transpose2d.out_channels, device=x.device)
        
        batch_size, in_channels, height_in, width_in = x.size()
        out_channels = self.conv_transpose2d.out_channels
        kernel_h, kernel_w = self.conv_transpose2d.kernel_size
        stride_h, stride_w = self.conv_transpose2d.stride
        padding_h, padding_w = self.conv_transpose2d.padding
        output_padding_h, output_padding_w = self.conv_transpose2d.output_padding
        dilation_h, dilation_w = self.conv_transpose2d.dilation
        groups = self.conv_transpose2d.groups
        
        height_out = (height_in - 1) * stride_h - 2 * padding_h + dilation_h * (kernel_h - 1) + output_padding_h + 1
        width_out = (width_in - 1) * stride_w - 2 * padding_w + dilation_w * (kernel_w - 1) + output_padding_w + 1
        
        return _get_mod().conv_transpose2d_cuda(
            x, weight, bias,
            batch_size, in_channels, out_channels,
            height_in, width_in, height_out, width_out,
            kernel_h, kernel_w, stride_h, stride_w,
            padding_h, padding_w, output_padding_h, output_padding_w,
            dilation_h, dilation_w, groups)
