import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int depth, int height, int width, int kernel_size, int stride, int padding) {
    int b = blockIdx.x / (out_channels * depth * height * width);
    int oc = (blockIdx.x / (depth * height * width)) % out_channels;
    int d = (blockIdx.x / (height * width)) % depth;
    int h = (blockIdx.x / width) % height;
    int w = blockIdx.x % width;

    if (b < batch_size && oc < out_channels && d < depth && h < height && w < width) {
        float sum = 0.0f;
        for (int ic = 0; ic < in_channels; ++ic) {
            for (int kd = -padding; kd <= padding; ++kd) {
                for (int kh = -padding; kh <= padding; ++kh) {
                    for (int kw = -padding; kw <= padding; ++kw) {
                        int id = d * stride + kd;
                        int ih = h * stride + kh;
                        int iw = w * stride + kw;
                        if (id >= 0 && id < depth && ih >= 0 && ih < height && iw >= 0 && iw < width) {
                            sum += input[b * in_channels * depth * height * width + ic * depth * height * width + id * height * width + ih * width + iw] *
                                   weight[oc * in_channels * kernel_size * kernel_size * kernel_size + ic * kernel_size * kernel_size * kernel_size + (kd + padding) * kernel_size * kernel_size + (kh + padding) * kernel_size + (kw + padding)];
                        }
                    }
                }
            }
        }
        output[b * out_channels * depth * height * width + oc * depth * height * width + d * height * width + h * width + w] = sum;
    }
}

__global__ void batch_norm_kernel(const float* input, float* output, const float* running_mean, const float* running_var, float eps, int batch_size, int out_channels, int depth, int height, int width) {
    int b = blockIdx.x / (out_channels * depth * height * width);
    int oc = (blockIdx.x / (depth * height * width)) % out_channels;
    int d = (blockIdx.x / (height * width)) % depth;
    int h = (blockIdx.x / width) % height;
    int w = blockIdx.x % width;

    if (b < batch_size && oc < out_channels && d < depth && h < height && w < width) {
        float x = input[b * out_channels * depth * height * width + oc * depth * height * width + d * height * width + h * width + w];
        float norm = (x - running_mean[oc]) / sqrt(running_var[oc] + eps);
        output[b * out_channels * depth * height * width + oc * depth * height * width + d * height * width + h * width + w] = norm;
    }
}

__global__ void avg_pool_kernel(const float* input, float* output, int batch_size, int out_channels, int depth, int height, int width, int pool_size) {
    int b = blockIdx.x / (out_channels * depth * height * width);
    int oc = (blockIdx.x / (depth * height * width)) % out_channels;
    int d = (blockIdx.x / (height * width)) % depth;
    int h = (blockIdx.x / width) % height;
    int w = blockIdx.x % width;

    if (b < batch_size && oc < out_channels && d < depth && h < height && w < width) {
        float sum = 0.0f;
        for (int pd = 0; pd < pool_size; ++pd) {
            for (int ph = 0; ph < pool_size; ++ph) {
                for (int pw = 0; pw < pool_size; ++pw) {
                    sum += input[b * out_channels * depth * height * width + oc * depth * height * width + (d * pool_size + pd) * height * width + (h * pool_size + ph) * width + w * pool_size + pw];
                }
            }
        }
        output[b * out_channels * depth * height * width + oc * depth * height * width + d * height * width + h * width + w] = sum / (pool_size * pool_size * pool_size);
    }
}

torch::Tensor conv_transpose_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int depth, int height, int width, int kernel_size, int stride, int padding) {
    auto output = torch::zeros({batch_size, out_channels, depth, height, width}, input.options());
    conv_transpose_kernel<<<(batch_size * out_channels * depth * height * width + 255) / 256, 256>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, out_channels, depth, height, width, kernel_size, stride, padding);
    return output;
}

torch::Tensor batch_norm_cuda(torch::Tensor input, const float* running_mean, const float* running_var, float eps, int batch_size, int out_channels, int depth, int height, int width) {
    auto output = torch::zeros_like(input);
    batch_norm_kernel<<<(batch_size * out_channels * depth * height * width + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), running_mean, running_var, eps, batch_size, out_channels, depth, height, width);
    return output;
}

torch::Tensor avg_pool_cuda(torch::Tensor input, int batch_size, int out_channels, int depth, int height, int width, int pool_size) {
    auto output = torch::zeros({batch_size, out_channels, depth / pool_size, height / pool_size, width / pool_size}, input.options());
    avg_pool_kernel<<<(batch_size * out_channels * depth * height * width + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_channels, depth, height, width, pool_size);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose_cuda", "batch_norm_cuda", "avg_pool_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, bias_shape):
        super().__init__()
        self.conv_transpose = nn.ConvTranspose3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding)
        self.batch_norm = nn.BatchNorm3d(out_channels)
        self.avg_pool1 = nn.AvgPool3d(kernel_size=2)
        self.avg_pool2 = nn.AvgPool3d(kernel_size=2)

    def forward(self, x):
        weight = self.conv_transpose.weight
        running_mean = self.batch_norm.running_mean
        running_var = self.batch_norm.running_var
        eps = self.batch_norm.eps

        x = _get_mod().conv_transpose_cuda(x, weight, x.size(0), x.size(1), self.conv_transpose.out_channels, x.size(2), x.size(3), x.size(4), self.conv_transpose.kernel_size[0], self.conv_transpose.stride[0], self.conv_transpose.padding[0])
        x = _get_mod().batch_norm_cuda(x, running_mean.data_ptr<float>(), running_var.data_ptr<float>(), eps, x.size(0), self.batch_norm.num_features, x.size(2), x.size(3), x.size(4))
        x = _get_mod().avg_pool_cuda(x, x.size(0), x.size(1), x.size(2), x.size(3), x.size(4), self.avg_pool1.kernel_size[0])
        x = _get_mod().avg_pool_cuda(x, x.size(0), x.size(1), x.size(2), x.size(3), x.size(4), self.avg_pool2.kernel_size[0])
        return x
