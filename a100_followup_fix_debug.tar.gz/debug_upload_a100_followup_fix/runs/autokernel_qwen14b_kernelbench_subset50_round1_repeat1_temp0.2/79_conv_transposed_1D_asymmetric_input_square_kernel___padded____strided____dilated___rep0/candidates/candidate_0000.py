import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose1d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int padding, int dilation) {
    
    int b = blockIdx.x / (out_channels * (length + 2 * padding));
    int oc = (blockIdx.x / (length + 2 * padding)) % out_channels;
    int o = blockIdx.x % (length + 2 * padding);

    float sum = 0.0f;
    if (bias != nullptr) {
        sum = bias[oc];
    }

    for (int ic = 0; ic < in_channels; ++ic) {
        for (int k = 0; k < kernel_size; ++k) {
            int i = o * stride - padding + k * dilation;
            if (i >= 0 && i < length) {
                sum += input[b * in_channels * length + ic * length + i] *
                       weight[oc * in_channels * kernel_size + ic * kernel_size + k];
            }
        }
    }

    output[b * out_channels * (length + 2 * padding) + oc * (length + 2 * padding) + o] = sum;
}

torch::Tensor conv_transpose1d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int padding, int dilation) {
    
    auto output = torch::zeros({batch_size, out_channels, length + 2 * padding}, input.options());
    int num_threads = 256;
    int num_blocks = (batch_size * out_channels * (length + 2 * padding) + num_threads - 1) / num_threads;
    conv_transpose1d_kernel<<<num_blocks, num_threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.defined() ? bias.data_ptr<float>() : nullptr,
        batch_size, in_channels, out_channels, length,
        kernel_size, stride, padding, dilation);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose1d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, bias: bool = False):
        super().__init__()
        self.conv1d_transpose = nn.ConvTranspose1d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, dilation=dilation, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if not x.is_cuda:
            raise ValueError("Input tensor must be on CUDA device.")
        
        weight = self.conv1d_transpose.weight
        bias = self.conv1d_transpose.bias if self.conv1d_transpose.bias is not None else torch.tensor([], dtype=torch.float32, device=x.device)
        
        batch_size, in_channels, length = x.size()
        out_channels = weight.size(0)
        kernel_size = weight.size(2)
        stride = self.conv1d_transpose.stride[0]
        padding = self.conv1d_transpose.padding[0]
        dilation = self.conv1d_transpose.dilation[0]
        
        return _get_mod().conv_transpose1d_cuda(
            x, weight, bias,
            batch_size, in_channels, out_channels, length,
            kernel_size, stride, padding, dilation)
