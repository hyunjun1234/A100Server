import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void max_kernel(const float* input, float* output, int N, int max_dim) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        int row = idx / max_dim;
        int col = idx % max_dim;
        float max_val = -FLT_MAX;
        for (int i = 0; i < max_dim; ++i) {
            max_val = fmaxf(max_val, input[row * max_dim + i]);
        }
        output[row] = max_val;
    }
}

__global__ void subtract_mean_kernel(const float* input, float* output, int N, float mean) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        output[idx] = input[idx] - mean;
    }
}

torch::Tensor gemm_max_subtract_gelu_cuda(torch::Tensor x, torch::Tensor weight, torch::Tensor bias, int max_dim) {
    auto output = torch::empty_like(x);
    int N = x.size(0);
    int M = weight.size(0);
    int K = weight.size(1);

    // GEMM
    cublasHandle_t handle;
    cublasCreate(&handle);
    float alpha = 1.0f, beta = 0.0f;
    cublasSgemm(handle, CUBLAS_OP_N, CUBLAS_OP_N, M, N, K, &alpha, weight.data_ptr<float>(), K, x.data_ptr<float>(), N, &beta, output.data_ptr<float>(), M);
    cublasDestroy(handle);

    // Add bias
    output.add_(bias.view(1, -1));

    // Max
    max_kernel<<<(N + 255) / 256, 256>>>(output.data_ptr<float>(), output.data_ptr<float>(), N, max_dim);

    // Subtract mean
    float mean = output.mean().item<float>();
    subtract_mean_kernel<<<(N + 255) / 256, 256>>>(output.data_ptr<float>(), output.data_ptr<float>(), N, mean);

    // GELU
    for (int i = 0; i < N * M; ++i) {
        float val = output.data_ptr<float>()[i];
        output.data_ptr<float>()[i] = 0.5f * val * (1.0f + tanhf(0.7978845608028654f * (val + 0.044715f * val * val * val)));
    }

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "gemm_max_subtract_gelu_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, max_dim):
        super().__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.max_dim = max_dim

    def forward(self, x):
        return _get_mod().gemm_max_subtract_gelu_cuda(x, self.gemm.weight, self.gemm.bias, self.max_dim)
