import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void cumsum_kernel(const float* input, float* output, int N, int dim, int stride) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        int base_idx = idx / stride * stride;
        output[idx] = input[idx];
        for (int i = 1; i <= dim; ++i) {
            output[idx] += input[base_idx + idx % stride - i];
        }
    }
}

torch::Tensor cumsum_cuda(torch::Tensor input, int dim) {
    auto output = torch::empty_like(input);
    int N = input.numel();
    int stride = input.size(dim);
    cumsum_kernel<<<(N+255)/256, 256>>>(
        input.data_ptr<float>(), output.data_ptr<float>(), N, dim, stride);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "cumsum_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, x):
        return _get_mod().cumsum_cuda(x, self.dim)
