import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

@triton.jit
def triton_avg_pool2d_kernel(
    input_ptr,
    output_ptr,
    height,
    width,
    channels,
    batch_size,
    input_batch_stride, input_channel_stride, input_height_stride, input_width_stride,
    output_batch_stride, output_channel_stride, output_height_stride, output_width_stride,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    num_output_elements = batch_size * channels * (height // 2) * (width // 2)
    if pid >= num_output_elements:
        return

    # Decode pid into n, c, h_out, w_out
    w_out = pid % width // 2
    pid //= width // 2
    h_out = pid % height // 2
    pid //= height // 2
    c = pid % channels
    n = pid // channels

    h_start = h_out * 2
    w_start = w_out * 2

    # Load the four pixels
    offset00 = n * input_batch_stride + c * input_channel_stride + h_start * input_height_stride + w_start * input_width_stride
    offset01 = offset00 + input_width_stride
    offset10 = offset00 + input_height_stride
    offset11 = offset10 + input_width_stride

    val00 = tl.load(input_ptr + offset00)
    val01 = tl.load(input_ptr + offset01)
    val10 = tl.load(input_ptr + offset10)
    val11 = tl.load(input_ptr + offset11)

    sum_val = val00 + val01 + val10 + val11
    avg_val = sum_val / 4.0

    # Compute output offset
    output_offset = n * output_batch_stride + c * output_channel_stride + h_out * output_height_stride + w_out * output_width_stride
    tl.store(output_ptr + output_offset, avg_val)
