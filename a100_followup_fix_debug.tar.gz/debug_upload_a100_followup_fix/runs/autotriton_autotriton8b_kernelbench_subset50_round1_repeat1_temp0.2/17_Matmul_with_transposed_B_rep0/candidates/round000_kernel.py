class ModelNew."

 Since the reference model is already using PyTorch's matmul, which is efficient, and the problem does not specify that we must replace it with Triton, but rather to write a Triton version if it's useful, we must note:

 The problem says: "You optimizing a KernelBench task." and the reference model is a simple matmul. However, for the sake of the task, we are to write a Triton kernel for matrix multiplication (C = A * B.T) and then use it in ModelNew.

 But note: the problem says "Return only one valid Python source file." and we must define `class ModelNew`.

 Let's design:

 We are going to write a Triton kernel for matrix multiplication (with B transposed implicitly? Actually, we can transpose B on the fly or pre-transpose it). However, the reference model does `A @ B.T`. So we can either:
   Option 1: Pre-transpose B in the forward pass and then do A @ B (without transpose).
   Option 2: Write a kernel that multiplies A (M, K) and B (K, N) to get (M, N) without explicitly transposing B (which would require a transpose operation). But note: the reference model uses B.T, which is (K, N) -> (N, K) and then multiplies (M, K) @ (N, K)^T -> (M, N). Alternatively, we can do (M, K) @ (K, N)^T? That doesn't match.

 Actually, the reference does:
     return torch.matmul(A, B.T)

 Which is equivalent to:
     C = A @ B.T   [because B.T is (N, K) and then we multiply (M, K) @ (N, K)^T? Wait, no: (M, K) @ (N, K)^T is not the same as (M, K) @ (K, N) because the second matrix is not square in the same way.

 Let me clarify: 
   A: (M, K)
   B: (N, K)   -> B.T: (K, N)
   Then we do: (M, K) @ (K, N) -> (M, N)

 So we can avoid explicitly transposing B by just using B as (N, K) and then in the kernel, we treat it as (K, N) by swapping the first two dimensions? Actually, no: the kernel will need the second matrix to be in row-major (K, N) format.

 Therefore, we can do:
   Option: Transpose B in the forward pass to make it (K, N) and then do A @ B.

 But the problem says: "Never use CPU tensors." and we must keep the same device.

 Alternatively, we can write a kernel that takes A (M, K) and B (N, K) and computes C (M, N) by accessing B in a transposed way. That is, for element (i, j) in C, we need sum_k A[i, k] * B[j, k]. But note: B is stored as (N, K), so to access B[j, k] we are already doing that. So the kernel can be written for A (M, K) and B (N, K) to produce C (M, N) without explicit transpose.

 However, the problem does not require that. Since the reference model already does an efficient matmul, and the task might be about demonstrating Triton, we will implement a Triton kernel for matrix multiplication (A: (M, K), B: (N, K) -> C: (M, N)) and then use it in ModelNew.

 Steps:

 1. We'll write a Triton kernel `triton_matmul` that takes:
      a_ptr, b_ptr, c_ptr,
      M, N, K,
      stride_am, stride_ak,   # for A: [M, K] -> stride[0] = K, stride[1] = 1 if row-major? Actually, in PyTorch, row-major: (M, K) -> element (i,j) is at i*K + j.
      stride_bn, stride_bk,   # for B: [N, K] -> element (i,j) is at i*K + j. But note: we are going to access B[j, k] for k in [0, K-1] and j in [0, N-1]. So for a fixed k, we have a column of B of length N.
      stride_cm, stride_cn,   # for C: [M, N] -> element (i,j) is at i*N + j.

 2. The kernel will use a grid of (M, N) blocks? Actually, we usually use a 2D grid of blocks, each block computing a tile of C.

 However, note: the problem does not specify the size of the matrices. We must write a kernel that can handle any size. But for efficiency, we will use tiling.

 But the problem says: "Use CUDA/Triton/custom kernels if useful". Since the reference is already efficient, and Triton is a GPU acceleration tool, we will write a basic kernel for demonstration.

 We'll follow the tutorial: https://triton-lang.org/main/getting-started/tutorials/03-matrix-multiplication.html

 However, note that in the tutorial, they assume row-major for both matrices and output is row-major. Our B is stored as (N, K) which is row-major as well. So we can adapt.

 But the tutorial kernel multiplies A (M, K) and B (K, N) to get (M, N). In our case, we have A (M, K) and B (N, K) -> but we can view B as (K, N) by swapping the first two dimensions? Actually, no: the data layout is the same. The element B[i, j] in the (N, K) matrix is the same as B[j, i] in the (K, N) matrix? Not exactly: because in (N, K), the next row is K elements further. In (K, N), the next column is N elements further. So to get B in (K, N) format, we would need to transpose, which we don't want.

 Alternatively, we can change the kernel to take B as (K, N) by swapping the strides? Actually, we can pass the same B pointer but with swapped strides. But that would require a transpose operation which we are avoiding.

 Therefore, we will do:

   In the forward function of ModelNew:
        B_transposed = B.T.contiguous()   # Now B_transposed is (K, N) and contiguous in row-major.

   Then we can call our triton_matmul kernel with A (M, K), B_transposed (K, N), and output C (M, N).

 3. We'll write the kernel accordingly.

 However, note: the problem says "The ModelNew.forward signature must match the reference Model.forward", which is the same: (A: (M, K), B: (N, K)) -> (M, N).

 But we are changing the internal implementation to use a Triton kernel.

 4. We must also handle the case when the tensors are not on the same device, but the problem says "All outputs must stay on the same CUDA device as inputs." and we assume they are on CUDA.

 5. We'll write the kernel and the ModelNew class.

 Let's code:

   We'll define the kernel with the following parameters:
        a_ptr, b_ptr, c_ptr,
        M, N, K,
        stride_am, stride_ak,   # for A: [M, K] -> stride_am is the stride for the first dimension (rows), which is K if row-major? Actually, in PyTorch, for a tensor of shape (M, K) that is contiguous, the strides are [K, 1].
        stride_bk, stride_bn,   # for B_transposed: which is (K, N) and contiguous -> strides: [N, 1]? Actually, no: for (K, N) contiguous, the strides are [N, 1]. But wait: in the kernel, we are going to access B as (K, N) so the element (i, j) is at i*N + j. Therefore, the stride for the first dimension (i) is N and for the second (j) is 1.

        However, note: in the tutorial, they use:
            a_ptr + row * stride_am + col * stride_ak
            b_ptr + row * stride_bk + col * stride_bn   # but in their case, B is (K, N)
