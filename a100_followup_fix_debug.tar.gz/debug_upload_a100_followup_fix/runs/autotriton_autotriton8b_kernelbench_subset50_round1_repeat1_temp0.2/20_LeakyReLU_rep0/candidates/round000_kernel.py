import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def leaky_relu_kernel(
    x_ptrs,
    out_ptrs,
    xnumel,
    XBLOCK : tl.constexpr,
    negative_slope : tl.constexpr,
):
    pid = tl.program_id(0) 
    offsets = pid * XBLOCK + tl.arange(0, XBLOCK)[:]
    x_mask = offsets < xnumel
    x = tl.load(x_ptrs + offsets, mask=x_mask)
    out = tl.where(x >= 0, x, x * negative_slope)
    tl.store(out_ptrs + offsets, out, mask=x_mask)

class ModelNew(nn.Module):
    """
    Simple model that performs a LeakyReLU activation using Triton.
    """
    def __init__(self, negative_slope: float = 0.01):
        """
        Initializes the LeakyReLU module.

        Args:
            negative_slope (float, optional): The negative slope of the activation function. Defaults to 0.01.
        """
        super(ModelNew, self).__init__()
        self.negative_slope = negative_slope
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Applies LeakyReLU activation to the input tensor using Triton.

        Args:
            x (torch.Tensor): Input tensor of any shape, must be on CUDA.

        Returns:
            torch.Tensor: Output tensor with LeakyReLU applied, same shape as input.
        """
        if not x.is_cuda:
            raise ValueError("Input tensor must be on CUDA device.")
        output = torch.empty_like(x)
        XBLOCK = 1024
        grid = (triton.cdiv(x.numel(), XBLOCK),)
        leaky_relu_kernel[grid](
            x, output, x.numel(), XBLOCK, self.negative_slope
        )
        return output
