import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def hardsigmoid_kernel(
    x_ptr,
    output_ptr,
    nelem,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    block_start = pid * BLOCK_SIZE
    offsets = block_start + tl.arange(0, BLOCK_SIZE)
    mask = offsets < nelem
    x = tl.load(x_ptr + offsets, mask=mask)
    
    zero = tl.zeros_like(x)
    one = tl.full_like(x, 1.0)
    x_scaled = x * (1.0 / 6.0)
    result = tl.where(x <= -3.0, zero, x_scaled + 0.5)
    result = tl.where(x >= 3.0, one, result)
    
    tl.store(output_ptr + offsets, result, mask=mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        assert x.is_cuda, "Input tensor must be on CUDA"
        output = torch.empty_like(x)
        nelem = x.numel()
        if nelem == 0:
            return output
        BLOCK_SIZE = 1024
        grid = (triton.cdiv(nelem, BLOCK_SIZE),)
        hardsigmoid_kernel[grid](x.view(-1), output.view(-1), nelem, BLOCK_SIZE)
        return output
