import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def mish_kernel(
    x_ptrs,
    out_ptrs,
    xnumel,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < xnumel
    x = tl.load(x_ptrs + offsets, mask=mask)
    zero = 0.0
    one = 1.0
    threshold = 20.0
    exp_x = tl.math.exp(x)
    log1p_exp_x = tl.math.log(one + exp_x)
    gt_mask = x > threshold
    where_result = tl.where(gt_mask, x, log1p_exp_x)
    tanh_result = tl.math.tanh(where_result)
    out = x * tanh_result
    tl.store(out_ptrs + offsets, out, mask=mask)

class ModelNew(nn.Module):
    """
    Optimized model using Triton for Mish activation.
    Performs linear transformation followed by two Mish activations.
    """
    def __init__(self, in_features, out_features):
        super(ModelNew, self).__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x):
        x = self.linear(x)
        x = self._apply_mish(x)
        x = self._apply_mish(x)
        return x

    def _apply_mish(self, x):
        if not x.is_cuda:
            return torch.nn.functional.mish(x)
        output = torch.empty_like(x)
        numel = x.numel()
        grid = lambda meta: (triton.cdiv(numel, meta['BLOCK_SIZE']),)
        mish_kernel[grid](x, output, numel, BLOCK_SIZE=1024)
        return output
