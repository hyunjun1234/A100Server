import torch
import torch.nn as nn
import triton
import triton.language as tl
from triton.language.extra import libdevice

@triton.jit
def triton_softplus_kernel(
    x_ptr,
    out_ptr,
    xnumel,
    threshold,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < xnumel
    x = tl.load(x_ptr + offsets, mask=mask)
    
    is_large = x > threshold
    exp_x = tl.math.exp(x)
    log1p_exp_x = libdevice.log1p(exp_x)
    result = tl.where(is_large, x, log1p_exp_x)
    
    tl.store(out_ptr + offsets, result, mask=mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_flat = x.flatten()
        output_flat = torch.empty_like(x_flat)
        xnumel = x_flat.numel()
        
        if xnumel == 0:
            return x
        
        BLOCK_SIZE = 1024
        grid = lambda meta: (triton.cdiv(xnumel, meta['BLOCK_SIZE']),)
        
        triton_softplus_kernel[grid](
            x_flat,
            output_flat,
            xnumel,
            20.0,
            BLOCK_SIZE=BLOCK_SIZE
        )
        
        return output_flat.reshape(x.shape)
