...  # all the necessary classes and functions, without the checkpointing code in BasicLayer
...

class ModelNew(Model):
    pass
