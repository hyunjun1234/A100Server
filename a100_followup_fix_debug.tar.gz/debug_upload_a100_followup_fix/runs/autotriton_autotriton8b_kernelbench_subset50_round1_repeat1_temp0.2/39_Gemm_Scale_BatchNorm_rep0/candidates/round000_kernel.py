<think>
We are given a reference model that does:
1. Linear transformation (GEMM)
2. Scaling by a parameter (scale)
3. Batch normalization

We are to optimize this using Triton or CUDA kernels where beneficial.

However, note that the reference model already uses PyTorch's built-in operations. 
But the task might be to replace parts with custom kernels for performance.

But the problem says: "Use CUDA/Triton/custom kernels if useful." and "Never use CPU tensors."

Let's break down the operations:

1. Linear layer (GEMM): This is a highly optimized operation in cuBLAS. We might not need a custom kernel for this unless we are targeting very specific optimizations.

2. Scaling: This is an element-wise operation. We can implement this with a Triton kernel for better performance, but PyTorch's element-wise operations are already efficient.

3. Batch normalization: PyTorch's batch norm is also optimized. We might not need a custom kernel here.

Given that the operations are already optimized in PyTorch, it's not clear if we need to replace any with Triton. However, the problem might expect us to demonstrate Triton usage where possible.

But note: the scaling operation (x = x * self.scale) can be done with a Triton kernel for educational purposes.

Alternatively, we might consider fusing the scaling and batch norm? But the problem doesn't specify.

We are to define a class `ModelNew` that has the same forward pass.

We'll keep the linear layer as is (using `nn.Linear`). We'll replace the scaling and batch norm with a custom Triton kernel? Or we can write a Triton kernel for the scaling step.

However, the scaling step is very simple and might not benefit from a custom kernel. But let's proceed.

Plan:

- We'll keep the linear layer (self.gemm) as a nn.Linear.
- We'll create a parameter self.scale as before.
- Instead of doing `x = x * self.scale` and then `x = self.bn(x)`, we can combine them? Or we can write a Triton kernel that does both scaling and batch norm? But the problem doesn't specify.

Alternatively, we can write a Triton kernel that does the scaling step only. Why? Because the problem might be to demonstrate Triton.

But note: the batch norm has learnable parameters (weight and bias) and running statistics. We cannot ignore them.

We have two options:

Option 1: Keep the batch norm as is, and replace the scaling with a Triton kernel.

Option 2: Fuse scaling and batch norm into a single kernel to avoid the intermediate storage.

Given that the problem doesn't specify, and to match the reference exactly, we'll do:

x = self.gemm(x)
x = triton_scale_and_bn(x, self.scale, self.bn.weight, self.bn.bias, self.bn.running_mean, self.bn.running_var, self.bn.eps)

But wait, the batch norm has momentum and training/eval modes. We must respect those.

Alternatively, we can write a kernel that does:

scaled = x * scale
then apply batch norm with the given parameters.

But note: the batch norm operation in PyTorch is:

y = (x - mean) / sqrt(var + eps) * weight + bias

We can write a Triton kernel that does this for each element in the batch (each feature across the batch).

However, note that the batch norm is applied per feature (across the batch). So for each feature j, we have:

output[i, j] = (input[i, j] * scale[j] - running_mean[j]) / sqrt(running_var[j] + eps) * weight[j] + bias[j]

But wait: the input to batch norm is the output of the linear layer (which is of shape [batch_size, out_features]). The scaling is applied first (element-wise by feature). Then batch norm is applied per feature (across the batch).

So the Triton kernel will take:
- input tensor (after linear layer) of shape [batch_size, out_features]
- scale tensor of shape [out_features]
- batch norm parameters: weight, bias, running_mean, running_var, eps

And output a tensor of the same shape.

We can write a Triton kernel that does:

for each element (i, j) in the input:
    temp = input[i, j] * scale[j]
    temp = (temp - running_mean[j]) / sqrt(running_var[j] + eps)
    temp = temp * weight[j] + bias[j]
    output[i, j] = temp

But note: the batch norm parameters (weight, bias, running_mean, running_var) are learnable and have the same shape as [out_features].

We must also handle the training/eval mode? Actually, in the forward pass of the model, the batch norm module handles that internally. We are using the batch norm module, so we don't need to worry about that in the kernel.

However, the kernel must use the current state of the batch norm parameters (which are updated during training). So we pass them as arguments.

But note: the batch norm module's parameters (weight, bias, etc.) are updated by an optimizer. We are passing them to the kernel, so the kernel will use the updated values.

Implementation of the Triton kernel:

We'll write a kernel that processes the input in 2D. We can use a grid of (batch_size, out_features) but that might be too many threads. Instead, we can use a 1D grid and have each thread handle a contiguous block of elements? Or we can use 2D blocks.

Alternatively, we can flatten the input and process it as a 1D array. Then we can use a 1D grid.

Steps for the kernel:

1. Each program will handle a range of elements. We'll use a 1D grid.

2. We'll compute the indices (i, j) from the 1D index. But note: the input is 2D. So:

   total_elements = batch_size * out_features

3. We'll have a loop over the elements in the block.

4. For each element at position idx (in the flattened array):
   i = idx // out_features
   j = idx % out_features

5. Then we do the computation.

But note: the batch norm parameters are of size out_features, so we can index them with j.

We'll write the kernel accordingly.

However, the problem says: "Use CUDA/Triton/custom kernels if useful." and we are replacing the scaling step. The batch norm is already in PyTorch. So we are using a custom kernel for the scaling step? That might not be useful, but for demonstration it's acceptable.

Alternatively, we can write a kernel that fuses the scaling and batch norm to avoid the intermediate storage. That would be more efficient. But the problem doesn't specify.

Given the ambiguity, we'll do the scaling in a Triton kernel and leave the batch norm as is.

But note: the reference model does:

x = self.gemm(x)
x = x * self.scale
x = self.bn(x)

We are replacing the `x * self.scale` with a Triton kernel. Then we call `self.bn(x)`.

This is two steps. Alternatively, we could fuse them into one kernel to save memory. However, the problem doesn't require fusion.

We'll proceed with the two-step approach for clarity.

Now, let's code:

We need to define the Triton kernel for scaling.

But note: the scaling is element-wise and independent per feature. We can also do it with PyTorch, but we are to demonstrate Triton.

Kernel for scaling:

We'll write a kernel that takes:
- input tensor (after gemm)
- scale tensor (1D of size out_features)
- output tensor (same shape as input)

But wait, the batch norm will be applied next. So we don't need to store the scaled tensor? Actually, we are going to pass the scaled tensor to the batch norm. So we can either:

Option A: Compute the scaled tensor with Triton and then call self.bn on it.
Option B: Fuse scaling and batch norm in one kernel and output the batch norm result.

We'll do Option A for clarity, even though it uses extra memory for the scaled tensor.

Alternatively, we can write a kernel that does both scaling and batch norm without storing the intermediate scaled tensor. That would be more efficient. But let's do Option A for now.

So:

Step 1: Compute scaled = triton_scale(input, scale)
Step 2: scaled = self.bn(scaled)

But note: the batch norm module expects a 3D tensor (for BatchNorm1d) if the input is 2D? Actually, BatchNorm1d expects input of shape (N, C) where N is batch size and C is channels (features). It works on the last dimension.

So our input to batch norm is 2D, which is acceptable.

Now, let's write the Triton kernel for scaling.

We'll name it `triton_scale`.

Kernel signature:

@triton.jit
def triton_scale_kernel(
    input_ptr, scale_ptr, output_ptr,
    n
