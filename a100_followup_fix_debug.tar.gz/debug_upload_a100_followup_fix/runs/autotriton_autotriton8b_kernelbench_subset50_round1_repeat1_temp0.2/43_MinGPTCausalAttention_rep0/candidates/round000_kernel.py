@triton.jit
def softmax_kernel(output_ptr, input_ptr, input_row_stride, output_row_stride, n_cols, BLOCK_SIZE: tl.constexpr):
    # The rows are independent, so we get the program ID for the row.
    row_idx = tl.program_id(0)
    # The stride to get to the start of the row of input
    row_start_ptr = input_ptr + row_idx * input_row_stride
    # The stride to get to the start of the row of output
    row_start_out_ptr = output_ptr + row_idx * output_row_stride
    # Create an offset for the columns
    col_offsets = tl.arange(0, BLOCK_SIZE)
    # Initialize an array to hold the row data
    row = tl.zeros([BLOCK_SIZE], dtype=tl.float32)
    # Loop over the row in chunks of BLOCK_SIZE
    for i in range(0, n_cols, BLOCK_SIZE):
        cols = i + col_offsets
        mask = cols < n_cols
        ptr = row_start_ptr + cols
        # Load a block of data
        values = tl.load(ptr, mask=mask, other=-float('inf'))
        row = tl.where(mask, values, row)
    # Subtract maximum for numerical stability
    row_minus_max = row - tl.max(row, axis=0)
    # Compute exponentials
    numerator = tl.exp(row_minus_max)
    # Sum exponentials
    denominator = tl.sum(numerator, axis=0)
    softmax_output = numerator / denominator
    # Write back
    for i in range(0, n_cols, BLOCK_SIZE):
        cols = i + col_offsets
        mask = cols < n_cols
        ptr = row_start_out_ptr + cols
        tl.store(ptr, softmax_output, mask=mask)
