import torch
import torch.nn as nn
import torch.nn.functional as F

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, output_padding: int = 0, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        # We don't need to create a ConvTranspose2d layer because we are using F.conv_transpose2d in forward.
        # However, we might need to store the parameters for the operation? Actually, F.conv_transpose2d requires the same arguments.
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.output_padding = output_padding
        self.groups = groups
        self.bias = bias

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Performs the transposed 2D convolution using PyTorch's functional API.

        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_channels, height, width).

        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_channels, height_out, width_out).
        """
        return F.conv_transpose2d(x, None,  # weight is None because we don't have a ConvTranspose2d layer; instead we use the arguments?
                                  self.out_channels,  # This is the second argument of F.conv_transpose2d: in_channels? 
                                  stride=self.stride, 
                                  padding=self.padding, 
                                  output_padding=self.output_padding, 
                                  groups=self.groups, 
                                  bias=self.bias)
