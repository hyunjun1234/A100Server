import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_mul_kernel(
    A_ptr,
    C_ptr,
    s,
    numel,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < numel
    a = tl.load(A_ptr + offsets, mask=mask)
    c = a * s
    tl.store(C_ptr + offsets, c, mask=mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, s: float) -> torch.Tensor:
        assert A.is_cuda, "Input tensor must be on CUDA"
        C = torch.empty_like(A)
        numel = A.numel()
        BLOCK_SIZE = 1024
        grid = lambda meta: (triton.cdiv(numel, meta['BLOCK_SIZE']),)
        triton_mul_kernel[grid](A, C, s, numel, BLOCK_SIZE=BLOCK_SIZE)
        return C
