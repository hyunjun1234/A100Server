import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def conv_transpose2d_kernel(
    input_ptr, weight_ptr, bias_ptr, output_ptr,
    ks0, ks1, pad0, pad1, out_pad0, out_pad1,
    in_channels, out_channels, kernel_h, kernel_w,
    input_h, input_w, output_h, output_w,
    batch_size, groups, bias_flag,
    BLOCK_SIZE: tl.constexpr
):
    pid = tl.program_id(0)
    num_pid = tl.num_programs(0)
    total_elements = batch_size * out_channels * output_h * output_w
    start_idx = pid * BLOCK_SIZE
    offsets = start_idx + tl.arange(0, BLOCK_SIZE)
    mask = offsets < total_elements

    # Calculate indices
    b = offsets // (out_channels * output_h * output_w)
    oc_oh_ow = offsets % (out_channels * output_h * output_w)
    oc = oc_oh_ow // (output_h * output_w)
    oh_ow = oc_oh_ow % (output_h * output_w)
    oh = oh_ow // output_w
    ow = oh_ow % output_w

    # Initialize accumulator
    acc = tl.zeros((BLOCK_SIZE,), dtype=tl.float32)

    # Group iteration
    for g in range(0, groups):
        ic = g
        for kh in range(0, kernel_h):
            for kw in range(0, kernel_w):
                ih = oh * ks0 - pad0 + kh
                iw = ow * ks1 - pad1 + kw
                if ih >= 0 and ih < input_h and iw >= 0 and iw < input_w:
                    input_offset = b * in_channels * input_h * input_w + ic * input_h * input_w + ih * input_w + iw
                    weight_offset = oc * kernel_h * kernel_w * in_channels + ic * kernel_h * kernel_w + kh * kernel_w + kw
                    input_val = tl.load(input_ptr + input_offset, mask=mask, other=0.0)
                    weight_val = tl.load(weight_ptr + weight_offset, mask=mask, other=0.0)
                    acc += input_val * weight_val

    # Bias addition
    if bias_flag:
        bias_offset = oc
        bias_val = tl.load(bias_ptr + bias_offset, mask=mask, other=0.0)
        acc += bias_val

    # Store result
    output_offset = offsets
    tl.store(output_ptr + output_offset, acc, mask=mask)

class ModelNew(nn.Module):
    """
    Performs a transposed 2D convolution with a square input and an asymmetric kernel using a custom Triton kernel.

    Args:
        in_channels (int): Number of channels in the input tensor.
        out_channels (int): Number of channels produced by the convolution.
        kernel_size (tuple): Size of the convolution kernel (height, width).
        stride (int, optional): Stride of the convolution. Defaults to 1.
        padding (int or tuple, optional): Padding applied to the input. Defaults to 0.
        output_padding (int or tuple, optional): Additional size added to one side of the output shape. Defaults to 0.
        groups (int, optional): Number of blocked
