import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_min_sub_kernel(x_ptrs, out_ptrs, xnumel, c, XBLOCK : tl.constexpr):
    pid = tl.program_id(0) 
    offsets = pid * XBLOCK + tl.arange(0, XBLOCK)[:]
    x_mask = offsets < xnumel
    x = tl.load(x_ptrs + offsets, mask=x_mask)
    min_val = tl.minimum(x, c)
    result = min_val - c
    tl.store(out_ptrs + offsets, result, mask=x_mask)

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, constant):
        super(ModelNew, self).__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.constant = nn.Parameter(torch.tensor(constant))

    def forward(self, x):
        x = self.linear(x)
        output = torch.empty_like(x)
        XBLOCK = 1024
        grid = (triton.cdiv(x.numel(), XBLOCK),)
        triton_min_sub_kernel[grid](x, output, x.numel(), self.constant.item(), XBLOCK)
        return output
