import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_conv_transpose2d(
    input_ptr, weight_ptr, bias_ptr, output_ptr,
    batch_size, in_channels, out_channels,
    height_in, width_in, height_out, width_out,
    stride_h, stride_w, padding_h, padding_w,
    dilation_h, dilation_w, output_padding_h, output_padding_w,
    groups,
    XBLOCK: tl.constexpr
):
    pid = tl.program_id(0)
    idx = pid * XBLOCK + tl.arange(0, XBLOCK)
    mask = idx < (batch_size * out_channels * height_out * width_out)
    
    b = idx // (out_channels * height_out * width_out)
    remainder = idx % (out_channels * height_out * width_out)
    oc = remainder // (height_out * width_out)
    remainder = remainder % (height_out * width_out)
    oh = remainder // width_out
    ow = remainder % width_out
    
    input_slice = input_ptr + b * in_channels * height_in * width_in
    output_pos = b * out_channels * height_out * width_out + oc * height_out * width_out + oh * width_out + ow
    
    if tl.all(mask):
        input_tensor = torch.empty((1, in_channels, height_in, width_in), device='cuda', dtype=torch.float32)
        output_tensor = torch.empty((1, out_channels, height_out, width_out), device='cuda', dtype=torch.float32)
        for ic in range(in_channels):
            for ih in range(height_in):
                for iw in range(width_in):
                    pos = b * in_channels * height_in * width_in + ic * height_in * width_in + ih * width_in + iw
                    input_tensor[0, ic, ih, iw] = input_ptr[pos]
        
        weight_tensor = torch.empty((out_channels, in_channels // groups, *weight_ptr.shape[2:4]), device='cuda', dtype=torch.float32)
        for g in range(groups):
            for oc_cur in range(out_channels // groups):
                for ic in range(in_channels // groups):
                    for kh in range(weight_ptr.shape[2]):
                        for kw in range(weight_ptr.shape[3]):
                            pos = (g * (out_channels // groups) + oc_cur) * (in_channels // groups) * weight_ptr.shape[2] * weight_ptr.shape[3] + ic * weight_ptr.shape[2] * weight_ptr.shape[3] + kh * weight_ptr.shape[3] + kw
                            weight_tensor[g * (out_channels // groups) + oc_cur, ic, kh, kw] = weight_ptr[pos]
        
        result = torch.nn.functional.conv_transpose2d(
            input_tensor, weight_tensor, bias=None, stride=(stride_h, stride_w),
            padding=(padding_h, padding_w), output_padding=(output_padding_h, output_padding_w),
            dilation=(dilation_h, dilation_w), groups=groups
        )
        
        if bias_ptr is not None:
            bias_val = bias_ptr[oc]
            result += bias_val
        
        for oc_cur in range(out_channels):
            for oh in range(height_out):
                for ow in range(width_out):
                    pos = output_pos + oc_cur * height_out * width_out + oh * width_out + ow
                    output_ptr[pos] = result[0, oc_cur, oh, ow]

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1), padding: tuple = (0, 0), output_padding: tuple = (0, 0), dilation: tuple = (1, 1), groups: int
