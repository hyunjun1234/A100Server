import triton
import triton.language as tl

@triton.jit
def avg_pool3d_kernel(
    in_ptr, out_ptr,
    D_in, H_in, W_in,
    C, N,
    D_out, H_out, W_out,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    # Total number of output elements
    total_out = N * C * D_out * H_out * W_out
    if pid >= total_out:
        return

    # Decompose pid into indices (n, c, d, h, w) for the output
    w = pid % W_out
    h = (pid // W_out) % H_out
    d = (pid // (W_out * H_out)) % D_out
    c = (pid // (W_out * H_out * D_out)) % C
    n = pid // (W_out * H_out * D_out * C)

    # Input window boundaries
    d_start = d * 2
    h_start = h * 2
    w_start = w * 2

    # Accumulate the sum
    acc = 0.0
    for di in range(2):
        for hi in range(2):
            for wi in range(2):
                di_in = d_start + di
                hi_in = h_start + hi
                wi_in = w_start + wi
                # Compute input offset
                in_offset = n * (C*D_in*H_in*W_in) + c * (D_in*H_in*W_in) + di_in * (H_in*W_in) + hi_in * (W_in) + wi_in
                val = tl.load(in_ptr + in_offset)
                acc += val

    avg = acc / 8.0
    # Write back
    out_offset = pid
    tl.store(out_ptr + out_offset, avg)
