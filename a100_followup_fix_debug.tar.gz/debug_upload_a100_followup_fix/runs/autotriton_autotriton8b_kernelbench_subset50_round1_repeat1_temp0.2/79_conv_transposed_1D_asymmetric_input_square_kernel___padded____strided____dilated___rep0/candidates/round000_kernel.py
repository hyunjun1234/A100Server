class ModelNew(nn.Module):
         def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, bias: bool = False):
             super().__init__()
             self.in_channels = in_channels
