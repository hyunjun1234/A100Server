class ModelNew(nn.Module):
        def __init__(self):
            super().__init__()

        def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
            # Check that A and B are on CUDA
            assert A.is_cuda and B.is_cuda, "Inputs must be on CUDA"
            # Check that they are contiguous
            if not A.is_contiguous():
                A = A.contiguous()
            if not B.is_contiguous():
                B = B.contiguous()
            M, K = A.shape
            K2, N = B.shape
            assert K == K2, "Incompatible dimensions"
            # Allocate output
            C = torch.empty((M, N), device=A.device, dtype=A.dtype)
            # If the matrix is too small, we can use a fallback (but the problem size is large, so we use the kernel)
            # Define block sizes
            BLOCK_SIZE_M = 64
            BLOCK_SIZE_N = 64
            BLOCK_SIZE_K = 32
            # Grid size
            grid = (triton.cdiv(M, BLOCK_SIZE_M), triton.cdiv(N, BLOCK_SIZE_N))
            # Launch kernel
            triton_matmul[grid](
                A, B, C,
                M, N, K,
                A.stride(0), A.stride(1),
                B.stride(0), B.stride(1),
                C.stride(0), C.stride(1),
                BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K,
                GROUP_SIZE_M=8  # tutorial uses 8, but we don't use L2 tiling so it doesn't matter
            )
            return C

But note: the kernel definition must be included.

However, there is a catch: the tutorial kernel uses shared memory and registers efficiently. We are following it word-for-word.

But note: the tutorial kernel also has a loop over K. We'll include that.

Let's write the kernel in full:

    @triton.jit
    def triton_matmul(
        # Pointers to matrices
        a_ptr, b_ptr, c_ptr,
        # Matrix dimensions
        M, N, K,
        # Strides
        stride_am, stride_ak,
        stride_bk, stride_bn,
        stride_cm, stride_cn,
        # Block sizes
        BLOCK_SIZE_M: tl.constexpr
