import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def gelu_kernel(
    x_ptr,
    out_ptr,
    n_elements,
    XBLOCK : tl.constexpr,
):
    pid = tl.program_id(0)
    block_start = pid * XBLOCK
    offsets = block_start + tl.arange(0, XBLOCK)
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask)
    
    sqrt_2_over_pi = 0.7978845608028654
    cubed = x * x * x
    inner = x + 0.044715 * cubed
    scaled = inner * sqrt_2_over_pi
    tanh_scaled = tl.tanh(scaled)
    gelu = 0.5 * x * (1.0 + tanh_scaled)
    
    tl.store(out_ptr + offsets, gelu, mask=mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, x):
        assert x.is_cuda, "Input must be on CUDA"
        output = torch.empty_like(x)
        n_elements = output.numel()
        grid = lambda meta: (triton.cdiv(n_elements, meta['XBLOCK']),)
        gelu_kernel[grid](x, output, n_elements, XBLOCK=1024)
        return output
