import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_cumsum(input_ptr, output_ptr, stride, numel, XBLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offsets = pid * XBLOCK + tl.arange(0, XBLOCK)
    mask = offsets < numel
    
    x = tl.load(input_ptr + offsets, mask=mask, other=0.0)
    acc = 0.0
    for i in range(0, XBLOCK):
        idx = offsets[i]
        if idx < numel:
            current = tl.load(input_ptr + idx)
            acc += current
            tl.store(output_ptr + idx, acc)

class ModelNew(nn.Module):
    def __init__(self, dim):
        super(ModelNew, self).__init__()
        self.dim = dim

    def forward(self, x):
        if self.dim != 1:
            return torch.cumsum(x, dim=self.dim)
        
        original_shape = x.shape
        x_flat = x.flatten(1)
        batch_size, seq_len = x_flat.shape
        
        output = torch.empty_like(x_flat)
        numel = x_flat.numel()
        XBLOCK = 1024
        grid = (triton.cdiv(numel, XBLOCK),)
        
        triton_cumsum[grid](x_flat, output, seq_len, numel, XBLOCK)
        return output.view(original_shape)
