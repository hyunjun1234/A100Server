<think>
We are given a reference model that uses `torch.bmm` for batched matrix multiplication.
The task is to create a new model `ModelNew` that also performs batched matrix multiplication, but using Triton for better performance.
We note that the input tensors are 3D: (batch_size, m, k) and (batch_size, k, n), and the output is (batch_size, m, n).

Steps:
1. We will write a Triton kernel that performs batched matrix multiplication.
2. The kernel will launch one program for each batch element? Or we can process multiple batches in parallel?
   However, note that the batch dimension is the first dimension. We can have each block handle one batch element? But that might not be efficient if batch_size is large and we have many blocks. Alternatively, we can process multiple batches and multiple rows/columns in a block.

But note: The problem says to optimize using Triton. We can follow the tutorial on matrix multiplication in Triton, but extend it to batched.

In the tutorial, they have a matrix multiplication kernel that uses tiling. We can do the same for each batch.

We'll design the kernel as follows:
- We have three tensors: A, B, and C.
- Each program will compute a block of C for a specific batch index, and a specific tile of the matrix.

However, note that the batch dimension is the first dimension. We can iterate over batches in the kernel? Or we can launch a grid of (batch_size, num_blocks_m, num_blocks_n) and each block computes a tile for a specific batch.

But Triton's grid is 3D. We can set:
  grid = (batch_size, triton.cdiv(m, BLOCK_SIZE_M), triton.cdiv(n, BLOCK_SIZE_N))

But note: the total number of blocks might be too high if batch_size is large? Alternatively, we can process multiple batches in a single block? That might complicate the kernel.

Alternatively, we can have each program handle one batch and one tile? That would be:
  grid = (batch_size, triton.cdiv(m, BLOCK_SIZE_M), triton.cdiv(n, BLOCK_SIZE_N))

This is acceptable if batch_size is not too large (e.g., up to 10000) and the number of tiles in m and n is not too large.

But note: the problem says the batch_size is 128, m=128*4=512, k=256*4=1024, n=512*4=2048.

We can choose BLOCK_SIZE_M = 64, BLOCK_SIZE_N = 64, then the number of tiles in m: 512/64=8, n:2048/64=32. So grid = (128,8,32) -> 128*8*32 = 32768 blocks. That is acceptable.

So the plan:
- Write a Triton kernel that takes A, B, C, batch_size, m, n, k, and the strides for A, B, C.
- The kernel will use program_id(0) for the batch index, program_id(1) for the row block index (over m), program_id(2) for the column block index (over n).
- Then, each block will compute a tile of size [BLOCK_SIZE_M, BLOCK_SIZE_N] in the output matrix for the given batch.

However, note that the matrices A and B for a given batch have shapes (m, k) and (k, n) respectively. We must be cautious about the shared memory usage: we need to load a block of A (of size BLOCK_SIZE_M * BLOCK_SIZE_K) and a block of B (of size BLOCK_SIZE_K * BLOCK_SIZE_N) into shared memory. But note that BLOCK_SIZE_M and BLOCK_SIZE_N are the output tile dimensions, and BLOCK_SIZE_K is the inner dimension (k). We might need to tune the block sizes.

Alternatively, we can use the same kernel as the matrix multiplication tutorial but wrap it in a loop over batches? But the tutorial kernel is for a single matrix multiplication.

We can modify the tutorial kernel to handle a batch by having an extra dimension in the grid for the batch.

Let's follow the tutorial: https://triton-lang.org/main/getting-started/tutorials/03-matrix-multiplication.html

In the tutorial, they have:
  pid = tl.program_id(axis=0)
  num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
  num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
