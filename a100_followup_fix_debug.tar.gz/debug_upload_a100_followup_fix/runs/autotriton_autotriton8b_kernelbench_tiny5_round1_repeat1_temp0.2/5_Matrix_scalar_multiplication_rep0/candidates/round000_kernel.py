import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_mul_kernel(a_ptr, c_ptr, s, xnumel, XBLOCK: tl.constexpr):
    pid = tl.program_id(0)
    offsets = pid * XBLOCK + tl.arange(0, XBLOCK)[:]
