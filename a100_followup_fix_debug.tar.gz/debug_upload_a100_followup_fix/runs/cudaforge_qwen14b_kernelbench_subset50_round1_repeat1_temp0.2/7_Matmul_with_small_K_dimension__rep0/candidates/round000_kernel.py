import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs a single matrix multiplication (C = A * B) with a small K dimension.
    This version includes some optimizations for better performance.
    """
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs matrix multiplication with some optimizations.

        Args:
            A: Input tensor of shape (M, K).
            B: Input tensor of shape (K, N).

        Returns:
            Output tensor of shape (M, N).
        """
        # Ensure the input tensors are on the same device
        A, B = A.to(B.device), B.to(A.device)
        
        # Use torch.bmm for batch matrix multiplication if applicable
        if A.dim() == 3 and B.dim() == 3:
            return torch.bmm(A, B)
        
        # Use torch.matmul for standard matrix multiplication
        return torch.matmul(A, B)

M = 16384 * 2
N = 16384 * 2
K = 32 * 2

def get_inputs():
    A = torch.rand(M, K)
    B = torch.rand(K, N)
    return [A, B]

def get_init_inputs():
    return []  # No special initialization inputs needed