import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


def _to_3tuple(x):
    if isinstance(x, (list, tuple)):
        assert len(x) == 3
        return tuple(int(v) for v in x)
    return (int(x), int(x), int(x))


def _ceil_div(a, b):
    return (a + b - 1) // b


def _dtype_size(dtype):
    if dtype == torch.float32:
        return 4
    if dtype == torch.float16:
        return 2
    if dtype == torch.bfloat16:
        return 2
    # default
    return 4


def _conv2d_nchw_fused_weight_1x1_bias(weight, bias):
    # weight: [Cout, Cin, 1, 1] -> [Cout, Cin]
    w = weight.view(weight.shape[0], weight.shape[1])
    if bias is not None:
        b = bias.view(-1)
    else:
        b = torch.zeros(w.shape[0], device=w.device, dtype=w.dtype)
    return w, b


def _conv2d_nchw_fused_weight_kxk(weight, bias, k):
    # weight: [Cout, Cin, k, k] -> [Cout, Cin*k*k]
    w = weight.view(weight.shape[0], weight.shape[1] * k * k)
    if bias is not None:
        b = bias.view(-1)
    else:
        b = torch.zeros(w.shape[0], device=w.device, dtype=w.dtype)
    return w, b


def _conv2d_nchw_fused_weight_depthwise_kxk(weight, bias, k):
    # weight: [Cout, Cin=groups, k, k] -> [Cout, k*k] per group
    # but we keep it as [Cout, Cin*k*k] with groups=Cin
    w = weight.view(weight.shape[0], weight.shape[1] * k * k)
    if bias is not None:
        b = bias.view(-1)
    else:
        b = torch.zeros(w.shape[0], device=w.device, dtype=w.dtype)
    return w, b


def _conv2d_nchw_fused_weight_expand_1x1(weight, bias):
    # expand: [hidden, in, 1,1] -> [hidden, in]
    w = weight.view(weight.shape[0], weight.shape[1])
    if bias is not None:
        b = bias.view(-1)
    else:
        b = torch.zeros(w.shape[0], device=w.device, dtype=w.dtype)
    return w, b


def _conv2d_nchw_fused_weight_project_1x1(weight, bias):
    # project: [out, hidden, 1,1] -> [out, hidden]
    w = weight.view(weight.shape[0], weight.shape[1])
    if bias is not None:
        b = bias.view(-1)
    else:
        b = torch.zeros(w.shape[0], device=w.device, dtype=w.dtype)
    return w, b


def _conv2d_nchw_fused_weight_linear(weight, bias):
    # linear: [num_classes, Cout] keep as is
    return weight, bias


def _conv2d_nchw_fused_weight_shape(weight):
    # returns (Cout, Cin, k, k) or (Cout, Cin, 1, 1)
    return weight.shape


def _conv2d_nchw_fused_bias(weight, bias):
    return bias if bias is not None else torch.zeros(weight.shape[0], device=weight.device, dtype=weight.dtype)


def _conv2d_nchw_fused_conv1x1_bias(x, w, b, stride, padding, out_c, out_h, out_w, device, dtype):
    # x: [N, C, H, W], w: [OC, IC], b: [OC]
    N, C, H, W = x.shape
    OC = out_c
    assert C == w.shape[1], f"Conv1x1: in_channels {C} != weight in_channels {w.shape[1]}"
    assert OC == w.shape[0], f"Conv1x1: out_channels {OC} != weight out_channels {w.shape[0]}"
    y = torch.zeros((N, OC, out_h, out_w), device=device, dtype=dtype)
    # simple matmul per pixel
    # y[n, oc, oh, ow] = sum_ic w[oc, ic] * x[n, ic, oh, ow]
    for oh in range(out_h):
        for ow in range(out_w):
            x_tile = x[:, :, oh:oh+1, ow:ow+1].reshape(N, C)  # [N, C]
            # [N, OC] = [N, C] @ [OC, C]^T => wrong, need [N,C] @ [C,OC]
            w_t = w.t().contiguous()  # [IC, OC]
            y_tile = x_tile.matmul(w_t)  # [N, OC]
            y[:, :, oh, ow] = y_tile + b.view(1, -1)
    return y


def _conv2d_nchw_fused_depthwise_kxk(x, w, b, stride, padding, out_c, out_h, out_w, device, dtype, k):
    # x: [N, C, H, W], w: [C, k*k]  groups=C
    N, C, H, W = x.shape
    assert out_c == C, f"Depthwise: out_c {out_c} != in_c {C}"
    y = torch.zeros((N, C, out_h, out_w), device=device, dtype=dtype)
    # for each (n, c, oh, ow): sum over kk
    for n in range(N):
        for c in range(C):
            for oh in range(out_h):
                for ow in range(out_w):
                    # compute input top-left
                    ih0 = oh * stride - padding
                    iw0 = ow * stride - padding
                    s = 0.0
                    for kh in range(k):
                        ih = ih0 + kh
                        valid_h = (ih >= 0) and (ih < H)
                        for kw in range(k):
                            iw = iw0 + kw
                            valid_w = (iw >= 0) and (iw < W)
                            if valid_h and valid_w:
                                s += float(x[n, c, ih, iw]) * float(w[c, kh * k + kw])
                    y[n, c, oh, ow] = s + float(b[c])
    return y


def _conv2d_nchw_fused_expand_1x1(x, w, b, out_c, out_h, out_w, device, dtype):
    # x: [N, C, H, W], w: [hidden, C], b: [hidden]
    N, C, H, W = x.shape
    hidden = out_c
    y = torch.zeros((N, hidden, out_h, out_w), device=device, dtype=dtype)
    # pointwise: y = x @ w^T + b
    w_t = w.t().contiguous()  # [C, hidden]
    for oh in range(out_h):
        for ow in range(out_w):
            x_tile = x[:, :, oh:oh+1, ow:ow+1].reshape(N, C)  # [N, C]
            y_tile = x_tile.matmul(w_t)  # [N, hidden]
            y[:, :, oh, ow] = y_tile + b.view(1, -1)
    return y


def _conv2d_nchw_fused_project_1x1(x, w, b, out_c, out_h, out_w, device, dtype):
    # x: [N, hidden, H, W], w: [out, hidden], b: [out]
    N, hidden, H, W = x.shape
    out = out_c
    y = torch.zeros((N, out, out_h, out_w), device=device, dtype=dtype)
    w_t = w.t().contiguous()  # [hidden, out]
    for oh in range(out_h):
        for ow in range(out_w):
            x_tile = x[:, :, oh:oh+1, ow:ow+1].reshape(N, hidden)  # [N, hidden]
            y_tile = x_tile.matmul(w_t)  # [N, out]
            y[:, :, oh, ow] = y_tile + b.view(1, -1)
    return y


def _conv2d_nchw_fused_linear(x, w, b, device, dtype):
    # x: [N, C], w: [num_classes, C]
    N, C = x.shape
    num_classes = w.shape[0]
    y = torch.zeros((N, num_classes), device=device, dtype=dtype)
    w_t = w.t().contiguous()  # [C,
