import math
import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


def _next_power_of_two(x: int) -> int:
    return 1 if x <= 1 else 1 << (x - 1).bit_length()


@triton.jit
def _fused_linear_scale_bn_infer_kernel(
    X,            # [M, K] float32
    W,            # [N, K] float32 (nn.Linear weight)
    BIAS,         # [N] float32 (nn.Linear bias)
    SCALE,        # [N] float32
    MEAN,         # [N] float32 (running_mean)
    VAR,          # [N] float32 (running_var)
    Y,            # [M, N] float32
    M: tl.constexpr,
    N: tl.constexpr,
    K: tl.constexpr,
    stride_xm: tl.constexpr, stride_xk: tl.constexpr,
    stride_wn: tl.constexpr, stride_wk: tl.constexpr,
    stride_ym: tl.constexpr, stride_yn: tl.constexpr,
    eps: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * 128 + tl.arange(0, 128)
    offs_n = pid_n * 128 + tl.arange(0, 128)
    offs_k = tl.arange(0, 64)

    # Create pointers for the first K-tile
    x_ptrs = X + (offs_m[:, None] * stride_xm) + (offs_k[None, :] * stride_xk)
    w_ptrs = W + (offs_n[:, None] * stride_wn) + (offs_k[None, :] * stride_wk)

    acc = tl.zeros((128, 128), dtype=tl.float32)

    # Loop over K dimension
    for k in range(0, K, 64):
        k_mask = (k + offs_k) < K
        x = tl.load(x_ptrs, mask=k_mask[None, :], other=0.0)
        w = tl.load(w_ptrs, mask=k_mask[None, :], other=0.0)
        # acc += x @ w.T : (128,64) @ (64,128) -> (128,128)
        acc += tl.dot(x, tl.trans(w))
        x_ptrs += 64 * stride_xk
        w_ptrs += 64 * stride_wk

    # Add bias
    bias = tl.load(BIAS + offs_n, mask=offs_n < N, other=0.0)
    acc = acc + bias[None, :]

    # Scale
    scale = tl.load(SCALE + offs_n, mask=offs_n < N, other=1.0)
    acc = acc * scale[None, :]

    # BN inference: y = ((x * scale) - mean) / sqrt(var + eps)
    mean = tl.load(MEAN + offs_n, mask=offs_n < N, other=0.0)
    var = tl.load(VAR + offs_n, mask=offs_n < N, other=1.0)
    rstd = 1.0 / tl.sqrt(var + eps)
    acc = (acc - mean[None, :]) * rstd[None, :]

    # Store
    y_ptrs = Y + (offs_m[:, None] * stride_ym) + (offs_n[None, :] * stride_yn)
    m_mask = offs_m < M
    n_mask = offs_n < N
    mask = m_mask[:, None] & n_mask[None, :]
    tl.store(y_ptrs, acc, mask=mask)


class ModelNew(nn.Module):
    """
    Fused version of:
      x = linear(x)          # GEMM + bias
      x = x * scale          # elementwise scale
      x = bn(x)              # batch-norm (eval mode)

    Notes:
    - Uses a single Triton kernel in eval mode.
    - Falls back to PyTorch ops if Triton is unavailable or if training (running stats).
    """
    def __init__(self, in_features, out_features, scale_shape, eps=1e-5, momentum=0.1):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.scale = nn.Parameter(torch.randn(scale_shape))
        self.bn = nn.BatchNorm1d(out_features, eps=eps, momentum=momentum)
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Ensure CUDA
        if not x.is_cuda:
            raise RuntimeError("ModelNew requires CUDA tensors.")
        device = x.device

        M, K = x.shape
        N = self.linear.out_features

        # If training or Triton not available, fall back to PyTorch path
        use_triton = TRITON_AVAILABLE and (not self.bn.training)

        if not use_triton:
            # PyTorch path: linear -> scale -> bn
            y = self.linear(x)
            y = y * self.scale
            y = self.bn(y)
            return y

        # Shapes and dtypes
        # Use float32 throughout to match the provided code
        x_f = x.to(torch.float32)
        w_f = self.linear.weight.to(torch.float32)   # [N, K]
        b_f = self.linear.bias.to(torch.float32)     # [N]
        scale_f = self.scale.to(torch.float32)       # [N]
        running_mean = self.bn.running_mean.to(torch.float32)  # [N]
        running_var = self.bn.running_var.to(torch.float32)    # [N]

        # Allocate output
        y = torch.empty((M, N), device=device, dtype=torch.float32)

        # Strides (row-major)
        stride_xm, stride_xk = x_f.stride(0), x_f.stride(1)
        stride_wn, stride_wk = w_f.stride(0), w_f.stride(1)
        stride_ym, stride_yn = y.stride(0), y.stride(1)

        # Grid
        grid = (_next_power_of_two(M) // 128, _next_power_of_two(N) // 128)

        _fused_linear_scale_bn_infer_kernel(
            x_f, w_f, b_f, scale_f, running_mean, running_var, y,
            M, N, K,
            stride_xm, stride_xk,
            stride_wn, stride_wk,
            stride_ym, stride_yn,
            self.eps,
            num_warps=4,
            num_stages=2,
            grid=grid,
        )

        return y
