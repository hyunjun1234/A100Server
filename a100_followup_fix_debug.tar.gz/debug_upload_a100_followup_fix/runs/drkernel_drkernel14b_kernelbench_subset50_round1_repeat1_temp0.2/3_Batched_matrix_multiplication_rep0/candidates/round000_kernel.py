import math
import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


# Autotuned Triton kernel for batched matmul: C[b, m, n] = sum_k A[b, m, k] * B[b, k, n]
@triton.autotune(
    configs=[
        triton.Config({'BLOCK_M': 64,  'BLOCK_N': 64,  'BLOCK_K': 32}, num_warps=4, num_stages=3),
        triton.Config({'BLOCK_M': 128, 'BLOCK_N': 64,  'BLOCK_K': 32}, num_warps=4, num_stages=3),
        triton.Config({'BLOCK_M': 64,  'BLOCK_N': 128, 'BLOCK_K': 32}, num_warps=4, num_stages=3),
        triton.Config({'BLOCK_M': 128, 'BLOCK_N': 128, 'BLOCK_K': 32}, num_warps=8, num_stages=4),
        triton.Config({'BLOCK_M': 64,  'BLOCK_N': 256, 'BLOCK_K': 32}, num_warps=8, num_stages=4),
        triton.Config({'BLOCK_M': 256, 'BLOCK_N': 64,  'BLOCK_K': 32}, num_warps=8, num_stages=4),
    ],
    key=['M', 'N', 'K'],
)
@triton.jit
def _bmm_kernel(
    A, B, C,
    BATCH: tl.constexpr, M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
    stride_ab, stride_am, stride_ak,
    stride_bb, stride_bk, stride_bn,
    stride_cb, stride_cm, stride_cn,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
):
    pid_b = tl.program_id(0)
    pid_m = tl.program_id(1)
    pid_n = tl.program_id(2)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # Pointers for A and B tiles
    A_ptrs = A + pid_b * stride_ab + (offs_m[:, None] * stride_am) + (offs_k[None, :] * stride_ak)
    B_ptrs = B + pid_b * stride_bb + (offs_k[:, None] * stride_bk) + (offs_n[None, :] * stride_bn)

    # Accumulator
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    # Loop over K dimension
    for k in range(0, K, BLOCK_K):
        a = tl.load(
            A_ptrs,
            mask=(offs_m[:, None] < M) & (k + offs_k[None, :] < K),
            other=0.0,
        )
        b = tl.load(
            B_ptrs,
            mask=(k + offs_k[:, None] < K) & (offs_n[None, :] < N),
            other=0.0,
        )
        # Accumulate
        acc += tl.dot(a, b)
        # Advance pointers
        A_ptrs += BLOCK_K * stride_ak
        B_ptrs += BLOCK_K * stride_bk

    # Write back
    C_ptrs = C + pid_b * stride_cb + (offs_m[:, None] * stride_cm) + (offs_n[None, :] * stride_cn)
    tl.store(
        C_ptrs,
        acc,
        mask=(offs_m[:, None] < M) & (offs_n[None, :] < N),
    )


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()
        if not TRITON_AVAILABLE:
            # Fallback will be used automatically in forward
            pass

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs batched matrix multiplication: C = A @ B
        Shapes:
            A: (B, M, K)
            B: (B, K, N)
            C: (B, M, N)
        All tensors must be CUDA and float32 for this optimized path.
        """
        assert A.dim() == 3 and B.dim() == 3, f"Expected 3D tensors, got {A.shape} and {B.shape}"
        Bsz, M, K = A.shape
        Bsz_b, K_b, N = B.shape
        assert Bsz == Bsz_b and K == K_b, f"Incompatible shapes: {A.shape} @ {B.shape}"

        # Ensure CUDA and dtype
        device = A.device
        assert device.type == 'cuda', "Inputs must be CUDA tensors"
        assert B.device == device, "A and B must be on the same device"

        # This kernel is implemented for float32; cast if needed
        if A.dtype != torch.float32:
            A = A.to(torch.float32)
        if B.dtype != torch.float32:
            B = B.to(torch.float32)

        # Allocate output
        C = torch.empty((Bsz, M, N), device=device, dtype=torch.float32)

        # Compute strides (in elements)
        stride_ab, stride_am, stride_ak = A.stride(0), A.stride(1), A.stride(2)
        stride_bb, stride_bk, stride_bn = B.stride(0), B.stride(1), B.stride(2)
        stride_cb, stride_cm, stride_cn = C.stride(0), C.stride(1), C.stride(2)

        # Grid: (batch, M tiles, N tiles)
        def grid(meta):
            return (
                Bsz,
                triton.cdiv(M, meta['BLOCK_M']),
                triton.cdiv(N, meta['BLOCK_N']),
            )

        _bmm_kernel[grid](
            A, B, C,
            Bsz, M, N, K,
            stride_ab, stride_am, stride_ak,
            stride_bb, stride_bk, stride_bn,
            stride_cb, stride_cm, stride_cn,
        )

        return C
