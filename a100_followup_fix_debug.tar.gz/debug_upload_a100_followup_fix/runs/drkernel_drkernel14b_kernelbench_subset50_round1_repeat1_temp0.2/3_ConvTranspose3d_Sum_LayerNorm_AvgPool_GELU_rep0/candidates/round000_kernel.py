import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


def _to_3tuple(x):
    if isinstance(x, (list, tuple)):
        assert len(x) == 3
        return tuple(int(v) for v in x)
    x = int(x)
    return (x, x, x)


def _to_5tuple(x):
    if isinstance(x, (list, tuple)):
        assert len(x) == 5
        return tuple(int(v) for v in x)
    x = int(x)
    return (x, x, x, x, x)


def _to_3tuple_or_none(x):
    if x is None:
        return None
    return _to_3tuple(x)


def _conv_transpose3d_output_shape(x_shape, kernel_size, stride, padding, output_padding):
    N, C_in, D, H, W = x_shape
    kd, kh, kw = kernel_size
    sd, sh, sw = stride
    pd, ph, pw = padding
    ood, ooh, oow = output_padding
    D_out = (D - 1) * sd - 2 * pd + kd + ood
    H_out = (H - 1) * sh - 2 * ph + kh + ooh
    W_out = (W - 1) * sw - 2 * pw + kw + oow
    return N, C_in, D_out, H_out, W_out


def _compute_conv_transpose3d_index(d_out, h_out, w_out, kernel_size, stride, padding):
    kd, kh, kw = kernel_size
    sd, sh, sw = stride
    pd, ph, pw = padding
    di = d_out * sd - pd
    hi = h_out * sh - ph
    wi = w_out * sw - pw
    return di, hi, wi, kd, kh, kw


@triton.jit
def conv_transpose3d_kernel(
    x_ptr, w_ptr, y_ptr,
    N: tl.constexpr, C_in: tl.constexpr, D: tl.constexpr, H: tl.constexpr, W: tl.constexpr,
    C_out: tl.constexpr, KD: tl.constexpr, KH: tl.constexpr, KW: tl.constexpr,
    SD: tl.constexpr, SH: tl.constexpr, SW: tl.constexpr,
    PD: tl.constexpr, PH: tl.constexpr, PW: tl.constexpr,
    D_out: tl.constexpr, H_out: tl.constexpr, W_out: tl.constexpr,
    x_stride_n, x_stride_c, x_stride_d, x_stride_h, x_stride_w,
    w_stride_co, w_stride_ci, w_stride_kd, w_stride_kh, w_stride_kw,
    y_stride_n, y_stride_c, y_stride_d, y_stride_h, y_stride_w,
):
    pid = tl.program_id(0)
    # Map pid to (n, co, d_out, h_out, w_out)
    w_all = W_out
    h_all = H_out * w_all
    d_all = D_out * h_all
    nco_all = C_out * d_all
    n = pid // nco_all
    rem1 = pid % nco_all
    co = rem1 // d_all
    rem2 = rem1 % d_all
    do = rem2 // (H_out * W_out)
    rem3 = rem2 % (H_out * W_out)
    ho = rem3 // W_out
    wo = rem3 % W_out

    # Accumulator
    acc = tl.zeros((), dtype=tl.float32)

    # Compute input base indices for this output position
    di, hi, wi, KD, KH, KW = _compute_conv_transpose3d_index(do, ho, wo, (KD, KH, KW), (SD, SH, SW), (PD, PH, PW))
    # Loop over kernel and input channels
    for kd in range(KD):
        id = di + kd
        for kh in range(KH):
            ih = hi + kh
            for kw in range(KW):
                iw = wi + kw
                # Loop over input channels
                for ci in range(C_in):
                    # x index: n, ci, id, ih, iw
                    x_idx = (
                        n * x_stride_n
                        + ci * x_stride_c
                        + id * x_stride_d
                        + ih * x_stride_h
                        + iw * x_stride_w
                    )
                    # w index: co, ci, kd, kh, kw
                    w_idx = (
                        co * w_stride_co
                        + ci * w_stride_ci
                        + kd * w_stride_kd
                        + kh * w_stride_kh
                        + kw * w_stride_kw
                    )
                    xv = tl.load(x_ptr + x_idx).to(tl.float32)
                    wv = tl.load(w_ptr + w_idx).to(tl.float32)
                    acc += xv * wv

    # Store to y
    y_idx = (
        n * y_stride_n
        + co * y_stride_c
        + do * y_stride_d
        + ho * y_stride_h
        + wo * y_stride_w
    )
    tl.store(y_ptr + y_idx, acc)


def conv_transpose3d_triton(x, w, stride, padding):
    # x: [N, C_in, D, H, W], w: [C_in, C_out, KD, KH, KW]
    assert x.is_cuda and w.is_cuda, "Triton kernel requires CUDA tensors"
    device = x.device
    N, C_in, D, H, W = x.shape
    C_in_w, C_out, KD, KH, KW = w.shape
    assert C_in == C_in_w, f"Weight C_in mismatch: {C_in} vs {C_in_w}"
    SD, SH, SW = _to_3tuple(stride)
    PD, PH, PW = _to_3tuple(padding)
    # Default output_padding = (0,0,0) for this kernel
    OOD, OOH, OOW = 0, 0, 0
    D_out = (D - 1) * SD - 2 * PD + KD + OOD
    H_out = (H - 1) * SH - 2 * PH + KH + OOH
    W_out = (W - 1) * SW - 2 * PW + KW + OOW
    assert D_out > 0 and H_out > 0 and W_out > 0, f"Invalid output shape: {D_out}x{H_out}x{W_out}"

    y = torch.empty((N, C_out, D_out, H_out, W_out), device=device, dtype=torch.float32)

    # Strides
    x_strides = x.stride()
    w_strides = w.stride()
    y_strides = y.stride()

    grid = (N * C_out * D_out * H_out * W_out,)
    conv_transpose3d_kernel[grid](
        x, w, y,
        N, C_in, D, H, W,
        C_out, KD, KH, KW,
        SD, SH, SW,
        PD, PH, PW,
        D_out, H_out, W_out,
        x_strides[0], x_strides[1], x_strides[2], x_strides[3], x_strides[4],
        w_strides[1], w_strides[0], w_strides[2], w_strides[3], w_strides[4],
        y_strides[0], y_strides[1], y_strides[2], y_strides[3], y_strides[4],
        num_warps=4,
        num_stages=2,
    )
    return y


@triton.jit
def add_sum_layernorm_kernel(
    y_ptr, out_ptr,
    N: tl.constexpr, C: tl.constexpr, D: tl.constexpr, H: tl.constexpr, W: tl.constexpr,
    sum_val: tl.constexpr,
    eps: tl.constexpr,
    y_stride_n, y_stride_c, y_stride_d, y_stride_h, y_stride_w,
    out_stride_n, out_stride_c, out_stride_d, out_stride_h, out_stride_w,
):
