import math
import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


# Fused kernel:
# For each (b, h, w): compute s = sum_c log(exp(x[b,c,h,w]) + exp(b[c]))
# Then accumulate acc += s; finally write acc * scale to out[b]
@triton.jit
def _fused_gavg_bias_lse_sum_kernel(
    x_ptr,            # *f32, shape [B, C, H, W]
    bias_ptr,         # *f32, shape [C]
    out_ptr,          # *f32, shape [B]
    B: tl.constexpr,
    C: tl.constexpr,
    H: tl.constexpr,
    W: tl.constexpr,
    stride_b: tl.constexpr,
    stride_c: tl.constexpr,
    stride_h: tl.constexpr,
    stride_w: tl.constexpr,
    scale: tl.constexpr,
):
    pid = tl.program_id(0)
    b = pid
    # guard
    if b >= B:
        return

    # Accumulator for sum over spatial positions of logsumexp
    acc = tl.zeros((), dtype=tl.float32)

    # Loop over h
    for h in range(0, H):
        # Loop over w
        for w in range(0, W):
            # Local sum over channels for this (h, w)
            s = tl.zeros((), dtype=tl.float32)
            # Loop over channels
            for c in range(0, C):
                # x[b, c, h, w]
                offs = b * stride_b + c * stride_c + h * stride_h + w * stride_w
                xv = tl.load(x_ptr + offs)  # f32
                bv = tl.load(bias_ptr + c)  # f32
                z = xv + bv
                e = tl.exp(z)
                s += tl.log(1.0 + e)
            acc += s

    out_val = acc * scale
    tl.store(out_ptr + b, out_val)


class ModelNew(nn.Module):
    """
    Triton-optimized version of the reference model:
    - Keep ConvTranspose2d (cuDNN) for performance/correctness.
    - Fuse global average pooling + bias add + logsumexp + sum + scale into a single Triton kernel.
    """
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape, device=None):
        super(ModelNew, self).__init__()
        self.conv_transpose = nn.ConvTranspose2d(in_channels, out_channels, kernel_size)
        # Keep bias as Parameter to match original
        self.bias = nn.Parameter(torch.randn(bias_shape, device=device))
        # Ensure device alignment
        if device is not None:
            self.to(device)

    def forward(self, x: torch.Tensor):
        # 1) ConvTranspose2d (cuDNN)
        x = self.conv_transpose(x)

        # Expect NCHW
        assert x.dim() == 4, f"Expected 4D NCHW tensor, got shape {tuple(x.shape)}"
        B, C, H, W = x.shape

        # 2) Ensure CUDA + dtype
        if not x.is_cuda:
            raise RuntimeError("ModelNew requires CUDA tensors.")
        if x.dtype != torch.float32:
            x = x.to(torch.float32)
        bias = self.bias
        if bias.dtype != torch.float32:
            bias = bias.to(torch.float32)
        # Ensure bias is on same device and shape [C]
        if bias.device != x.device:
            bias = bias.to(x.device)
        # bias shape in ref is (C,1,1); we only need (C,)
        if bias.dim() == 3:
            assert bias.shape[1] == 1 and bias.shape[2] == 1, "Unexpected bias shape"
            bias = bias.view(C)
        else:
            assert bias.shape == (C,), f"Bias shape must be (C,) or (C,1,1), got {tuple(bias.shape)}"
        # contiguous
        x = x.contiguous()
        bias = bias.contiguous()

        # 3) Launch fused kernel
        out = torch.empty((B,), device=x.device, dtype=torch.float32)

        # Strides for NCHW
        stride_b, stride_c, stride_h, stride_w = x.stride()

        # Scale = 10.0
        scale = 10.0

        grid = (B,)
        _fused_gavg_bias_lse_sum_kernel[grid](
            x, bias, out,
            B, C, H, W,
            stride_b, stride_c, stride_h, stride_w,
            scale,
            num_warps=4,
            num_stages=2,
        )

        return out
