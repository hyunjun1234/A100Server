import math
import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    _HAS_TRITON = True
except Exception:
    _HAS_TRITON = False


# Fused GEMM + bias + Swish + scale
# Computes: C = scale * swish(A @ B + bias)
# Shapes:
#   A: [M, K]
#   B: [K, N]
#   bias: [N]
#   C: [M, N]
@triton.jit
def _matmul_bias_sigmoid_scale_kernel(
    A, B, Bias, C,
    M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    scale,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # Pointers for A and B tiles
    A_ptrs = A + (offs_m[:, None] * stride_am + offs_k[None, :] * stride_ak)
    B_ptrs = B + (offs_k[:, None] * stride_bk + offs_n[None, :] * stride_bn)

    # Accumulator
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    # Loop over K
    for k in range(0, K, BLOCK_K):
        a = tl.load(
            A_ptrs,
            mask=(offs_m[:, None] < M) & (k + offs_k[None, :] < K),
            other=0.0,
        )
        b = tl.load(
            B_ptrs,
            mask=(k + offs_k[:, None] < K) & (offs_n[None, :] < N),
            other=0.0,
        )
        acc += tl.dot(a, b)
        A_ptrs += BLOCK_K * stride_ak
        B_ptrs += BLOCK_K * stride_bk

    # Add bias
    bias = tl.load(Bias + offs_n, mask=offs_n < N, other=0.0)
    acc = acc + bias[None, :]

    # Swish: x * sigmoid(x)
    # sigmoid(x) = 1 / (1 + exp(-x))
    sig = 1.0 / (1.0 + tl.exp(-acc))
    out = acc * sig

    # Scale
    out = out * scale

    # Store
    C_ptrs = C + (offs_m[:, None] * stride_cm + offs_n[None, :] * stride_cn)
    tl.store(
        C_ptrs,
        out,
        mask=(offs_m[:, None] < M) & (offs_n[None, :] < N),
    )


class ModelNew(nn.Module):
    """
    Triton-optimized version of the reference model:
      y = scale * swish(x @ W^T + b)
    Fuses matmul + bias + activation + scale into a single kernel.
    """
    def __init__(self, in_features, out_features, scaling_factor):
        super().__init__()
        # Keep same parameter shapes as nn.Linear
        self.in_features = in_features
        self.out_features = out_features
        self.scaling_factor = float(scaling_factor)

        # Parameters: weight [out_features, in_features], bias [out_features]
        self.weight = nn.Parameter(torch.empty(out_features, in_features))
        self.bias = nn.Parameter(torch.empty(out_features))

        # Kaiming uniform init like nn.Linear default
        bound = 1 / math.sqrt(in_features)
        with torch.no_grad():
            self.weight.uniform_(-bound, bound)
            self.bias.uniform_(-bound, bound)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [B, in_features]
        returns: [B, out_features]
        """
        assert x.dim() == 2, f"Expected 2D input, got shape {tuple(x.shape)}"
        B, K = x.shape
        assert K == self.in_features, f"Expected in_features={self.in_features}, got {K}"

        # Ensure dtype/device
        if x.dtype != torch.float32:
            x = x.float()
        device = x.device
        assert device.type == "cuda", "ModelNew requires CUDA tensors"

        # Prepare B as [K, N] = weight.T
        # Keep on same device
        W_t = self.weight.t().contiguous()  # [K, N]
        bias = self.bias.contiguous()       # [N]

        # Allocate output
        y = torch.empty((B, self.out_features), device=device, dtype=torch.float32)

        # Strides (row-major)
        stride_am = x.stride(0)
        stride_ak = x.stride(1)
        stride_bk = W_t.stride(0)
        stride_bn = W_t.stride(1)
        stride_cm = y.stride(0)
        stride_cn = y.stride(1)

        # Tile sizes: chosen for these shapes; can be tuned
        BLOCK_M = 64
        BLOCK_N = 64
        BLOCK_K = 32

        grid = (triton.cdiv(B, BLOCK_M), triton.cdiv(self.out_features, BLOCK_N))

        _matmul_bias_sigmoid_scale_kernel(
            x, W_t, bias, y,
            B, self.out_features, K,
            stride_am, stride_ak,
            stride_bk, stride_bn,
            stride_cm, stride_cn,
            self.scaling_factor,
            BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N, BLOCK_K=BLOCK_K,
            num_warps=4, num_stages=3,
        )

        return y

    def extra_repr(self):
        return f"in_features={self.in_features}, out_features={self.out_features}, scaling_factor={self.scaling_factor}"
