import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


# Triton kernel: conv2d NCHW -> NCHW, direct convolution
# Assumptions:
# - stride=1, padding=1, kernel=3x3
# - in_dtype = out_dtype = float32
# - groups = 1
# - no bias
@triton.jit
def conv2d_nchw_3x3_kernel(
    x_ptr, w_ptr, y_ptr,
    B, Cin, H, W, Cout,
    x_stride_n, x_stride_c, x_stride_h, x_stride_w,
    w_stride_co, w_stride_ci, w_stride_kh, w_stride_kw,
    y_stride_n, y_stride_c, y_stride_h, y_stride_w,
    OUT: tl.constexpr,  # 0: forward, 1: backward (unused here)
):
    pid_n = tl.program_id(0)
    pid_co = tl.program_id(1)
    pid_oh = tl.program_id(2)
    pid_ow = tl.program_id(3)

    # Output coords
    n = pid_n
    co = pid_co
    oh = pid_oh
    ow = pid_ow

    # Accumulator
    acc = tl.zeros((), dtype=tl.float32)

    # Loop over input channels and kernel
    # kh, kw in {0,1,2}; ih = oh + kh - pad = oh + kh - 1; similarly for iw
    for ci in range(0, Cin):
        for kh in range(3):
            ih = oh + kh - 1
            if (ih < 0) or (ih >= H):
                continue
            for kw in range(3):
                iw = ow + kw - 1
                if (iw < 0) or (iw >= W):
                    continue
                # Load x[n, ci, ih, iw]
                x_off = (
                    n * x_stride_n
                    + ci * x_stride_c
                    + ih * x_stride_h
                    + iw * x_stride_w
                )
                x_val = tl.load(x_ptr + x_off).to(tl.float32)

                # Load w[co, ci, kh, kw]
                w_off = (
                    co * w_stride_co
                    + ci * w_stride_ci
                    + kh * w_stride_kh
                    + kw * w_stride_kw
                )
                w_val = tl.load(w_ptr + w_off).to(tl.float32)

                acc += x_val * w_val

    # Store y[n, co, oh, ow]
    y_off = (
        n * y_stride_n
        + co * y_stride_c
        + oh * y_stride_h
        + ow * y_stride_w
    )
    tl.store(y_ptr + y_off, acc)


def _conv2d_nchw_3x3_triton(x, w, bias=None, out=None):
    """
    x: (N, Cin, H, W) float32 CUDA
    w: (Cout, Cin, 3, 3) float32 CUDA
    bias: (Cout) or None
    out: (N, Cout, H, W) or None
    Returns: out
    """
    assert x.is_cuda and w.is_cuda, "Triton conv requires CUDA tensors"
    assert x.dtype == torch.float32 and w.dtype == torch.float32, "Use float32 for now"
    N, Cin, H, W = x.shape
    Cout, Cin_w, KH, KW = w.shape
    assert Cin == Cin_w and KH == 3 and KW == 3, "Only 3x3 supported"
    # Output shape (no padding, stride=1 => H,W unchanged)
    OH = H
    OW = W
    if out is None:
        out = torch.empty((N, Cout, OH, OW), device=x.device, dtype=x.dtype)

    # Strides
    x_strides = x.stride()
    w_strides = w.stride()
    y_strides = out.stride()

    grid = (N, Cout, OH, OW)
    conv2d_nchw_3x3_kernel[grid](
        x, w, out,
        N, Cin, H, W, Cout,
        x_strides[0], x_strides[1], x_strides[2], x_strides[3],
        w_strides[0], w_strides[1], w_strides[2], w_strides[3],
        y_strides[0], y_strides[1], y_strides[2], y_strides[3],
        OUT=0,
        num_warps=4,
        num_stages=2,
    )

    if bias is not None:
        out += bias.view(1, -1, 1, 1)

    return out


class ModelNew(nn.Module):
    def __init__(self, num_classes=1000):
        super(ModelNew, self).__init__()
        # Keep first and last layers as PyTorch for simplicity / correctness
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=96, kernel_size=11, stride=4, padding=2)
        self.relu1 = nn.ReLU(inplace=True)
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2)

        # Middle layers: use custom weights but call Triton in forward
        self.conv2_triton_w = nn.Parameter(torch.empty(256, 96, 3, 3))
        self.conv3_triton_w = nn.Parameter(torch.empty(384, 256, 3, 3))
        self.conv4_triton_w = nn.Parameter(torch.empty(384, 384, 3, 3))
        self.conv5_triton_w = nn.Parameter(torch.empty(256, 384, 3, 3))

        # Kaiming init similar to Conv2d default
        for w in [self.conv2_triton_w, self.conv3_triton_w, self.conv4_triton_w, self.conv5_triton_w]:
            nn.init.kaiming_uniform_(w, a=math.sqrt(5))
        # Biases (optional): set to zero
        self.conv2_bias = nn.Parameter(torch.zeros(256))
        self.conv3_bias = nn.Parameter(torch.zeros(384))
        self.conv4_bias = nn.Parameter(torch.zeros(384))
        self.conv5_bias = nn.Parameter(torch.zeros(256))

        self.relu2 = nn.ReLU(inplace=True)
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2)
        self.relu3 = nn.ReLU(inplace=True)
        self.relu4 = nn.ReLU(inplace=True)
        self.relu5 = nn.ReLU(inplace=True)
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2)

        self.fc1 = nn.Linear(in_features=256 * 6 * 6, out_features=4096)
        self.relu6 = nn.ReLU(inplace=True)
        self.dropout1 = nn.Dropout(p=0.0)
        self.fc2 = nn.Linear(in_features=4096, out_features=4096)
        self.relu7 = nn.ReLU(inplace=True)
        self.dropout2 = nn.Dropout(p=0.0)
        self.fc3 = nn.Linear(in_features=4096, out_features=num_classes)

    def forward(self, x):
        # Ensure CUDA
        assert x.is_cuda, "Input must be on CUDA for Triton path"
        x = self.conv1(x)
        x = self.relu1(x)
        x = self.maxpool1(x)

        # Conv2: 96 -> 256
        w = self.conv2_triton_w
        b = self.conv2_bias
        x = _conv2d_nchw_3x3_triton(x, w, bias=b)
        x = self.relu2(x)
        x = self.maxpool2(x)

        # Conv3: 256 -> 384
        w = self.conv3_triton_w
        b = self.conv3_bias
        x = _conv2d_nchw_3x3_triton(x, w, bias=b)
        x = self.relu3(x)

        # Conv4: 384 -> 384
        w = self.conv4_triton_w
        b = self.conv4_bias
        x = _conv2d_nchw_3x3_triton(x, w, bias=b)
        x = self.relu4(x)
