import math
import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


# Simple elementwise kernel: C = A * s
if TRITON_AVAILABLE:
    @triton.jit
    def _scale_kernel(
        A_ptr, C_ptr,
        M: tl.constexpr, N: tl.constexpr,
        stride_am, stride_an,
        stride_cm, stride_cn,
        s: tl.constexpr,
        BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr
    ):
        pid_m = tl.program_id(0)
        pid_n = tl.program_id(1)

        offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
        offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

        mask_m = offs_m < M
        mask_n = offs_n < N

        a_ptrs = A_ptr + (offs_m[:, None] * stride_am + offs_n[None, :] * stride_an)
        c_ptrs = C_ptr + (offs_m[:, None] * stride_cm + offs_n[None, :] * stride_cn)

        mask = mask_m[:, None] & mask_n[None, :]

        a = tl.load(a_ptrs, mask=mask, other=0.0)
        c = a * s
        tl.store(c_ptrs, c, mask=mask)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()
        # No parameters; purely elementwise op

    def forward(self, A: torch.Tensor, s: float) -> torch.Tensor:
        """
        Performs matrix-scalar multiplication on CUDA using Triton if available.
        Falls back to PyTorch elementwise multiply otherwise.

        Args:
            A: Input matrix of shape (M, N), CUDA tensor
            s: Scalar value

        Returns:
            C: Resulting matrix of shape (M, N), same device as A
        """
        if not isinstance(A, torch.Tensor):
            raise TypeError("A must be a torch.Tensor")
        if A.device.type != "cuda":
            raise RuntimeError("ModelNew requires CUDA tensors; got CPU tensor")
        if A.ndim != 2:
            raise ValueError(f"Expected 2D tensor, got shape {tuple(A.shape)}")

        M, N = A.shape

        # Fast path: Triton kernel
        if TRITON_AVAILABLE:
            # Allocate output
            C = torch.empty_like(A)

            # Choose reasonable tile sizes; these work well for many shapes
            BLOCK_M = 128
            BLOCK_N = 128

            grid = (triton.cdiv(M, BLOCK_M), triton.cdiv(N, BLOCK_N))

            _scale_kernel[grid](
                A, C,
                M, N,
                A.stride(0), A.stride(1),
                C.stride(0), C.stride(1),
                s,
                BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N,
                num_warps=4, num_stages=2
            )
            return C

        # Fallback: pure PyTorch elementwise multiply (still on CUDA if A is CUDA)
        return A * s
