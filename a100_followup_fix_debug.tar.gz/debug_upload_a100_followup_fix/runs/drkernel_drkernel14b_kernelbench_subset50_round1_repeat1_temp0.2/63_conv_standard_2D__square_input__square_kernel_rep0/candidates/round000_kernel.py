import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    _HAS_TRITON = True
except Exception:
    _HAS_TRITON = False


# Direct 2D convolution kernel: no padding, stride=1, dilation=1, groups=1
# Computes: out[n, oc, oh, ow] = sum_{ic=0..C_in-1} sum_{kh=0..K-1} sum_{kw=0..K-1}
#             x[n, ic, oh+kh, ow+kw] * w[oc, ic, kh, kw]
#
# Assumptions:
# - x: [N, C_in, H, W], contiguous
# - w: [C_out, C_in, K, K], contiguous
# - out: [N, C_out, H, W], contiguous
# - All tensors are on CUDA
# - dtype: float16/bfloat16/float32; accumulation in float32
#
# Tiling:
# - Tile over (oh, ow) for spatial, and over oc for output channels.
# - Loop over ic and kh, kw in Python (small K).
@triton.jit
def conv2d_nchw_kernel(
    x_ptr, w_ptr, out_ptr,
    N: tl.constexpr, C_in: tl.constexpr, C_out: tl.constexpr,
    H: tl.constexpr, W: tl.constexpr, K: tl.constexpr,
    stride_x_n: tl.constexpr, stride_x_c: tl.constexpr, stride_x_h: tl.constexpr, stride_x_w: tl.constexpr,
    stride_w_oc: tl.constexpr, stride_w_ic: tl.constexpr, stride_w_kh: tl.constexpr, stride_w_kw: tl.constexpr,
    stride_out_n: tl.constexpr, stride_out_c: tl.constexpr, stride_out_h: tl.constexpr, stride_out_w: tl.constexpr,
    BLOCK_OH: tl.constexpr, BLOCK_OW: tl.constexpr, BLOCK_OC: tl.constexpr,
):
    # Program ids
    pid_n = tl.program_id(0)
    pid_oh = tl.program_id(1)
    pid_ow = tl.program_id(2)
    pid_oc = tl.program_id(3)

    # Offsets for tiles
    oh = pid_oh * BLOCK_OH + tl.arange(0, BLOCK_OH)
    ow = pid_ow * BLOCK_OW + tl.arange(0, BLOCK_OW)
    oc = pid_oc * BLOCK_OC + tl.arange(0, BLOCK_OC)

    # Masks for bounds
    mask_oh = oh < H
    mask_ow = ow < W
    mask_oc = oc < C_out

    # Create 2D spatial grid for the tile
    oh_2d = oh[:, None]  # (BLOCK_OH, 1)
    ow_2d = ow[None, :]  # (1, BLOCK_OW)

    # Accumulator: (BLOCK_OC, BLOCK_OH, BLOCK_OW) in fp32
    acc = tl.zeros((BLOCK_OC, BLOCK_OH, BLOCK_OW), dtype=tl.float32)

    # Loop over input channels and kernel window
    for ic in range(0, C_in):
        # For each (kh, kw)
        for kh in range(0, K):
            # top = oh + kh
            top = oh_2d + kh  # (BLOCK_OH, 1)
            for kw in range(0, K):
                left = ow_2d + kw  # (1, BLOCK_OW)

                # Compute x addresses: x[n, ic, top, left]
                # Broadcast to (BLOCK_OH, BLOCK_OW)
                x_idx = (
                    pid_n * stride_x_n
                    + ic * stride_x_c
                    + top * stride_x_h
                    + left * stride_x_w
                )  # shape (BLOCK_OH, BLOCK_OW)

                # Validity mask for x (spatial bounds)
                valid_x = (top < H) & (left < W)
                # Load x, cast to fp32
                x_val = tl.load(x_ptr + x_idx, mask=valid_x, other=0.0).to(tl.float32)  # (BLOCK_OH, BLOCK_OW)

                # Load weights: w[oc, ic, kh, kw] -> shape (BLOCK_OC,)
                w_idx = (
                    oc * stride_w_oc
                    + ic * stride_w_ic
                    + kh * stride_w_kh
                    + kw * stride_w_kw
                )  # (BLOCK_OC,)
                w_val = tl.load(w_ptr + w_idx, mask=mask_oc, other=0.0).to(tl.float32)  # (BLOCK_OC,)

                # Broadcast multiply: (BLOCK_OC, 1, 1) * (1, BLOCK_OH, BLOCK_OW)
                acc += w_val[:, None, None] * x_val[None, :, :]

    # Write out: out[n, oc, oh, ow]
    # Compute out pointer base for n
    out_base_n = pid_n * stride_out_n
    for ioc in range(0, BLOCK_OC):
        if not mask_oc[ioc]:
            continue
        oc_i = oc[ioc]
        out_base_c = oc_i * stride_out_c
        # Loop over oh, ow
        for ioh in range(0, BLOCK_OH):
            if not mask_oh[ioh]:
                continue
            top = oh[ioh]
            for iow in range(0, BLOCK_OW):
                if not mask_ow[iow]:
                    continue
                left = ow[iow]
                out_idx = out_base_n + out_base_c + top * stride_out_h + left * stride_out_w
                # Cast to output dtype (assume same as x.dtype)
                # We don't have dtype info here; assume float32 out for safety.
                out_val = acc[ioc, ioh, iow]
                tl.store(out_ptr + out_idx, out_val)


class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int,
                 stride: int = 1, padding: int = 0, dilation: int = 1, groups: int = 1, bias: bool = False):
        super().__init__()
        if groups != 1:
            raise NotImplementedError("groups != 1 not supported in this Triton kernel")
        if dilation != 1:
            raise NotImplementedError("dilation != 1 not supported in this Triton kernel")
        if padding != 0:
            raise NotImplementedError("padding != 0 not supported in this Triton kernel")
        if stride != 1:
            raise NotImplementedError("stride != 1 not supported in this Triton kernel")
        self.in_channels = int(in_channels)
        self.out_channels = int(out_channels)
        self.kernel_size = int(kernel_size)
        # Parameters: weight [C_out, C_in, K, K]
        self.weight = nn.Parameter(torch.empty(self.out_channels, self.in_channels, self.kernel_size, self.kernel_size))
        if bias:
            self.bias = nn.Parameter(torch.empty(self.out_channels))
        else:
            self.register_parameter("bias", None)
        self.reset_parameters()

    def reset_parameters(self):
        # Simple init similar to Conv2d default
        # bound = 1 / sqrt(fan_in)
        fan_in = self.in_channels * self.kernel_size * self.kernel_size
        bound = 1.0 / math.sqrt(fan_in)
        with torch.no_grad():
            self.weight.uniform_(-bound, bound)
            if self.bias is not None:
                self.bias.uniform_(-bound, bound)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: (N, C_in, H, W), CUDA tensor
        returns: (N, C_out, H, W), same dtype/device as x
        """
        if not x.is_cuda:
            raise RuntimeError("ModelNew requires CUDA tensors")
        N, C_in, H, W = x.shape
        K = self.kernel_size
        C_out = self.out_channels
        if C_in != self.in_channels:
            raise RuntimeError(f"Expected in_channels={self.in_channels}, got {C_in}")
        # Allocate output
        out = torch.empty((N, C_out, H, W), device=x.device, dtype=torch.float32)  # compute in fp32
        # Ensure contiguous
        x_c = x.contiguous()
        w_c = self.weight.contiguous()
        # Strides
        sxn, sxc, sxh, sxw
