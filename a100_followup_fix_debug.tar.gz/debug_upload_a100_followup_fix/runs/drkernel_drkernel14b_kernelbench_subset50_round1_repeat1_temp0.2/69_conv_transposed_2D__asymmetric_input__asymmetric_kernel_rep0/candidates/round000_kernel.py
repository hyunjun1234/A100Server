import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


def _compute_deconv_out_dim(in_size: int, kernel_size: int, stride: int, padding: int, output_padding: int, dilation: int) -> int:
    # PyTorch formula: out = (in - 1)*stride - 2*padding + dilation*(kernel - 1) + output_padding + 1
    return (in_size - 1) * stride - 2 * padding + dilation * (kernel_size - 1) + output_padding + 1


def _conv_transpose2d_output_shape(
    input_shape: tuple,
    kernel_size: tuple,
    stride: tuple,
    padding: tuple,
    output_padding: tuple,
    dilation: tuple,
) -> tuple:
    N, C_in, H_in, W_in = input_shape
    kH, kW = kernel_size
    sH, sW = stride
    pH, pW = padding
    opH, opW = output_padding
    dH, dW = dilation
    H_out = _compute_deconv_out_dim(H_in, kH, sH, pH, opH, dH)
    W_out = _compute_deconv_out_dim(W_in, kW, sW, pW, opW, dW)
    C_out = C_in  # groups=1; for groups>1, C_out is independent of C_in but must match layer definition
    return (N, C_out, H_out, W_out)


def _ceil_div(a: int, b: int) -> int:
    return (a + b - 1) // b


def _to_2tuple(x):
    if isinstance(x, (list, tuple)):
        assert len(x) == 2, f"Expected a 2-tuple, got {x}"
        return int(x[0]), int(x[1])
    x = int(x)
    return x, x


class ModelNew(nn.Module):
    """
    Triton implementation of ConvTranspose2d with arbitrary stride, padding, output_padding, dilation, groups=1, bias.

    Notes:
    - All tensors must be CUDA; CPU tensors are not supported.
    - Accumulation is done in float32 for numerical stability; output is cast to input dtype.
    - Supports float32, float16, bfloat16 inputs.
    - Groups must be 1 (not implemented here).
    """
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: tuple,
        stride: tuple = (1, 1),
        padding: tuple = (0, 0),
        output_padding: tuple = (0, 0),
        dilation: tuple = (1, 1),
        groups: int = 1,
        bias: bool = False,
    ):
        super().__init__()
        assert groups == 1, "This Triton implementation currently supports groups=1 only."
        self.in_channels = int(in_channels)
        self.out_channels = int(out_channels)
        self.kernel_size = _to_2tuple(kernel_size)
        self.stride = _to_2tuple(stride)
        self.padding = _to_2tuple(padding)
        self.output_padding = _to_2tuple(output_padding)
        self.dilation = _to_2tuple(dilation)
        self.groups = int(groups)
        self.bias_flag = bool(bias)

        kH, kW = self.kernel_size
        # Weight shape: (in_channels, out_channels, kH, kW) for groups=1
        self.weight = nn.Parameter(torch.empty(self.in_channels, self.out_channels, kH, kW))
        if self.bias_flag:
            self.bias = nn.Parameter(torch.empty(self.out_channels))
        else:
            self.register_parameter("bias", None)

        # Kaiming uniform init similar to ConvTranspose2d default
        # a = sqrt(5) for relu-like; fan_in = in_channels * kH * kW
        a = math.sqrt(5)
        fan_in = self.in_channels * kH * kW
        bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
        nn.init.kaiming_uniform_(self.weight, a=a)
        if self.bias is not None:
            nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        assert x.is_cuda, "ModelNew requires CUDA tensors; move input to CUDA."
        assert x.dim() == 4, f"Expected NCHW tensor, got shape {tuple(x.shape)}"
        N, C_in, H_in, W_in = x.shape
        assert C_in == self.in_channels, f"Input C={C_in} != in_channels={self.in_channels}"
        device = x.device
        dtype = x.dtype

        kH, kW = self.kernel_size
        sH, sW = self.stride
        pH, pW = self.padding
        opH, opW = self.output_padding
        dH, dW = self.dilation

        # Compute output shape (matches PyTorch)
        H_out = _compute_deconv_out_dim(H_in, kH, sH, pH, opH, dH)
        W_out = _compute_deconv_out_dim(W_in, kW, sW, pW, opW, dW)
        C_out = self.out_channels

        # Allocate output
        y = torch.empty((N, C_out, H_out, W_out), device=device, dtype=dtype)

        # Dtypes: accumulate in float32
        x_f32 = x.to(torch.float32)
        w_f32 = self.weight.to(torch.float32)
        b_f32 = self.bias.to(torch.float32) if (self.bias is not None) else None

        # Launch Triton kernel
        # Grid: (N, C_out, ceil_div(H_out*W_out, BLOCK))
        BLOCK = 128
        num_hw = H_out * W_out
        grid = (N, C_out, _ceil_div(num_hw, BLOCK))

        conv_transpose2d_kernel[
            grid
        ](
            x_f32, w_f32, b_f32 if b_f32 is not None else torch.empty(1, device=device, dtype=torch.float32),
            N, C_in, H_in, W_in,
            C_out, H_out, W_out,
            kH, kW,
            sH, sW,
            pH, pW,
            opH, opW,
            dH, dW,
            self.bias_flag,
            dtype_size=x_f32.element_size(),
            BLOCK=BLOCK,
        )

        # Cast back to input dtype
        if y.dtype != dtype:
            y = y.to(dtype)
        return y


if TRITON_AVAILABLE:
    @triton.jit
    def conv_transpose2d_kernel(
        x, w, b,  # pointers
        N: tl.constexpr, C_in: tl.constexpr, H_in: tl.constexpr, W_in: tl.constexpr,
        C_out: tl.constexpr, H_out: tl.constexpr, W_out: tl.constexpr,
        kH: tl.constexpr, kW: tl.constexpr,
        sH: tl.constexpr, sW: tl.constexpr,
        pH: tl.constexpr, pW: tl.constexpr,
        opH: tl.constexpr, opW: tl.constexpr,
        dH: tl.constexpr, dW: tl.constexpr,
        has_bias: tl.constexpr,
        dtype_size: tl.constexpr,
        BLOCK: tl.constexpr,
    ):
        # Program ids
        pid_n = tl.program_id(0)
        pid_co = tl.program_id(1)
        pid_blk = tl.program_id(2)

        # Linear index over H_out*W_out
        offs = pid_blk * BLOCK + tl.arange(0, BLOCK)
        mask = offs < (H_out * W_out)

        # Recover (h, w) from linear index
        w_idx = offs % W_out
        h_idx = offs // W_out

        # Base pointer for x[n]
        # x is [N, C_in, H_in, W_in] contiguous
        # We will compute addresses as x_ptr + n*stride_n + c*stride_c + h*stride_h + w*stride_w
        # But to simplify, precompute base for n
        # Note: strides are in elements
        # Assume contiguous: stride_w = 1, stride_h = W_in, stride_c = H_in*W_in, stride_n = C_in*H_in*W_in
        # But we'll use generic strides from tensor
        # However, Triton does not pass strides; we encode using element indexing:
        # x[n, c, h, w] -> ((n*C_in + c)*H_in + h)*W_in + w
        # But to stay generic, we'll
