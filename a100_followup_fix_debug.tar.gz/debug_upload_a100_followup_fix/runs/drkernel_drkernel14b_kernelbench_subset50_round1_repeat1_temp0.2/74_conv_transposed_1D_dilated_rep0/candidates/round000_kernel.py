import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


def _compute_output_length(L_in: int, kernel_size: int, stride: int, padding: int, dilation: int) -> int:
    # PyTorch ConvTranspose1d formula:
    # L_out = (L_in - 1) * stride - 2 * padding + dilation * (kernel_size - 1) + output_padding + 1
    # Here we assume output_padding = 0 (default), matching the reference code.
    return (L_in - 1) * stride - 2 * padding + dilation * (kernel_size - 1) + 1


def _ceil_div(a: int, b: int) -> int:
    return (a + b - 1) // b


@triton.jit
def _conv_transpose1d_fwd_kernel(
    x_ptr,            # [B, IC, L_in]
    w_ptr,            # [IC, OC, K]
    b_ptr,            # [OC] or None
    y_ptr,            # [B, OC, L_out]
    B: tl.constexpr,
    IC: tl.constexpr,
    OC: tl.constexpr,
    K: tl.constexpr,
    L_in: tl.constexpr,
    L_out: tl.constexpr,
    stride_x_b: tl.constexpr, stride_x_c: tl.constexpr, stride_x_l: tl.constexpr,
    stride_w_ic: tl.constexpr, stride_w_oc: tl.constexpr, stride_w_k: tl.constexpr,
    stride_y_b: tl.constexpr, stride_y_c: tl.constexpr, stride_y_l: tl.constexpr,
    stride: tl.constexpr,
    padding: tl.constexpr,
    dilation: tl.constexpr,
    has_bias: tl.constexpr,
    # tiling
    BLOCK_OC: tl.constexpr,
    BLOCK_L: tl.constexpr,
):
    pid_b = tl.program_id(0)
    pid_oc = tl.program_id(1)
    pid_l = tl.program_id(2)

    oc = pid_oc * BLOCK_OC + tl.arange(0, BLOCK_OC)
    l = pid_l * BLOCK_L + tl.arange(0, BLOCK_L)

    # Masks for valid ranges
    oc_mask = oc < OC
    l_mask = l < L_out

    # Accumulator
    acc = tl.zeros((BLOCK_OC, BLOCK_L), dtype=tl.float32)

    # Loop over input channels and kernel taps
    for ic in range(0, IC):
        for k in range(0, K):
            # Compute input position i for each output position l:
            # l = i * stride - padding + k * dilation  => i = (l + padding - k * dilation) / stride
            num = l + padding - k * dilation
            # We only consider valid l; num divisibility by stride must hold for valid contribution
            # But we cannot branch per-element easily; instead, we compute i and then check modulo == 0
            # Compute i = num // stride (integer division); then check (i*stride == num)
            i = num // stride
            is_div = i * stride == num  # boolean vector

            # Valid if: l in range, ic in range, and divisible condition
            valid = l_mask & is_div

            # Compute input index l_in = i
            l_in = i  # shape [BLOCK_L]

            # Bounds check on l_in: 0 <= l_in < L_in
            in_bounds = (l_in >= 0) & (l_in < L_in)
            valid = valid & in_bounds

            # Create 2D mask [BLOCK_OC, BLOCK_L]
            mask = (oc_mask[:, None]) & (valid[None, :])

            # Load x[b, ic, l_in] -> shape [BLOCK_L]
            x_off = pid_b * stride_x_b + ic * stride_x_c + l_in * stride_x_l
            x_val = tl.load(x_ptr + x_off + valid * 0, mask=valid, other=0.0)  # only load where valid
            x_val = x_val.to(tl.float32)  # [BLOCK_L]

            # Load w[ic, oc, k] -> shape [BLOCK_OC]
            w_off = ic * stride_w_ic + oc * stride_w_oc + k * stride_w_k
            w_val = tl.load(w_ptr + w_off + oc_mask * 0, mask=oc_mask, other=0.0)
            w_val = w_val.to(tl.float32)  # [BLOCK_OC]

            # Outer product accumulate: acc[oc, l] += w_val[oc] * x_val[l]
            acc += w_val[:, None] * x_val[None, :]

    # Add bias if present
    if has_bias:
        b_val = tl.load(b_ptr + oc, mask=oc_mask, other=0.0).to(tl.float32)  # [BLOCK_OC]
        acc += b_val[:, None]

    # Store result y[b, oc, l]
    y_off_b = pid_b * stride_y_b
    for off in range(0, BLOCK_L):
        l_idx = pid_l * BLOCK_L + off
        if l_idx < L_out:
            for j in range(0, BLOCK_OC):
                oc_idx = pid_oc * BLOCK_OC + j
                if oc_idx < OC:
                    y_addr = y_ptr + y_off_b + oc_idx * stride_y_c + l_idx * stride_y_l
                    tl.store(y_addr, acc[j, off])


class ModelNew(nn.Module):
    """
    Triton-optimized transposed 1D convolution that matches the reference signature.
    Computes y = conv_transpose1d(x, w) + bias, with support for stride, padding, dilation.
    """
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int,
                 stride: int = 1, padding: int = 0, dilation: int = 1, bias: bool = False):
        super().__init__()
        self.in_channels = int(in_channels)
        self.out_channels = int(out_channels)
        self.kernel_size = int(kernel_size)
        self.stride = int(stride)
        self.padding = int(padding)
        self.dilation = int(dilation)
        self.has_bias = bool(bias)

        # Parameters: shape [IC, OC, K]
        w = torch.empty(in_channels, out_channels, kernel_size)
        nn.init.kaiming_uniform_(w, a=math.sqrt(5))
        self.weight = nn.Parameter(w)

        if bias:
            b = torch.empty(out_channels)
            fan_in = in_channels * kernel_size
            bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
            nn.init.uniform_(b, -bound, bound)
            self.bias = nn.Parameter(b)
        else:
            self.register_parameter("bias", None)

        # Fallback module for CPU or if Triton is not available
        self._fallback = nn.ConvTranspose1d(
            in_channels, out_channels, kernel_size,
            stride=stride, padding=padding, dilation=dilation, bias=bias
        )
        # Copy weights to fallback to ensure identical behavior when falling back
        with torch.no_grad():
            self._fallback.weight.copy_(self.weight)
            if bias:
                self._fallback.bias.copy_(self.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: (B, IC, L_in), float32, CUDA
        returns y: (B, OC, L_out)
        """
        if not x.is_cuda:
            # CPU fallback
            return self._fallback(x)

        assert x.dtype == torch.float32, "This Triton kernel currently supports float32 only."
        B, IC, L_in = x.shape
        IC_w, OC, K = self.weight.shape
        assert IC == IC_w, f"Input channels {IC} != weight IC {IC_w}"
        assert K == self.kernel_size

        L_out = _compute_output_length(L_in, self.kernel_size, self.stride, self.padding, self.dilation)
        y = torch.empty((B, OC, L_out), device=x.device, dtype=x.dtype)

        # Strides
        sx_b, sx_c, sx_l = x.stride(0), x.stride(1), x.stride(2)
        sw_ic, sw_oc, sw_k = self.weight.stride(0), self.weight.stride(1), self.weight.stride(2)
        sy_b, sy_c, sy_l = y.stride(0), y.stride(1), y.stride(2)

        # Tiling parameters
        BLOCK_OC = 32
        BLOCK_L = 128

        grid = (
            B,
            _ceil_div(OC, BLOCK_OC),
            _ceil_div(L_out, BLOCK_L),
        )

        has_bias = self.has_bias and (self.bias is not None)

        _conv_transpose1d_fwd
