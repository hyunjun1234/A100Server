import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


def _ceil_div(a, b):
    return (a + b - 1) // b


@triton.jit
def conv1d_fwd_kernel(
    x_ptr,         # *f16/f32/bf16 [B, Cin, Lin]
    w_ptr,         # *f16/f32/bf16 [Cout, Cin, K]
    b_ptr,         # *f16/f32/bf16 [Cout] or nullptr
    y_ptr,         # *f16/f32/bf16 [B, Cout, Lout]
    # sizes
    B: tl.constexpr,
    Cin: tl.constexpr,
    Cout: tl.constexpr,
    Lin: tl.constexpr,
    Lout: tl.constexpr,
    K: tl.constexpr,
    # strides (in elements)
    x_sN: tl.constexpr, x_sC: tl.constexpr, x_sL: tl.constexpr,
    w_sO: tl.constexpr, w_sI: tl.constexpr, w_sK: tl.constexpr,
    y_sN: tl.constexpr, y_sC: tl.constexpr, y_sL: tl.constexpr,
    # execution params
    stride: tl.constexpr,
    dilation: tl.constexpr,
    # tiling
    BLOCK_L: tl.constexpr,
):
    pid_bc = tl.program_id(0)  # over B*Cout
    pid_lo = tl.program_id(1)  # over Lout tiles

    b = pid_bc // Cout
    oc = pid_bc % Cout

    l_start = pid_lo * BLOCK_L
    l_idx = l_start + tl.arange(0, BLOCK_L)
    mask_l = l_idx < Lout

    # accumulator in fp32
    acc = tl.zeros([BLOCK_L], dtype=tl.float32)

    # loop over input channels and kernel taps
    for ic in range(0, Cin):
        for kt in range(0, K):
            # compute input l positions: l = l_out*stride - pad + kt*dilation
            # pad = 0 (asymmetric) => l = l_out*stride + kt*dilation
            li = l_idx * stride + kt * dilation  # shape [BLOCK_L]

            # bounds mask: 0 <= li < Lin
            in_bounds = (li >= 0) & (li < Lin)
            valid = mask_l & in_bounds

            # x address: x[b, ic, li]
            x_addr = x_ptr + b * x_sN + ic * x_sC + li * x_sL
            x_val = tl.load(x_addr, mask=valid, other=0.0)
            x_val_f32 = x_val.to(tl.float32)

            # w address: w[oc, ic, kt]
            w_addr = w_ptr + oc * w_sO + ic * w_sI + kt * w_sK
            w_val = tl.load(w_addr)
            w_val_f32 = w_val.to(tl.float32)

            acc += x_val_f32 * w_val_f32

    # add bias if provided
    if b_ptr != 0:
        bo = tl.load(b_ptr + oc)
        acc += bo.to(tl.float32)

    # store result to y[b, oc, l_idx]
    y_addr = y_ptr + b * y_sN + oc * y_sC + l_idx * y_sL
    # cast back to input dtype (assume same as x)
    # We don't have x dtype here; assume float32 output, caller can cast.
    tl.store(y_addr, acc, mask=mask_l)


class ModelNew(nn.Module):
    """
    Triton-optimized 1D convolution matching the reference Model.forward signature.

    Args:
        in_channels (int): Number of channels in the input tensor.
        out_channels (int): Number of channels produced by the convolution.
        kernel_size (int): Size of the square convolution kernel.
        stride (int, optional): Stride of the convolution. Defaults to 1.
        dilation (int, optional): Spacing between kernel elements. Defaults to 1.
        bias (bool, optional): If True, adds a learnable bias to the output. Defaults to False.
    """
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, dilation: int = 1, bias: bool = False):
        super().__init__()
        self.in_channels = int(in_channels)
        self.out_channels = int(out_channels)
        self.kernel_size = int(kernel_size)
        self.stride = int(stride)
        self.dilation = int(dilation)
        self.use_bias = bool(bias)

        # Parameters: keep weights on CUDA, dtype float32 by default
        # Shape: [Cout, Cin, K]
        self.weight = nn.Parameter(torch.empty(self.out_channels, self.in_channels, self.kernel_size))
        if self.use_bias:
            self.bias = nn.Parameter(torch.empty(self.out_channels))
        else:
            self.register_parameter("bias", None)

        self.reset_parameters()

    def reset_parameters(self):
        # Simple init similar to Conv1d default (can be tuned)
        # kaiming_uniform_ for weights, uniform for bias
        bound = 1 / math.sqrt(self.in_channels)
        with torch.no_grad():
            # weight: (Cout, Cin, K)
            nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
            if self.bias is not None:
                nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Performs the 1D convolution using a Triton kernel.

        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_channels, length), CUDA.

        Returns:
            torch.Tensor: Output tensor of shape (batch_size, out_channels, length_out), CUDA.
        """
        if not x.is_cuda:
            raise RuntimeError("ModelNew requires CUDA tensors; please move input to CUDA.")

        B, Cin, Lin = x.shape
        assert Cin == self.in_channels, f"Expected in_channels={self.in_channels}, got {Cin}"
        K = self.kernel_size
        stride = self.stride
        dilation = self.dilation

        # Compute output length (no padding)
        Lout = (Lin - dilation * (K - 1) - 1) // stride + 1
        if Lout <= 0:
            raise ValueError(f"Invalid configuration: computed Lout={Lout} <= 0. Check stride/dilation/kernel/length.")

        # Ensure contiguous
        x_c = x.contiguous()
        w_c = self.weight.contiguous()
        bias_c = self.bias.contiguous() if (self.bias is not None) else None

        # Allocate output (float32 accumulation, cast later if needed)
        y = torch.empty((B, self.out_channels, Lout), device=x.device, dtype=torch.float32)

        # Strides in elements
        x_sN, x_sC, x_sL = x_c.stride(0), x_c.stride(1), x_c.stride(2)
        w_sO, w_sI, w_sK = w_c.stride(0), w_c.stride(1), w_c.stride(2)
        y_sN, y_sC, y_sL = y.stride(0), y.stride(1), y.stride(2)

        # Grid: (B*Cout) x ceil_div(Lout, BLOCK_L)
        BLOCK_L = 128
        grid = (B * self.out_channels, _ceil_div(Lout, BLOCK_L))

        # Bias pointer: pass 0 if None
        b_ptr = bias_c if bias_c is not None else torch.empty(1, device=x.device, dtype=y.dtype)
        b_addr = b_ptr if bias_c is not None else torch.tensor(0, device=x.device)

        conv1d_fwd_kernel[
            grid
        ](
            x_c, w_c, b_addr, y,
            B, self.in_channels, self.out_channels, Lin, Lout, K,
            x_sN, x_sC, x_sL,
            w_sO, w_sI, w
