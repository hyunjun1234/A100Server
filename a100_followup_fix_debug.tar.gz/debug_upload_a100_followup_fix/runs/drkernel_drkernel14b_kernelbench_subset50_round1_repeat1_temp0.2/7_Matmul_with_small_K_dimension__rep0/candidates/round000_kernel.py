import math
import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    _HAS_TRITON = True
except Exception:
    _HAS_TRITON = False


# Tiled matmul: C[M, N] = A[M, K] @ B[K, N]
# Specialized for small K and large M/N; FP32 accumulation.
@triton.jit
def _matmul_smallk_kernel(
    A, B, C,
    M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    num_warps: tl.constexpr,
    num_stages: tl.constexpr,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # Pointers for the first K tile
    a_ptrs = A + (offs_m[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_n[None, :] * stride_bn)

    # Accumulator
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    # Loop over K in BLOCK_K steps
    for k in range(0, K, BLOCK_K):
        a = tl.load(
            a_ptrs,
            mask=(offs_m[:, None] < M) & (k + offs_k[None, :] < K),
            other=0.0,
        )
        b = tl.load(
            b_ptrs,
            mask=(k + offs_k[:, None] < K) & (offs_n[None, :] < N),
            other=0.0,
        )
        # Accumulate
        acc += tl.dot(a, b)
        # Advance pointers
        a_ptrs += BLOCK_K * stride_ak
        b_ptrs += BLOCK_K * stride_bk

    # Write back
    c_ptrs = C + (offs_m[:, None] * stride_cm + offs_n[None, :] * stride_cn)
    tl.store(
        c_ptrs,
        acc,
        mask=(offs_m[:, None] < M) & (offs_n[None, :] < N),
    )


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()
        # Tunable parameters; good starting point for small K and large M/N
        self.block_m = 128
        self.block_n = 128
        self.block_k = 64
        self.num_warps = 4
        self.num_stages = 2

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        # Validate shapes
        assert A.dim() == 2 and B.dim() == 2, f"Expected 2D tensors, got {A.shape} and {B.shape}"
        M, K = A.shape
        K2, N = B.shape
        assert K == K2, f"Incompatible shapes: A is (*, {K}), B is ({K2}, *), K mismatch"

        # If not CUDA or Triton not available, fall back
        if (not _HAS_TRITON) or (not A.is_cuda) or (not B.is_cuda):
            return torch.matmul(A, B)

        # Ensure dtype is float32 for stable accumulation; cast if needed
        # You can remove these casts if you want to preserve input dtype exactly.
        if A.dtype != torch.float32:
            A = A.to(torch.float32)
        if B.dtype != torch.float32:
            B = B.to(torch.float32)

        # Allocate output
        C = torch.empty((M, N), device=A.device, dtype=torch.float32)

        # Strides (in elements)
        stride_am, stride_ak = A.stride(0), A.stride(1)
        stride_bk, stride_bn = B.stride(0), B.stride(1)
        stride_cm, stride_cn = C.stride(0), C.stride(1)

        # Grid
        grid = (triton.cdiv(M, self.block_m), triton.cdiv(N, self.block_n))

        _matmul_smallk_kernel(
            A, B, C,
            M, N, K,
            stride_am, stride_ak,
            stride_bk, stride_bn,
            stride_cm, stride_cn,
            num_warps=self.num_warps,
            num_stages=self.num_stages,
            BLOCK_M=self.block_m,
            BLOCK_N=self.block_n,
            BLOCK_K=self.block_k,
        )

        return C
