import math
import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    _HAS_TRITON = True
except Exception:
    _HAS_TRITON = False


# Fused kernel: C = GEMM(A, B) -> row-wise max -> subtract row mean -> GELU
# Shapes:
#   A: [M, K]
#   B: [K, N]
#   C: [M, N]
# We compute tiles of C, accumulate dot(A_tile, B_tile), then do row-wise reductions
# and GELU in-register before writing out.
@triton.jit
def _fused_gemm_rowmax_mean_gelu_kernel(
    A_ptr, B_ptr, C_ptr,
    M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    # meta-params
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    # Pointers for the first K-tile
    a_ptrs = A_ptr + (offs_m[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B_ptr + (offs_k[:, None] * stride_bk + offs_n[None, :] * stride_bn)

    # Accumulator for the GEMM result tile
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    # Loop over K dimension
    k_iter = 0
    while k_iter < K:
        k_remaining = K - k_iter
        # Mask K if needed
        k_mask = offs_k < k_remaining

        a = tl.load(a_ptrs, mask=k_mask[None, :], other=0.0)
        b = tl.load(b_ptrs, mask=k_mask[:, None], other=0.0)
        acc += tl.dot(a, b)

        # Advance pointers
        a_ptrs += BLOCK_K * stride_ak
        b_ptrs += BLOCK_K * stride_bk
        k_iter += BLOCK_K

    # Write acc to C (temporary; we will overwrite with final values)
    c_ptrs = C_ptr + (offs_m[:, None] * stride_cm + offs_n[None, :] * stride_cn)
    tl.store(c_ptrs, acc)

    # Now perform row-wise max over columns in this tile
    # We'll iterate columns in BLOCK_N chunks to compute max per row
    row_max = tl.full((BLOCK_M,), -1.0e30, dtype=tl.float32)
    n0 = 0
    while n0 < N:
        col_offs = n0 + tl.arange(0, BLOCK_N)
        c_ptrs_chunk = C_ptr + (offs_m[:, None] * stride_cm + col_offs[None, :] * stride_cn)
        vals = tl.load(c_ptrs_chunk)
        # Mask invalid columns
        mask = col_offs < N
        vals = tl.where(mask[None, :], vals, -1.0e30)
        # Reduce max over columns for each row
        chunk_max = tl.max(vals, axis=1)
        row_max = tl.maximum(row_max, chunk_max)
        n0 += BLOCK_N

    # Broadcast row_max across columns
    row_max_b = row_max[:, None]

    # Compute row-wise sum of (C - row_max) over columns, in BLOCK_N chunks
    row_sum = tl.zeros((BLOCK_M,), dtype=tl.float32)
    n0 = 0
    while n0 < N:
        col_offs = n0 + tl.arange(0, BLOCK_N)
        c_ptrs_chunk = C_ptr + (offs_m[:, None] * stride_cm + col_offs[None, :] * stride_cn)
        vals = tl.load(c_ptrs_chunk)
        mask = col_offs < N
        vals = tl.where(mask[None, :], vals, 0.0)
        diff = vals - row_max_b
        chunk_sum = tl.sum(diff, axis=1)
        row_sum += chunk_sum
        n0 += BLOCK_N

    # Mean = sum / N (N is runtime)
    # Pass N as a scalar argument if needed; here we assume N is available as a constexpr or compute 1/N
    invN = 1.0 / N
    row_mean = row_sum * invN
    row_mean_b = row_mean[:, None]

    # Subtract mean, then GELU (numerically stable)
    n0 = 0
    while n0 < N:
        col_offs = n0 + tl.arange(0, BLOCK_N)
        c_ptrs_chunk = C_ptr + (offs_m[:, None] * stride_cm + col_offs[None, :] * stride_cn)
        vals = tl.load(c_ptrs_chunk)
        mask = col_offs < N
        z = vals - row_max_b - row_mean_b
        # GELU: 0.5 * z * (1 + erf(z / sqrt(2)))  (stable)
        inv_sqrt2 = 0.7071067811865476
        gelu = 0.5 * z * (1.0 + tl.math.erf(z * inv_sqrt2))
        out = tl.where(mask[None, :], gelu, 0.0)
        tl.store(c_ptrs_chunk, out)
        n0 += BLOCK_N


class ModelNew(nn.Module):
    """
    Triton-optimized version of the reference Model:
      y = GELU( max(x @ W^T + b, dim=1, keepdim=True) - mean(y, dim=1, keepdim=True) )
    Notes:
      - Assumes float32 tensors on CUDA.
      - Assumes max_dim == 1 (row-wise).
      - Falls back to PyTorch if Triton is not available.
    """
    def __init__(self, in_features, out_features, max_dim):
        super().__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.max_dim = max_dim

        if max_dim != 1:
            raise NotImplementedError("ModelNew currently supports max_dim == 1 only.")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if not x.is_cuda:
            raise RuntimeError("ModelNew requires CUDA tensors.")
        if x.dtype != torch.float32:
            raise RuntimeError("ModelNew currently supports float32 only.")

        # Shapes
        M, K = x.shape
        N = self.gemm.out_features

        # Ensure weights are contiguous and on device
        W = self.gemm.weight
        b = self.gemm.bias
        if not W.is_contiguous():
            W = W.contiguous()
        if not b.is_contiguous():
            b = b.contiguous()
        # B is [K, N]; A is [M, K]
        B = W  # [K, N]
        A = x  # [M, K]

        # Allocate output
        y = torch.empty((M, N), device=x.device, dtype=x.dtype)

        # Strides (in elements)
        stride_am = A.stride(0)
        stride_ak = A.stride(1)
        stride_bk = B.stride(0)
        stride_bn = B.stride(1)
        stride_cm = y.stride(0)
        stride_cn = y.stride(1)

        # Tile sizes (can be tuned)
        BLOCK_M = 64
        BLOCK_N = 128
        BLOCK_K = 32

        grid = (triton.cdiv(M, BLOCK_M), triton.cdiv(N, BLOCK_N))

        _fused_gemm_rowmax_mean_gelu_kernel[
            grid
        ](
            A, B, y,
            M, N, K,
            stride_am, stride_ak,
            stride_bk, stride_bn,
            stride_cm, stride_cn,
            BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N, BLOCK_K=BLOCK_K,
            num_warps=4, num_stages=2,
        )

        return y
