import math
import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


# Triton kernel: C = A * s
if TRITON_AVAILABLE:
    @triton.jit
    def _matmul_scalar_kernel(
        A_ptr, C_ptr,
        M, N,
        stride_am, stride_an,
        stride_cm, stride_cn,
        s,
        BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr
    ):
        pid_m = tl.program_id(0)
        pid_n = tl.program_id(1)

        offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
        offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

        mask_m = offs_m < M
        mask_n = offs_n < N

        a_ptrs = A_ptr + (offs_m[:, None] * stride_am + offs_n[None, :] * stride_an)
        c_ptrs = C_ptr + (offs_m[:, None] * stride_cm + offs_n[None, :] * stride_cn)

        mask = mask_m[:, None] & mask_n[None, :]

        a = tl.load(a_ptrs, mask=mask, other=0.0)
        c = a * s
        tl.store(c_ptrs, c, mask=mask)


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()
        # No parameters; everything is done in the kernel

    def forward(self, A: torch.Tensor, s: float) -> torch.Tensor:
        """
        Performs matrix-scalar multiplication C = A * s using a Triton kernel on CUDA.
        Falls back to PyTorch if Triton/CUDA is not available.

        Args:
            A: Input matrix of shape (M, N), CUDA tensor
            s: Scalar value

        Returns:
            C: Resulting matrix of shape (M, N), on the same device as A
        """
        # Validate device
        if not A.is_cuda:
            raise RuntimeError("ModelNew expects CUDA tensors; got CPU tensor.")

        # Ensure dtype is floating
        if not A.dtype.is_floating_point:
            raise TypeError(f"Expected floating-point tensor, got dtype={A.dtype}")

        M, N = A.shape
        C = torch.empty_like(A)

        # Choose tile sizes; 128x128 is a good default for many GPUs
        BLOCK_M = 128
        BLOCK_N = 128

        grid = (triton.cdiv(M, BLOCK_M), triton.cdiv(N, BLOCK_N))

        _matmul_scalar_kernel[grid](
            A, C,
            M, N,
            A.stride(0), A.stride(1),
            C.stride(0), C.stride(1),
            float(s),
            BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N,
            num_warps=4, num_stages=2,
        )

        return C
