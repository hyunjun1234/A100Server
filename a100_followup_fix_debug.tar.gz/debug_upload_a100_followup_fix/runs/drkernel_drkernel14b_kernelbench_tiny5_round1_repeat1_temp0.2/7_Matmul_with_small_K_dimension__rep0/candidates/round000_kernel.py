import torch
import torch.nn as nn

try:
    import triton
    import triton.language as tl
    TRITON_AVAILABLE = True
except Exception:
    TRITON_AVAILABLE = False


# Small-K matmul: C[M, N] = A[M, K] @ B[K, N]
# Tiled over M and N; loops over K in blocks of BLOCK_K.
@triton.jit
def _matmul_smallk_kernel(
    A, B, C,
    M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    OUT_DTYPE: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

    # Accumulator in fp32 for numeric stability
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)

    # Loop over K in BLOCK_K steps
    for k0 in range(0, K, BLOCK_K):
        offs_k = k0 + tl.arange(0, BLOCK_K)

        a_ptrs = A + (offs_m[:, None] * stride_am) + (offs_k[None, :] * stride_ak)
        b_ptrs = B + (offs_k[:, None] * stride_bk) + (offs_n[None, :] * stride_bn)

        a = tl.load(a_ptrs, mask=(offs_m[:, None] < M) & (offs_k[None, :] < K), other=0.0)
        b = tl.load(b_ptrs, mask=(offs_k[:, None] < K) & (offs_n[None, :] < N), other=0.0)

        # Cast to fp32 for dot; this supports fp16/bf16 inputs
        a = a.to(tl.float32)
        b = b.to(tl.float32)

        # Accumulate
        acc += tl.dot(a, b)

    # Write back
    c_ptrs = C + (offs_m[:, None] * stride_cm) + (offs_n[None, :] * stride_cn)
    out = acc.to(OUT_DTYPE)
    tl.store(c_ptrs, out, mask=(offs_m[:, None] < M) & (offs_n[None, :] < N))


class ModelNew(nn.Module):
    """
    Triton-optimized matmul for small K. Falls back to torch.matmul if Triton/CUDA is unavailable.
    """
    def __init__(self, block_m=128, block_n=128, block_k=64, num_warps=4, num_stages=2):
        super().__init__()
        self.block_m = block_m
        self.block_n = block_n
        self.block_k = block_k
        self.num_warps = num_warps
        self.num_stages = num_stages

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        # Validate shapes
        assert A.dim() == 2 and B.dim() == 2, f"Expected 2D tensors, got {A.shape} and {B.shape}"
        M, K_a = A.shape
        K_b, N = B.shape
        assert K_a == K_b, f"Incompatible shapes: A is (*, {K_a}), B is ({K_b}, *)."
        K = K_a

        # Device checks
        if (not TRITON_AVAILABLE) or (not A.is_cuda) or (not B.is_cuda):
            # Fallback: use torch.matmul (keeps device consistent)
            return torch.matmul(A, B)

        # Dtype handling: support fp16/bf16/fp32 inputs; output matches input dtype
        if A.dtype != B.dtype:
            raise ValueError(f"A and B must have same dtype, got {A.dtype} vs {B.dtype}")
        if A.dtype not in (torch.float16, torch.bfloat16, torch.float32):
            # Fallback for unsupported dtypes
            return torch.matmul(A, B)

        # Allocate output
        C = torch.empty((M, N), device=A.device, dtype
