import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

# Define the CUDA kernel
cuda_hinge_loss_code = """
#include <torch/extension.h>
#include <cmath>

__global__ void hinge_loss_kernel(const float* predictions, const float* targets, float* loss, int n) {
    extern __shared__ float shared_loss[];
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    int stride = blockDim.x * gridDim.x;

    float local_loss = 0.0f;
    for (int i = tid; i < n; i += stride) {
        float diff = 1.0f - predictions[i] * targets[i];
        local_loss += fmaxf(diff, 0.0f);
    }

    // Reduce local losses to a single block sum
    shared_loss[threadIdx.x] = local_loss;
    __syncthreads();

    for (unsigned int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (threadIdx.x < s) {
            shared_loss[threadIdx.x] += shared_loss[threadIdx.x + s];
        }
        __syncthreads();
    }

    if (threadIdx.x == 0) {
        atomicAdd(loss, shared_loss[0] / n);
    }
}
"""

# Load the CUDA kernel into PyTorch
hinge_loss_module = load_inline(name="hinge_loss_module", sources=[cuda_hinge_loss_code], verbose=True)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, predictions, targets):
        # Ensure inputs are on the correct device
        predictions = predictions.contiguous().cuda()
        targets = targets.contiguous().cuda()

        # Allocate memory for the loss
        loss = torch.tensor(0.0, dtype=torch.float32, device=predictions.device, requires_grad=False)

        # Define the CUDA kernel parameters
        block_size = 256
        grid_size = (predictions.size(0) + block_size - 1) // block_size
        shared_memory_size = block_size * sizeof(float)

        # Launch the CUDA kernel
        hinge_loss_module.hinge_loss_kernel[block_size, grid_size, shared_memory_size](
            predictions.data_ptr(),
            targets.data_ptr(),
            loss.data_ptr(),
            predictions.size(0)
        )

        return loss

# Test the implementation
def test_hinge_loss():
    model_ref = Model()
    model_opt = ModelNew()

    predictions, targets = get_inputs()

    loss_ref = model_ref(predictions, targets)
    loss_opt = model_opt(predictions, targets)

    print(f"Reference Loss: {loss_ref.item()}")
    print(f"Optimized Loss: {loss_opt.item()}")

    assert torch.isclose(loss_ref, loss_opt, atol=1e-6), "The optimized implementation does not match the reference."

# Run the test
test_hinge_loss()