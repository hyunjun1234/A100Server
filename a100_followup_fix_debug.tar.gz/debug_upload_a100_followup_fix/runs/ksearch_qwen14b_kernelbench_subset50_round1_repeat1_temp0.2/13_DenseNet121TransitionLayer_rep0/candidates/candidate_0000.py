import torch
import torch.nn as nn
from torch.utils.cpp_extension import load

# Load the CUDA kernel
custom_cuda_ops = load(name='custom_cuda_ops', sources=['custom_cuda_kernel.cu'])

class ModelNew(nn.Module):
    def __init__(self, num_input_features: int, num_output_features: int):
        super(ModelNew, self).__init__()
        self.num_input_features = num_input_features
        self.num_output_features = num_output_features
        self.bn = nn.BatchNorm2d(num_input_features)
        self.conv = nn.Conv2d(num_input_features, num_output_features, kernel_size=1, bias=False)

    def forward(self, x):
        # Apply Batch Normalization
        x = self.bn(x)
        
        # Apply ReLU activation
        x = torch.relu(x, inplace=True)
        
        # Apply 1x1 convolution
        x = self.conv(x)
        
        # Apply Average Pooling
        x = custom_cuda_ops.avg_pool2d_forward(x, kernel_size=2, stride=2)
        
        return x

# Custom CUDA kernel for average pooling
# custom_cuda_kernel.cu
"""
#include <ATen/ATen.h>

at::Tensor avg_pool2d_forward(
    const at::Tensor& input,
    int64_t kernel_size,
    int64_t stride) {
    AT_ASSERTM(input.dim() == 4, "Input must be a 4D tensor (batch_size, channels, height, width)");
    
    int64_t batch_size = input.size(0);
    int64_t num_channels = input.size(1);
    int64_t input_height = input.size(2);
    int64_t input_width = input.size(3);
    
    int64_t output_height = (input_height - kernel_size) / stride + 1;
    int64_t output_width = (input_width - kernel_size) / stride + 1;
    
    auto output = at::zeros({batch_size, num_channels, output_height, output_width}, input.options());
    
    AT_DISPATCH_FLOATING_TYPES(input.type(), "avg_pool2d_forward", [&] {
        scalar_t* input_data = input.data_ptr<scalar_t>();
        scalar_t* output_data = output.data_ptr<scalar_t>();
        
        for (int64_t b = 0; b < batch_size; ++b) {
            for (int64_t c = 0; c < num_channels; ++c) {
                for (int64_t oh = 0; oh < output_height; ++oh) {
                    for (int64_t ow = 0; ow < output_width; ++ow) {
                        int64_t ih = oh * stride;
                        int64_t iw = ow * stride;
                        
                        scalar_t sum = 0;
                        for (int64_t kh = 0; kh < kernel_size; ++kh) {
                            for (int64_t kw = 0; kw < kernel_size; ++kw) {
                                sum += input_data[(b * num_channels + c) * input_height * input_width + (ih + kh) * input_width + (iw + kw)];
                            }
                        }
                        output_data[(b * num_channels + c) * output_height * output_width + oh * output_width + ow] = sum / (kernel_size * kernel_size);
                    }
                }
            }
        }
    });
    
    return output;
}
"""

# Example usage
batch_size = 128
num_input_features = 32
num_output_features = 64
height, width = 256, 256

model_new = ModelNew(num_input_features, num_output_features)
inputs = torch.rand(batch_size, num_input_features, height, width)

output = model_new(inputs)
print(output.shape)