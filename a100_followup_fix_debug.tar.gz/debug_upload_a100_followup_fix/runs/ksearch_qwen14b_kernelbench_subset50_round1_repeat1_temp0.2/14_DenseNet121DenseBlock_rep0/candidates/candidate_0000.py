import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.cpp_extension import load_inline
import os

# Inline CUDA code for the custom kernel
cuda_code = """
#include <torch/extension.h>
#include <vector>

__global__ void dense_block_forward(
    const float* x, float* out,
    const float* bn_weight, const float* bn_bias, const float* bn_running_mean, const float* bn_running_var,
    const float* conv_weight, const float* conv_bias,
    int batch_size, int in_channels, int out_channels, int height, int width) {
    int bx = blockIdx.x;
    int tx = threadIdx.x;
    int ty = threadIdx.y;
    int tz = threadIdx.z;

    int channel = ty * blockDim.z + tz;
    int row = bx / (width * blockDim.x);
    int col = (bx % (width * blockDim.x)) / blockDim.x;
    int batch = bx % batch_size;

    if (channel >= out_channels) return;

    // Batch Normalization
    float x_normed = (x[batch * in_channels * height * width + channel * height * width + row * width + col] - bn_running_mean[channel]) /
                     sqrtf(bn_running_var[channel] + 1e-5f);

    // ReLU Activation
    x_normed = max(x_normed, 0.0f);

    // Convolution
    float sum = 0.0f;
    for (int k = 0; k < in_channels; ++k) {
        for (int kh = 0; kh < 3; ++kh) {
            for (int kw = 0; kw < 3; ++kw) {
                int r = row + kh - 1;
                int c = col + kw - 1;
                if (r >= 0 && r < height && c >= 0 && c < width) {
                    sum += x_normed * conv_weight[k * out_channels + channel * 3 * 3 + kh * 3 + kw];
                }
            }
        }
    }
    sum += conv_bias[channel];

    // Store result
    out[batch * out_channels * height * width + channel * height * width + row * width + col] = sum;
}

at::Tensor dense_block_forward_kernel(
    at::Tensor x, at::Tensor out,
    at::Tensor bn_weight, at::Tensor bn_bias, at::Tensor bn_running_mean, at::Tensor bn_running_var,
    at::Tensor conv_weight, at::Tensor conv_bias) {
    int batch_size = x.size(0);
    int in_channels = x.size(1);
    int out_channels = conv_weight.size(0);
    int height = x.size(2);
    int width = x.size(3);

    const float* x_data = x.data_ptr<float>();
    float* out_data = out.data_ptr<float>();
    const float* bn_weight_data = bn_weight.data_ptr<float>();
    const float* bn_bias_data = bn_bias.data_ptr<float>();
    const float* bn_running_mean_data = bn_running_mean.data_ptr<float>();
    const float* bn_running_var_data = bn_running_var.data_ptr<float>();
    const float* conv_weight_data = conv_weight.data_ptr<float>();
    const float* conv_bias_data = conv_bias.data_ptr<float>();

    dim3 threads(16, 8, 8);
    dim3 blocks((batch_size * height * width + threads.x - 1) / threads.x);

    dense_block_forward<<<blocks, threads>>>(
        x_data, out_data,
        bn_weight_data, bn_bias_data, bn_running_mean_data, bn_running_var_data,
        conv_weight_data, conv_bias_data,
        batch_size, in_channels, out_channels, height, width);

    return out;
}
"""

# Load the CUDA kernel
dense_block_forward = load_inline(name="dense_block_forward",
                                  cpp_sources=cuda_code,
                                  extra_cuda_cflags=["--expt-relaxed-constexpr"],
                                  verbose=True)

class ModelNew(nn.Module):
    def __init__(self, num_layers: int, num_input_features: int, growth_rate: int):
        super(ModelNew, self).__init__()
        layers = []
        for i in range(num_layers):
            layers.append(self._make_layer(num_input_features + i * growth_rate, growth_rate))
        self.layers = nn.ModuleList(layers)

    def _make_layer(self, in_features: int, growth_rate: int):
        return nn.Sequential(
            nn.BatchNorm2d(in_features),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_features, growth_rate, kernel_size=3, padding=1, bias=False),
            nn.Dropout(0.0)
        )

    def forward(self, x):
        features = [x]
        for layer in self.layers:
            new_feature = layer(x)
            features.append(new_feature)
            x = torch.cat(features, 1)  # Concatenate along channel axis

            # Custom CUDA kernel for forward pass
            bn_weight = layer[0].weight
            bn_bias = layer[0].bias
            bn_running_mean = layer[0].running_mean
            bn_running_var = layer[0].running_var
            conv_weight = layer[2].weight
            conv_bias = layer[2].bias

            out = torch.zeros_like(x)
            dense_block_forward(x, out, bn_weight, bn_bias, bn_running_mean, bn_running_var, conv_weight, conv_bias)
            x = out

        return x

# Example usage
batch_size = 10
num_layers = 6
num_input_features = 32
growth_rate = 32
height, width = 224, 224

model = ModelNew(num_layers, num_input_features, growth_rate)
input_tensor = torch.rand(batch_size, num_input_features, height, width)
output_tensor = model(input_tensor)
print(output_tensor.shape)