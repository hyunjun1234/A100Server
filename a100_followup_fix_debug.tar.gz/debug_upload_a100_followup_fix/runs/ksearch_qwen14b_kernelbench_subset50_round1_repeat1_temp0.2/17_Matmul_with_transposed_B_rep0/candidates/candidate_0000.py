import torch
import torch.nn as nn
from torch.utils.cpp_extension import load

# Load custom CUDA extension
matmul_kernel = load(name='matmul_kernel', sources=['matmul_kernel.cu'])

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        return matmul_kernel.matmul(A, B)

# CUDA kernel implementation in 'matmul_kernel.cu'
# ```cuda
// #include <torch/extension.h>
// #include <cuda_runtime.h>

// __global__ void matmul_kernel(const float* A, const float* B, float* C, int M, int N, int K) {
//     int row = blockIdx.y * blockDim.y + threadIdx.y;
//     int col = blockIdx.x * blockDim.x + threadIdx.x;

//     if (row < M && col < N) {
//         float sum = 0.0f;
//         for (int k = 0; k < K; ++k) {
//             sum += A[row * K + k] * B[k * N + col];
//         }
//         C[row * N + col] = sum;
//     }
// }

// at::Tensor matmul(const at::Tensor& A, const at::Tensor& B) {
//     int M = A.size(0);
//     int N = B.size(0);
//     int K = A.size(1);

//     auto options = torch::TensorOptions().dtype(torch::kFloat32).device(torch::kCUDA);
//     at::Tensor C = torch::zeros({M, N}, options);

//     dim3 threadsPerBlock(16, 16);
//     dim3 numBlocks((N + threadsPerBlock.x - 1) / threadsPerBlock.x, (M + threadsPerBlock.y - 1) / threadsPerBlock.y);

//     matmul_kernel<<<numBlocks, threadsPerBlock>>>(A.data_ptr<float>(), B.data_ptr<float>(), C.data_ptr<float>(), M, N, K);

//     return C;
// }
// ```

# Testing the implementation
M = 1024 * 2
K = 4096 * 2
N = 2048 * 2

def get_inputs():
    A = torch.rand(M, K, device='cuda')
    B = torch.rand(N, K, device='cuda')
    return [A, B]

def get_init_inputs():
    return []

# Create models
model_ref = Model()
model_opt = ModelNew()

# Get inputs
A, B = get_inputs()

# Perform matrix multiplication with reference implementation
C_ref = model_ref(A, B)

# Perform matrix multiplication with optimized implementation
C_opt = model_opt(A, B)

# Check correctness
assert torch.allclose(C_ref, C_opt, atol=1e-6), "The optimized implementation does not match the reference implementation."

# Measure performance
import time

# Warm-up
for _ in range(10):
    _ = model_ref(A, B)
    _ = model_opt(A, B)

# Measure reference implementation time
start_time = time.time()
for _ in range(100):
    _ = model_ref(A, B)
end_time = time.time()
ref_time = end_time - start_time

# Measure optimized implementation time
start_time = time.time()
for _ in range(100):
    _ = model_opt(A, B)
end_time = time.time()
opt_time = end_time - start_time

print(f"Reference implementation time: {ref_time} seconds")
print(f"Optimized implementation time: {opt_time} seconds")
print(f"Speedup: {ref_time / opt_time:.2f}x")