import torch
import torch.nn as nn
from torch.utils.cpp_extension import load

# Load custom CUDA kernels
cuda_kernels = load(
    name="cuda_kernels",
    sources=["cuda_kernels.cu"],
    verbose=True
)

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features):
        super(ModelNew, self).__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x):
        x = self.linear(x)  # (batch_size, out_features)

        # Summation
        x = cuda_kernels.sum(x, dim=1, keepdim=True)  # (batch_size, 1)

        # Max
        x = cuda_kernels.max(x, dim=1, keepdim=True)  # (batch_size, 1)

        # Average Pooling
        x = cuda_kernels.mean(x, dim=1, keepdim=True)  # (batch_size, 1)

        # LogSumExp
        x = cuda_kernels.logsumexp(x, dim=1, keepdim=True)  # (batch_size, 1)

        # Second LogSumExp
        x = cuda_kernels.logsumexp(x, dim=1, keepdim=True)  # (batch_size, 1)

        return x

batch_size = 1024
in_features = 8192
out_features = 8192

def get_inputs():
    return [torch.rand(batch_size, in_features)]

def get_init_inputs():
    return [in_features, out_features]