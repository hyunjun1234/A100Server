import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

# Load custom CUDA kernels
conv3d_cuda = load_inline(
    name="conv3d_cuda",
    sources=["""__global__ void conv3d_forward(const float* input, const float* weight, float* output,
                                             int batch_size, int in_channels, int out_channels,
                                             int D, int H, int W, int kernel_size) {
        int b = blockIdx.x;
        int o = blockIdx.y;
        int d = threadIdx.x;
        int h = threadIdx.y;
        int w = threadIdx.z;

        if (b < batch_size && o < out_channels && d < D && h < H && w < W) {
            float sum = 0.0f;
            for (int ic = 0; ic < in_channels; ++ic) {
                for (int kd = 0; kd < kernel_size; ++kd) {
                    for (int kh = 0; kh < kernel_size; ++kh) {
                        for (int kw = 0; kw < kernel_size; ++kw) {
                            int id = d + kd - kernel_size / 2;
                            int ih = h + kh - kernel_size / 2;
                            int iw = w + kw - kernel_size / 2;
                            if (id >= 0 && id < D && ih >= 0 && ih < H && iw >= 0 && iw < W) {
                                int in_idx = b * in_channels * D * H * W + ic * D * H * W + id * H * W + ih * W + iw;
                                int weight_idx = o * in_channels * kernel_size * kernel_size * kernel_size + ic * kernel_size * kernel_size * kernel_size + kd * kernel_size * kernel_size + kh * kernel_size + kw;
                                sum += input[in_idx] * weight[weight_idx];
                            }
                        }
                    }
                }
            }
            int out_idx = b * out_channels * D * H * W + o * D * H * W + d * H * W + h * W + w;
            output[out_idx] = sum;
        }
    }"""],
    extra_cflags=["-arch=sm_80", "-std=c++17"],
    verbose=True
)

groupnorm_cuda = load_inline(
    name="groupnorm_cuda",
    sources=["""__global__ void groupnorm_forward(const float* input, float* output,
                                                int batch_size, int num_groups, int channels_per_group,
                                                int D, int H, int W) {
        int b = blockIdx.x;
        int g = blockIdx.y;
        int c = threadIdx.x;
        int d = threadIdx.y;
        int h = threadIdx.z;
        int w = threadIdx.z;

        if (b < batch_size && g < num_groups && c < channels_per_group && d < D && h < H && w < W) {
            int c_start = g * channels_per_group;
            float sum = 0.0f;
            float sum_sq = 0.0f;
            for (int i = 0; i < channels_per_group; ++i) {
                int idx = b * num_groups * channels_per_group * D * H * W + (c_start + i) * D * H * W + d * H * W + h * W + w;
                sum += input[idx];
                sum_sq += input[idx] * input[idx];
            }

            float mean = sum / channels_per_group;
            float var = (sum_sq / channels_per_group) - mean * mean;
            float inv_std = rsqrt(var + 1e-5);

            for (int i = 0; i < channels_per_group; ++i) {
                int idx = b * num_groups * channels_per_group * D * H * W + (c_start + i) * D * H * W + d * H * W + h * W + w;
                output[idx] = (input[idx] - mean) * inv_std;
            }
        }
    }"""],
    extra_cflags=["-arch=sm_80", "-std=c++17"],
    verbose=True
)

mean_cuda = load_inline(
    name="mean_cuda",
    sources=["""__global__ void mean_forward(const float* input, float* output,
                                          int batch_size, int channels, int D, int H, int W) {
        extern __shared__ float shared[];
        int b = blockIdx.x;
        int t = threadIdx.x;

        if (b < batch_size) {
            float sum = 0.0f;
            for (int c = 0; c < channels; ++c) {
                for (int d = 0; d < D; ++d) {
                    for (int h = 0; h < H; ++h) {
                        for (int w = 0; w < W; ++w) {
                            int idx = b * channels * D * H * W + c * D * H * W + d * H * W + h * W + w;
                            sum += input[idx];
                        }
                    }
                }
            }
            shared[t] = sum;
            __syncthreads();

            if (t == 0) {
                float total_sum = 0.0f;
                for (int s = 0; s < blockDim.x; ++s) {
                    total_sum += shared[s];
                }
                output[b] = total_sum / (channels * D * H * W);
            }
        }
    }"""],
    extra_cflags=["-arch=sm_80", "-std=c++17"],
    verbose=True
)

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, num_groups):
        super(ModelNew, self).__init__()
        self.conv_weight = torch.randn(out_channels, in_channels, kernel_size, kernel_size, kernel_size, dtype=torch.float32)
        self.num_groups = num_groups
        self.channels_per_group = out_channels // num_groups

    def forward(self, x):
        batch_size, _, D, H, W = x.shape
        x = x.contiguous()

        # Custom 3D convolution
        x_conv = torch.zeros((batch_size, out_channels, D, H, W), device=x.device, dtype=torch.float32)
        block_size = (D, H, W)
        grid_size = (batch_size, out_channels)
        conv3d_cuda.conv3d_forward[x.device.type](x, self.conv_weight, x_conv, batch_size, x.shape[1], out_channels, D, H, W, self.conv_weight.shape[2], block=block_size, grid=grid_size)

        # Custom group normalization
        x_norm = torch.zeros_like(x_conv)
        block_size = (self.channels_per_group, D, H, W)
        grid_size = (batch_size, self.num_groups)
        groupnorm_cuda.groupnorm_forward[x.device.type](x_conv, x_norm, batch_size, self.num_groups, self.channels_per_group, D, H, W, block=block_size, grid=grid_size)

        # Custom mean computation
        x_mean = torch.zeros((batch_size,), device=x.device, dtype=torch.float32)
        block_size = (batch_size,)
        grid_size = (batch_size,)
        mean_cuda.mean_forward[x.device.type](x_norm, x_mean, batch_size, x_norm.shape[1], D, H, W, block=block_size, grid=grid_size, shared_mem=batch_size * sizeof(float))

        return x_mean

# Example usage
batch_size = 128
in_channels = 3
out_channels = 24
D, H, W = 24, 32, 32
kernel_size = 3
num_groups = 8

model = ModelNew(in_channels, out_channels, kernel_size, num_groups)
inputs = torch.rand(batch_size, in_channels, D, H, W)
output = model(inputs)
print(output.shape)