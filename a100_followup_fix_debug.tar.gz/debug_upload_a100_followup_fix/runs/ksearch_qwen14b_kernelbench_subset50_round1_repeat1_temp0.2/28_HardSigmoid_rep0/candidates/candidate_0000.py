import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline
import os

# Define the CUDA kernel
cuda_kernel_code = """
extern "C" __global__
void hard_sigmoid_kernel(float* input, float* output, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        float x = input[idx];
        output[idx] = max(0.0f, min(1.0f, 0.2f * x + 0.5f));
    }
}
"""

# Compile the CUDA kernel
hard_sigmoid_module = load_inline(
    name="hard_sigmoid_module",
    cpp_sources=[],
    cuda_sources=[cuda_kernel_code],
    extra_cuda_cflags=["-arch=sm_80"],  # For A100, sm_80 is the compute capability
    verbose=True
)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Ensure the input tensor is on the GPU
        if not x.is_cuda:
            x = x.cuda()

        # Create an output tensor on the GPU
        output = torch.empty_like(x)

        # Get the grid and block dimensions
        threads_per_block = 256
        blocks_per_grid = (x.numel() + threads_per_block - 1) // threads_per_block

        # Launch the CUDA kernel
        hard_sigmoid_module.hard_sigmoid_kernel[blocks_per_grid, threads_per_block](x, output, x.numel())

        return output

# Test the implementation
def test_model():
    batch_size = 4096
    dim = 393216
    x = torch.rand(batch_size, dim)

    # Reference implementation
    model_ref = Model()
    y_ref = model_ref(x)

    # Optimized implementation
    model_opt = ModelNew()
    y_opt = model_opt(x)

    # Check correctness
    assert torch.allclose(y_ref, y_opt, atol=1e-6), "The optimized implementation does not match the reference."

    print("Test passed!")

# Run the test
test_model()