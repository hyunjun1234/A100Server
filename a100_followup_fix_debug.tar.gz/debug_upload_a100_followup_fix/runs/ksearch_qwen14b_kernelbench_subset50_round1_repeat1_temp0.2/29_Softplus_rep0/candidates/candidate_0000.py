import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline
import os

# Define the CUDA kernel
cuda_kernel_code = """
__global__ void softplus_kernel(float* output, const float* input, int n) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        output[idx] = logf(1.0f + expf(input[idx]));
    }
}
"""

# Load the CUDA kernel as a PyTorch extension
os.environ['TORCH_CUDA_ARCH_LIST'] = '8.0'
softplus_cuda = load_inline(name='softplus_cuda',
                             cpp_sources=[],
                             cuda_sources=[cuda_kernel_code],
                             extra_cuda_cflags=['-arch=sm_80'])

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Ensure the input tensor is on the GPU
        x = x.contiguous().cuda()
        output = torch.empty_like(x).cuda()

        # Launch the CUDA kernel
        n = x.numel()
        threads_per_block = 256
        blocks_per_grid = (n + threads_per_block - 1) // threads_per_block
        softplus_cuda.softplus_kernel[blocks_per_grid, threads_per_block](output.data_ptr(), x.data_ptr(), n)

        return output.cpu()

# Test the implementation
if __name__ == "__main__":
    batch_size = 4096
    dim = 393216
    x = torch.rand(batch_size, dim)

    model_ref = Model()
    model_opt = ModelNew()

    y_ref = model_ref(x)
    y_opt = model_opt(x)

    # Check correctness
    assert torch.allclose(y_ref, y_opt, atol=1e-6), "Output mismatch"

    # Measure performance
    import time

    start_time = time.time()
    for _ in range(10):
        _ = model_ref(x)
    end_time = time.time()
    print(f"Reference model time: {end_time - start_time:.4f} seconds")

    start_time = time.time()
    for _ in range(10):
        _ = model_opt(x)
    end_time = time.time()
    print(f"Optimized model time: {end_time - start_time:.4f} seconds")