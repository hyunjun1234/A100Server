import torch
import torch.nn as nn
from torch.utils.cpp_extension import load
import os

# Load the custom CUDA kernel
kernel_dir = os.path.dirname(os.path.abspath(__file__))
matrix_mult_cuda = load(name='matrix_mult_cuda',
                        sources=[os.path.join(kernel_dir, 'matrix_mult_cuda.cu')],
                        extra_cflags=['-arch=sm_80'])

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs matrix multiplication using a custom CUDA kernel.

        Args:
            A: Input tensor of shape (M, K).
            B: Input tensor of shape (K, N).

        Returns:
            Output tensor of shape (M, N).
        """
        return matrix_mult_cuda.matrix_multiply(A, B)

# Example usage
if __name__ == "__main__":
    M = 1024 * 2
    K = 4096 * 2
    N = 2048 * 2

    A = torch.rand(M, K).cuda()
    B = torch.rand(K, N).cuda()

    model_new = ModelNew().cuda()
    C = model_new(A, B)

    print("Output tensor shape:", C.shape)