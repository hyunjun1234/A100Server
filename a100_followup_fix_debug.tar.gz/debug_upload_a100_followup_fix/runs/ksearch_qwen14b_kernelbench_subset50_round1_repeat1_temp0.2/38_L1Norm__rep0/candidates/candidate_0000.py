import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

# Inline CUDA code for L1 normalization
cuda_code = """
__global__ void l1_normalize_kernel(float* input, float* output, int batch_size, int dim) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= batch_size * dim) return;

    int batch_idx = idx / dim;
    int elem_idx = idx % dim;

    // Calculate L1 norm for the current batch
    float sum_abs = 0.0f;
    for (int i = 0; i < dim; ++i) {
        sum_abs += fabs(input[batch_idx * dim + i]);
    }

    // Normalize the current element
    output[idx] = input[idx] / sum_abs;
}
"""

# Load the custom CUDA kernel
l1_normalize_cuda = load_inline(
    name="l1_normalize_cuda",
    sources=[cuda_code],
    extra_cflags=["-O3"],
    extra_cuda_cflags=["-arch=sm_80", "-lineinfo"]
)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, dim = x.size(0), x.size(1)
        output = torch.empty_like(x)

        # Get CUDA stream and device properties
        stream = torch.cuda.current_stream()
        block_size = 256
        grid_size = (batch_size * dim + block_size - 1) // block_size

        # Launch the custom CUDA kernel
        l1_normalize_cuda.l1_normalize_kernel[grid_size, block_size](
            x.contiguous().data_ptr(),
            output.data_ptr(),
            batch_size,
            dim
        )

        return output

# Helper functions to test the implementation
def get_inputs():
    x = torch.rand(32768, 65535).cuda()
    return [x]

def check_correctness(model, model_new, inputs):
    ref_output = model(*inputs)
    new_output = model_new(*inputs)
    assert torch.allclose(ref_output, new_output, atol=1e-6), "Outputs do not match within tolerance"

# Example usage
if __name__ == "__main__":
    batch_size = 32768
    dim = 65535
    x = torch.rand(batch_size, dim).cuda()

    model = Model().cuda()
    model_new = ModelNew().cuda()

    # Check correctness
    check_correctness(model, model_new, [x])

    # Measure performance
    import time
    torch.manual_seed(0)
    ref_time = []
    new_time = []

    for _ in range(10):
        torch.cuda.synchronize()
        start = time.time()
        _ = model(x)
        torch.cuda.synchronize()
        end = time.time()
        ref_time.append(end - start)

        torch.cuda.synchronize()
        start = time.time()
        _ = model_new(x)
        torch.cuda.synchronize()
        end = time.time()
        new_time.append(end - start)

    print(f"Reference implementation time: {sum(ref_time) / len(ref_time)} s")
    print(f"Custom CUDA implementation time: {sum(new_time) / len(new_time)} s")
    print(f"Speedup: {sum(ref_time) / sum(new_time)}x")