import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.cpp_extension

# Load the CUDA extension
gru_cuda = torch.utils.cpp_extension.load(name='gru_cuda',
                                          sources=['gru_cuda_kernel.cu'])

class ModelNew(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers=3, bias=True, batch_first=False):
        super(ModelNew, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bias = bias
        self.batch_first = batch_first
        
        # Initialize weights and biases
        self.weight_ih = nn.Parameter(torch.randn(num_layers, 3 * hidden_size, input_size))
        self.weight_hh = nn.Parameter(torch.randn(num_layers, 3 * hidden_size, hidden_size))
        if bias:
            self.bias_ih = nn.Parameter(torch.randn(num_layers, 3 * hidden_size))
            self.bias_hh = nn.Parameter(torch.randn(num_layers, 3 * hidden_size))
        else:
            self.register_parameter('bias_ih', None)
            self.register_parameter('bias_hh', None)

    def forward(self, x, h0):
        if self.batch_first:
            x = x.transpose(0, 1)
        
        output = gru_cuda.gru_forward(x, h0, self.weight_ih, self.weight_hh, self.bias_ih, self.bias_hh, self.num_layers)
        
        if self.batch_first:
            output = output.transpose(0, 1)
        
        return output

# Test code
batch_size = 10
seq_len = 512
input_size = 128
hidden_size = 256
num_layers = 6

def get_inputs():
    return [torch.rand(seq_len, batch_size, input_size), torch.rand((num_layers, batch_size, hidden_size))]

def get_init_inputs():
    return [input_size, hidden_size, num_layers]

# Example usage
if __name__ == "__main__":
    # Get inputs
    x, h0 = get_inputs()
    
    # Create model instances
    model_ref = Model(input_size, hidden_size, num_layers)
    model_new = ModelNew(input_size, hidden_size, num_layers)
    
    # Forward pass
    output_ref = model_ref(x, h0)
    output_new = model_new(x, h0)
    
    # Check correctness
    assert torch.allclose(output_ref, output_new, atol=1e-5), "Output mismatch!"
    
    print("Correctness check passed.")