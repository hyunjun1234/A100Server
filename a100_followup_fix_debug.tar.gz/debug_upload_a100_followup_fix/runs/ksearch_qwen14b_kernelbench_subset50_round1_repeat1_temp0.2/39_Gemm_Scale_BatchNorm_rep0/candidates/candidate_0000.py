import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline
import math

# Inline CUDA code
cuda_code = """
extern "C" __global__ void gemm_scale_bn_forward(
    const float* input, const float* weight, const float* bias,
    const float* scale, const float* running_mean, const float* running_var,
    float* output, int batch_size, int in_features, int out_features, float eps) {
    int batch_idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (batch_idx >= batch_size) return;

    for (int out_idx = 0; out_idx < out_features; ++out_idx) {
        float sum = 0.0f;
        for (int in_idx = 0; in_idx < in_features; ++in_idx) {
            sum += input[batch_idx * in_features + in_idx] * weight[out_idx * in_features + in_idx];
        }
        output[batch_idx * out_features + out_idx] = sum * scale[out_idx] + bias[out_idx];
    }

    // Batch normalization
    for (int out_idx = 0; out_idx < out_features; ++out_idx) {
        float x = output[batch_idx * out_features + out_idx];
        float normalized = (x - running_mean[out_idx]) / sqrtf(running_var[out_idx] + eps);
        output[batch_idx * out_features + out_idx] = normalized;
    }
}
"""

# Load the CUDA module
gemm_scale_bn_module = load_inline(name="gemm_scale_bn_module", sources=[cuda_code], verbose=True)

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scale_shape, eps=1e-5, momentum=0.1):
        super(ModelNew, self).__init__()
        self.weight = nn.Parameter(torch.randn(out_features, in_features))
        self.bias = nn.Parameter(torch.zeros(out_features))
        self.scale = nn.Parameter(torch.randn(scale_shape))
        self.running_mean = torch.zeros(out_features)
        self.running_var = torch.ones(out_features)
        self.eps = eps

    def forward(self, x):
        batch_size = x.size(0)
        output = torch.empty_like(x)

        # Launch the CUDA kernel
        threads_per_block = 256
        blocks_per_grid = (batch_size + threads_per_block - 1) // threads_per_block
        gemm_scale_bn_module.gemm_scale_bn_forward[x.device.type](
            x, self.weight, self.bias, self.scale, self.running_mean, self.running_var,
            output, batch_size, x.size(1), self.weight.size(0), self.eps,
            grid=(blocks_per_grid,), block=(threads_per_block,)
        )

        return output

# Example usage
batch_size = 16384
in_features = 4096
out_features = 4096
scale_shape = (out_features,)

model_new = ModelNew(in_features, out_features, scale_shape)
input_data = torch.rand(batch_size, in_features)
output = model_new(input_data)
print(output.shape)