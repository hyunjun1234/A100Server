import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

# CUDA kernel code for batched matrix multiplication
cuda_kernel_code = """
__global__ void batched_gemm(float* A, float* B, float* C, int batch_size, int m, int k, int n) {
    int batch = blockIdx.z;
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (batch < batch_size && row < m && col < n) {
        float sum = 0.0f;
        for (int i = 0; i < k; ++i) {
            sum += A[batch * m * k + row * k + i] * B[batch * k * n + i * n + col];
        }
        C[batch * m * n + row * n + col] = sum;
    }
}
"""

# Load the CUDA kernel into PyTorch
batched_gemm_module = load_inline(name="batched_gemm_module", 
                                  sources=[cuda_kernel_code], 
                                  extra_cuda_cflags=["--expt-relaxed-constexpr"])

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        batch_size, m, k = A.shape
        _, k, n = B.shape
        
        # Ensure tensors are on the correct device
        A = A.contiguous().cuda()
        B = B.contiguous().cuda()
        
        # Allocate output tensor
        C = torch.zeros((batch_size, m, n), dtype=torch.float32, device='cuda')
        
        # Define grid and block dimensions
        threads_per_block = (16, 16, 1)
        blocks_per_grid_x = (n + threads_per_block[0] - 1) // threads_per_block[0]
        blocks_per_grid_y = (m + threads_per_block[1] - 1) // threads_per_block[1]
        blocks_per_grid_z = batch_size
        
        # Launch the CUDA kernel
        batched_gemm_module.batched_gemm[A, B, C, batch_size, m, k, n](blocks=(blocks_per_grid_x, blocks_per_grid_y, blocks_per_grid_z), threads=threads_per_block)
        
        return C

# Test the new model
batch_size = 128
m = 128 * 4
k = 256 * 4
n = 512 * 4

def get_inputs():
    A = torch.rand(batch_size, m, k)
    B = torch.rand(batch_size, k, n)
    return [A, B]

def get_init_inputs():
    return []  # No special initialization inputs needed

# Example usage
A, B = get_inputs()
model_ref = Model()
model_opt = ModelNew()

# Run reference implementation
C_ref = model_ref(A, B)

# Run optimized implementation
C_opt = model_opt(A, B)

# Check correctness
assert torch.allclose(C_ref, C_opt, atol=1e-5)

# Measure performance
import time

# Warm-up
for _ in range(10):
    _ = model_ref(A, B)
    _ = model_opt(A, B)

# Measure reference time
start_time = time.time()
for _ in range(100):
    _ = model_ref(A, B)
ref_time = time.time() - start_time

# Measure optimized time
start_time = time.time()
for _ in range(100):
    _ = model_opt(A, B)
opt_time = time.time() - start_time

print(f"Reference time: {ref_time} seconds")
print(f"Optimized time: {opt_time} seconds")
print(f"Speedup: {ref_time / opt_time}")