import torch
import torch.nn as nn
from torch.utils.cpp_extension import load

# Load CUDA extensions
conv_transpose_cuda = load(name="conv_transpose_cuda", sources=["conv_transpose_cuda.cpp"], extra_cflags=["-Xcompiler", "-fopenmp"], extra_cuda_cflags=["-Xcompiler", "-fopenmp"])

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, output_padding, sum_weight, norm_shape, pool_kernel_size):
        super(ModelNew, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.output_padding = output_padding
        self.sum_weight = nn.Parameter(torch.tensor(sum_weight))
        self.norm_shape = norm_shape
        self.pool_kernel_size = pool_kernel_size
        self.eps = 1e-5  # Small epsilon value for numerical stability

    def forward(self, x):
        # 3D Transposed Convolution
        x = conv_transpose_cuda.conv_transpose3d(x, self.out_channels, self.kernel_size, self.stride, self.padding, self.output_padding)
        
        # Addition
        x = x + self.sum_weight
        
        # Layer Normalization
        mean = x.mean(dim=-1, keepdim=True)
        variance = x.var(dim=-1, unbiased=False, keepdim=True)
        normalized = (x - mean) / torch.sqrt(variance + self.eps)
        x = normalized * self.norm_shape[0]  # Scale by the norm_shape dimension
        
        # Average Pooling
        x = conv_transpose_cuda.avg_pool3d(x, self.pool_kernel_size)
        
        # GELU Activation
        x = 0.5 * x * (1 + torch.tanh(torch.sqrt(2 / torch.pi) * (x + 0.044715 * torch.pow(x, 3))))
        
        return x

# Example usage
batch_size = 32
in_channels = 32
out_channels = 64
depth, height, width = 16, 32, 32
kernel_size = (3, 3, 3)
stride = (2, 2, 2)
padding = (1, 1, 1)
output_padding = (1, 1, 1)
sum_weight = 1.0
norm_shape = (out_channels,)
pool_kernel_size = (2, 2, 2)

model_new = ModelNew(in_channels, out_channels, kernel_size, stride, padding, output_padding, sum_weight, norm_shape, pool_kernel_size)
input_tensor = torch.rand(batch_size, in_channels, depth, height, width)
output = model_new(input_tensor)
print(output.shape)