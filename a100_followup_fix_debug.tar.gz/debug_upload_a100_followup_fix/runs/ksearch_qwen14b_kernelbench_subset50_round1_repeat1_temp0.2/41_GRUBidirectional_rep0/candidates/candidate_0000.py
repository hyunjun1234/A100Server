import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.cpp_extension import load
import os

# Load the custom CUDA kernel
cuda_kernel_path = os.path.join(os.path.dirname(__file__), 'gru_cuda_kernel.cu')
gru_cuda = load(name='gru_cuda', sources=[cuda_kernel_path])

class ModelNew(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers=3, bias=True, batch_first=False):
        super(ModelNew, self).__init__()
        
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bias = bias
        self.batch_first = batch_first
        
        self.weight_ih_l0 = nn.Parameter(torch.randn(3 * hidden_size, input_size))
        self.weight_hh_l0 = nn.Parameter(torch.randn(3 * hidden_size, hidden_size))
        self.bias_ih_l0 = nn.Parameter(torch.randn(3 * hidden_size)) if bias else None
        self.bias_hh_l0 = nn.Parameter(torch.randn(3 * hidden_size)) if bias else None
        
        self.weight_ih_l0_reverse = nn.Parameter(torch.randn(3 * hidden_size, input_size))
        self.weight_hh_l0_reverse = nn.Parameter(torch.randn(3 * hidden_size, hidden_size))
        self.bias_ih_l0_reverse = nn.Parameter(torch.randn(3 * hidden_size)) if bias else None
        self.bias_hh_l0_reverse = nn.Parameter(torch.randn(3 * hidden_size)) if bias else None
        
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            nn.init.uniform_(weight, -stdv, stdv)

    def forward(self, x, h0):
        if self.batch_first:
            x = x.transpose(0, 1)
        
        seq_len, batch_size, _ = x.shape
        h0_forward = h0[:self.num_layers, :, :]
        h0_backward = h0[self.num_layers:, :, :]
        
        output_forward = torch.zeros_like(x)
        output_backward = torch.zeros_like(x)
        
        gru_cuda.forward_pass(
            x, 
            h0_forward, 
            self.weight_ih_l0, 
            self.weight_hh_l0, 
            self.bias_ih_l0, 
            self.bias_hh_l0, 
            output_forward
        )
        
        gru_cuda.backward_pass(
            x.flip(dims=(0,)), 
            h0_backward, 
            self.weight_ih_l0_reverse, 
            self.weight_hh_l0_reverse, 
            self.bias_ih_l0_reverse, 
            self.bias_hh_l0_reverse, 
            output_backward
        )
        
        output_backward = output_backward.flip(dims=(0,))
        
        output = torch.cat((output_forward, output_backward), dim=2)
        
        if self.batch_first:
            output = output.transpose(0, 1)
        
        h_n_forward = output_forward[-1, :, :]
        h_n_backward = output_backward[0, :, :]
        h_n = torch.cat((h_n_forward, h_n_backward), dim=0)
        
        return output, h_n

# Example usage
batch_size = 10
seq_len = 512
input_size = 128
hidden_size = 256
num_layers = 6

model_new = ModelNew(input_size, hidden_size, num_layers)
x, h0 = get_inputs()
output, h_n = model_new(x, h0)
print(output.shape, h_n.shape)