import torch
import torch.nn as nn
from torch.utils.cpp_extension import load

# Load the custom CUDA extension
custom_cuda_kernels = load(name='custom_cuda_kernels', sources=['custom_cuda_kernels.cpp'])

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape):
        super(ModelNew, self).__init__()
        self.conv_transpose = nn.ConvTranspose2d(in_channels, out_channels, kernel_size)
        self.bias = nn.Parameter(torch.randn(bias_shape))

    def forward(self, x):
        # Transposed Convolution
        x = self.conv_transpose(x)
        
        # Global Average Pooling
        batch_size, channels, height, width = x.size()
        x = custom_cuda_kernels.global_avg_pool_2d(x)
        
        # Bias Addition
        x = custom_cuda_kernels.add_bias(x, self.bias)
        
        # Log-Sum-Exp
        x = custom_cuda_kernels.log_sum_exp(x)
        
        # Summation
        x = custom_cuda_kernels.sum_2d(x)
        
        # Multiplication
        x = custom_cuda_kernels.multiply_scalar(x, 10.0)
        
        return x

# Example usage
batch_size = 16
in_channels = 64
out_channels = 128
height = width = 512
kernel_size = 3
bias_shape = (out_channels, 1, 1)

model_new = ModelNew(in_channels, out_channels, kernel_size, bias_shape)
inputs = torch.rand(batch_size, in_channels, height, width)
output = model_new(inputs)
print(output)