import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline
import os

# CUDA kernel code
cuda_kernel_code = r"""
#include <torch/extension.h>
#include <vector>

__global__ void avg_pool_1d_forward_kernel(
    const float* input, float* output,
    int batch_size, int in_channels, int input_length,
    int kernel_size, int stride, int padding) {
    
    int batch_idx = blockIdx.x;
    int channel_idx = blockIdx.y;
    int out_idx = threadIdx.x;

    if (batch_idx >= batch_size || channel_idx >= in_channels || out_idx >= (input_length + 2 * padding - kernel_size) / stride + 1) {
        return;
    }

    int start_idx = out_idx * stride - padding;
    float sum = 0.0f;

    for (int i = 0; i < kernel_size; ++i) {
        int input_idx = start_idx + i;
        if (input_idx >= 0 && input_idx < input_length) {
            sum += input[(batch_idx * in_channels + channel_idx) * input_length + input_idx];
        }
    }

    output[(batch_idx * in_channels + channel_idx) * ((input_length + 2 * padding - kernel_size) / stride + 1) + out_idx] = sum / kernel_size;
}

at::Tensor avg_pool_1d_forward(
    const at::Tensor& input, int kernel_size, int stride, int padding) {
    
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int input_length = input.size(2);
    int output_length = (input_length + 2 * padding - kernel_size) / stride + 1;

    at::Tensor output = at::zeros({batch_size, in_channels, output_length}, input.options());

    dim3 threads(output_length);
    dim3 blocks(batch_size, in_channels);

    avg_pool_1d_forward_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        batch_size, in_channels, input_length, kernel_size, stride, padding);

    return output;
}
"""

# Compile the CUDA kernel
if not os.path.exists("kernel.so"):
    load_inline(name="kernel", cpp_sources=[cuda_kernel_code], verbose=True)

from kernel import avg_pool_1d_forward

class ModelNew(nn.Module):
    """
    Optimized model that performs 1D Average Pooling using a custom CUDA kernel.
    """
    def __init__(self, kernel_size: int, stride: int = 1, padding: int = 0):
        """
        Initializes the 1D Average Pooling layer.

        Args:
            kernel_size (int): Size of the pooling window.
            stride (int, optional): Stride of the pooling operation. Defaults to 1.
            padding (int, optional): Padding applied to the input tensor. Defaults to 0.
        """
        super(ModelNew, self).__init__()
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Applies 1D Average Pooling to the input tensor using a custom CUDA kernel.

        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_channels, input_length).

        Returns:
            torch.Tensor: Output tensor with 1D Average Pooling applied, shape (batch_size, in_channels, output_length).
        """
        return avg_pool_1d_forward(x, self.kernel_size, self.stride, self.padding)

# Test the optimized implementation
batch_size = 64
in_channels = 128
input_length = 65536
kernel_size = 8
stride = 1
padding = 4

def get_inputs():
    x = torch.rand(batch_size, in_channels, input_length)
    return [x]

def get_init_inputs():
    return [kernel_size, stride, padding]

# Verify correctness and performance
x = get_inputs()[0]
model_ref = Model(kernel_size, stride, padding)
model_opt = ModelNew(kernel_size, stride, padding)

output_ref = model_ref(x)
output_opt = model_opt(x)

# Check correctness
assert torch.allclose(output_ref, output_opt, atol=1e-5), "The outputs do not match."

# Measure performance
import time

start_time = time.time()
for _ in range(100):
    _ = model_ref(x)
ref_time = time.time() - start_time

start_time = time.time()
for _ in range(100):
    _ = model_opt(x)
opt_time = time.time() - start_time

print(f"Reference time: {ref_time:.4f} seconds")
print(f"Optimized time: {opt_time:.4f} seconds")
print(f"Speedup: {ref_time / opt_time:.2fx}")