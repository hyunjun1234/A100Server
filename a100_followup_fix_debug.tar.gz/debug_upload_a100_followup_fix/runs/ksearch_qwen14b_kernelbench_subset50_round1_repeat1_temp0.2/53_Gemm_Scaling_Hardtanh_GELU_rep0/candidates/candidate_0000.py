import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.cpp_extension import load_inline
import os

# Define the CUDA kernels
cuda_code = """
#include <torch/extension.h>
#include <vector>

__global__ void gemm_kernel(const float* A, const float* B, float* C, int m, int n, int k) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < m && col < n) {
        float sum = 0.0f;
        for (int i = 0; i < k; ++i) {
            sum += A[row * k + i] * B[i * n + col];
        }
        C[row * n + col] = sum;
    }
}

__global__ void scale_kernel(float* x, float scaling_factor, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        x[idx] *= scaling_factor;
    }
}

__global__ void hardtanh_kernel(float* x, float min_val, float max_val, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        x[idx] = (x[idx] < min_val) ? min_val : ((x[idx] > max_val) ? max_val : x[idx]);
    }
}

__global__ void gelu_kernel(float* x, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        float cdf = 0.5f * (1.0f + tanhf(sqrt(2.0f / M_PI) * (x[idx] + 0.044715f * powf(x[idx], 3))));
        x[idx] *= cdf;
    }
}
"""

# Load the CUDA kernels
cuda_module = load_inline(name='custom_cuda_kernels',
                          sources=[cuda_code],
                          extra_cuda_cflags=['-arch=sm_80'])

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scaling_factor, hardtanh_min, hardtanh_max):
        super(ModelNew, self).__init__()
        self.weight = nn.Parameter(torch.randn(out_features, in_features))
        self.bias = nn.Parameter(torch.randn(out_features))
        self.scaling_factor = scaling_factor
        self.hardtanh_min = hardtanh_min
        self.hardtanh_max = hardtanh_max

    def forward(self, x):
        batch_size, in_features = x.size()
        out_features = self.weight.size(0)

        # GEMM
        output = torch.zeros(batch_size, out_features, device=x.device)
        cuda_module.gemm_kernel[x.size(0), 128]((x.contiguous().view(-1).data_ptr(), self.weight.t().contiguous().view(-1).data_ptr(), output.data_ptr(), batch_size, out_features, in_features))

        # Add bias
        output += self.bias

        # Scale
        cuda_module.scale_kernel[output.size(0), 128](output.data_ptr(), self.scaling_factor, output.numel())

        # Hardtanh
        cuda_module.hardtanh_kernel[output.size(0), 128](output.data_ptr(), self.hardtanh_min, self.hardtanh_max, output.numel())

        # GELU
        cuda_module.gelu_kernel[output.size(0), 128](output.data_ptr(), output.numel())

        return output

# Test the implementation
batch_size = 2048
in_features = 8192
out_features = 8192
scaling_factor = 0.5
hardtanh_min = -2
hardtanh_max = 2

model_new = ModelNew(in_features, out_features, scaling_factor, hardtanh_min, hardtanh_max)
inputs = torch.rand(batch_size, in_features)

# Forward pass
output_new = model_new(inputs)

print(output_new)