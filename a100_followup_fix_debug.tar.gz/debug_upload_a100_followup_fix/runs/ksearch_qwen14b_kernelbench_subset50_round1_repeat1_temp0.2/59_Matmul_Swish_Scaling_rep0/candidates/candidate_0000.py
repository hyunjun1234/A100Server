import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.cpp_extension import load_inline

# Define the CUDA kernel
cuda_code = """
__global__ void matmul_swish_scaling(float* input, float* weight, float* bias, float* output, float* scaling_factor, int batch_size, int in_features, int out_features) {
    extern __shared__ float shared_mem[];
    float* shared_weights = shared_mem;
    float* shared_input = &shared_mem[out_features * in_features];

    int block_idx = blockIdx.x;
    int thread_idx = threadIdx.x;
    int row = block_idx / out_features;
    int col = block_idx % out_features;

    // Load weights into shared memory
    if (threadIdx.x < out_features * in_features) {
        shared_weights[threadIdx.x] = weight[threadIdx.x];
    }
    // Load input into shared memory
    if (row < batch_size && col < in_features) {
        shared_input[threadIdx.x] = input[row * in_features + col];
    }
    __syncthreads();

    float sum = 0.0f;
    if (row < batch_size && col < out_features) {
        for (int k = 0; k < in_features; ++k) {
            sum += shared_weights[col * in_features + k] * shared_input[row * in_features + k];
        }
        sum += bias[col];
        float swish = sum * 1.0f / (1.0f + exp(-sum));
        output[row * out_features + col] = swish * scaling_factor[0];
    }
}
"""

# Compile the CUDA kernel
matmul_swish_scaling = load_inline(name="matmul_swish_scaling",
                                   cpp_sources=[],
                                   cuda_sources=[cuda_code],
                                   extra_cuda_cflags=["-O3", "-arch=sm_80"])

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scaling_factor):
        super(ModelNew, self).__init__()
        self.weight = nn.Parameter(torch.randn(out_features, in_features))
        self.bias = nn.Parameter(torch.randn(out_features))
        self.scaling_factor = torch.tensor([scaling_factor], dtype=torch.float32)

    def forward(self, x):
        batch_size = x.size(0)
        output = torch.zeros((batch_size, self.weight.size(0)), device=x.device, dtype=torch.float32)
        
        # Launch the CUDA kernel
        threads_per_block = 256
        blocks_per_grid = (batch_size * self.weight.size(0) + threads_per_block - 1) // threads_per_block
        shared_mem_size = (self.weight.size(0) * self.weight.size(1) + batch_size * self.weight.size(1)) * sizeof(float)
        
        matmul_swish_scaling.matmul_swish_scaling[x.device.type](x.contiguous(), 
                                                             self.weight.contiguous(), 
                                                             self.bias.contiguous(), 
                                                             output.contiguous(), 
                                                             self.scaling_factor.contiguous(),
                                                             batch_size,
                                                             self.weight.size(1),
                                                             self.weight.size(0),
                                                             grid=(blocks_per_grid, 1, 1),
                                                             block=(threads_per_block, 1, 1),
                                                             sharedMem=shared_mem_size)
        
        return output

# Testing
batch_size = 128
in_features = 32768
out_features = 32768
scaling_factor = 2.0

model_ref = Model(in_features, out_features, scaling_factor)
model_opt = ModelNew(in_features, out_features, scaling_factor)

input_data = torch.rand(batch_size, in_features, device='cuda')

output_ref = model_ref(input_data)
output_opt = model_opt(input_data)

# Check correctness
assert torch.allclose(output_ref, output_opt, atol=1e-6), "Output mismatch!"

# Measure performance
import time

start_time = time.time()
for _ in range(100):
    _ = model_ref(input_data)
end_time = time.time()
print(f"Reference Model Time: {end_time - start_time} seconds")

start_time = time.time()
for _ in range(100):
    _ = model_opt(input_data)
end_time = time.time()
print(f"Optimized Model Time: {end_time - start_time} seconds")