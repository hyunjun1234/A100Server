import torch
from torch.utils.cpp_extension import load
import os

# Load the custom CUDA kernel
custom_cuda_module = load(
    name='custom_conv3d',
    sources=[os.path.join(os.path.dirname(__file__), 'custom_conv3d_kernel.cu')],
    verbose=True
)

class ModelNew(torch.nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, dilation=1, groups=1, bias=False):
        super(ModelNew, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.bias = bias
        
        # Initialize weight and bias
        self.weight = torch.nn.Parameter(torch.randn(out_channels, in_channels // groups, kernel_size, kernel_size, 1))
        if bias:
            self.bias = torch.nn.Parameter(torch.randn(out_channels))
        else:
            self.register_parameter('bias', None)

    def forward(self, x):
        return custom_cuda_module.custom_conv3d_forward(x, self.weight, self.bias, self.stride, self.padding, self.dilation, self.groups)

# Custom CUDA kernel implementation (custom_conv3d_kernel.cu)
"""
#include <torch/extension.h>
#include <vector>

// CUDA kernel for 3D convolution
__global__ void conv3d_forward_kernel(
    const float* input, 
    const float* weight, 
    float* output, 
    int batch_size, 
    int in_channels, 
    int out_channels, 
    int kernel_size, 
    int height, 
    int width, 
    int depth, 
    int stride, 
    int padding, 
    int dilation, 
    int groups
) {
    // Thread index
    int batch_idx = blockIdx.x;
    int out_channel_idx = blockIdx.y;
    int in_channel_group_idx = blockIdx.z;
    int out_channel_group_size = out_channels / groups;

    int out_channel_global_idx = out_channel_idx * out_channel_group_size + in_channel_group_idx;
    int in_channel_global_idx = in_channel_group_idx * (in_channels / groups);

    // Compute output dimensions
    int out_height = (height + 2 * padding - dilation * (kernel_size - 1) - 1) / stride + 1;
    int out_width = (width + 2 * padding - dilation * (kernel_size - 1) - 1) / stride + 1;
    int out_depth = depth; // Assuming depth is not affected by stride or padding

    int thread_idx = threadIdx.x;
    int num_threads = blockDim.x;

    // Compute the starting index for this thread
    int start_out_height = thread_idx;
    int stride_height = num_threads;

    // Iterate over output height
    for (int h = start_out_height; h < out_height; h += stride_height) {
        for (int w = 0; w < out_width; ++w) {
            for (int d = 0; d < out_depth; ++d) {
                float sum = 0.0f;
                for (int k_h = 0; k_h < kernel_size; ++k_h) {
                    for (int k_w = 0; k_w < kernel_size; ++k_w) {
                        int input_h = h * stride + k_h * dilation - padding;
                        int input_w = w * stride + k_w * dilation - padding;
                        if (input_h >= 0 && input_h < height && input_w >= 0 && input_w < width) {
                            for (int c = 0; c < in_channels / groups; ++c) {
                                int input_idx = (batch_idx * in_channels + in_channel_global_idx + c) * height * width * depth + input_h * width * depth + input_w * depth + d;
                                int weight_idx = (out_channel_global_idx * (in_channels / groups) + c) * kernel_size * kernel_size * 1 + k_h * kernel_size * 1 + k_w * 1 + 0;
                                sum += input[input_idx] * weight[weight_idx];
                            }
                        }
                    }
                }
                if (bias != nullptr) {
                    sum += bias[out_channel_global_idx];
                }
                int output_idx = (batch_idx * out_channels + out_channel_global_idx) * out_height * out_width * out_depth + h * out_width * out_depth + w * out_depth + d;
                output[output_idx] = sum;
            }
        }
    }
}

// Wrapper function for PyTorch
at::Tensor custom_conv3d_forward(
    at::Tensor input, 
    at::Tensor weight, 
    at::Tensor bias, 
    int stride, 
    int padding, 
    int dilation, 
    int groups
) {
    // Get input dimensions
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int height = input.size(2);
    int width = input.size(3);
    int depth = input.size(4);

    int out_channels = weight.size(0);
    int kernel_size = weight.size(2);

    // Output tensor
    at::Tensor output = at::zeros({batch_size, out_channels, height, width, depth}, input.options());

    // Launch CUDA kernel
    dim3 threads(256);
    dim3 blocks(batch_size, out_channels, in_channels / groups);
    conv3d_forward_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), 
        weight.data_ptr<float>(), 
        output.data_ptr<float>(), 
        batch_size, 
        in_channels, 
        out_channels, 
        kernel_size, 
        height, 
        width, 
        depth, 
        stride, 
        padding, 
        dilation, 
        groups
    );

    return output;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_conv3d_forward", &custom_conv3d_forward, "Custom 3D Convolution");
}
"""

# Test the custom implementation
def test_custom_conv3d():
    batch_size = 16
    in_channels = 3
    out_channels = 64
    kernel_size = 3
    width = 256
    height = 256
    depth = 10

    model_ref = Model(in_channels, out_channels, kernel_size)
    model_new = ModelNew(in_channels, out_channels, kernel_size)

    input_tensor = torch.rand(batch_size, in_channels, height, width, depth)

    output_ref = model_ref(input_tensor)
    output_new = model_new(input_tensor)

    assert torch.allclose(output_ref, output_new, atol=1e-5), "Output mismatch between reference and custom implementations"

    print("Test passed! Outputs match within tolerance.")

# Run the test
test_custom_conv3d()