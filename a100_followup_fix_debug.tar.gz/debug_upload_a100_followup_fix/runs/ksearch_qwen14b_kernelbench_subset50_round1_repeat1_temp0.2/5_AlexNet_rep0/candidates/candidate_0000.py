import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.cpp_extension import load

# Load custom CUDA kernel
custom_cuda = load(name="custom_cuda", sources=["custom_cuda_kernel.cu"])

class ModelNew(nn.Module):
    def __init__(self, num_classes=1000):
        super(ModelNew, self).__init__()
        
        # First convolutional layer
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=96, kernel_size=11, stride=4, padding=2)
        self.relu1 = nn.ReLU(inplace=True)
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2)
        
        # Second convolutional layer
        self.conv2 = nn.Conv2d(in_channels=96, out_channels=256, kernel_size=5, padding=2)
        self.relu2 = nn.ReLU(inplace=True)
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2)
        
        # Third convolutional layer
        self.conv3 = nn.Conv2d(in_channels=256, out_channels=384, kernel_size=3, padding=1)
        self.relu3 = nn.ReLU(inplace=True)
        
        # Fourth convolutional layer
        self.conv4 = nn.Conv2d(in_channels=384, out_channels=384, kernel_size=3, padding=1)
        self.relu4 = nn.ReLU(inplace=True)
        
        # Fifth convolutional layer
        self.conv5 = nn.Conv2d(in_channels=384, out_channels=256, kernel_size=3, padding=1)
        self.relu5 = nn.ReLU(inplace=True)
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2)
        
        # Fully connected layers
        self.fc1 = nn.Linear(in_features=256 * 6 * 6, out_features=4096)
        self.relu6 = nn.ReLU(inplace=True)
        self.dropout1 = nn.Dropout(p=0.0)
        
        self.fc2 = nn.Linear(in_features=4096, out_features=4096)
        self.relu7 = nn.ReLU(inplace=True)
        self.dropout2 = nn.Dropout(p=0.0)
        
        self.fc3 = nn.Linear(in_features=4096, out_features=num_classes)

    def forward(self, x):
        # Custom CUDA kernel for conv1
        x = custom_cuda.convolution_forward(x, self.conv1.weight, self.conv1.bias, self.conv1.stride, self.conv1.padding)
        x = self.relu1(x)
        x = self.maxpool1(x)
        
        # Custom CUDA kernel for conv2
        x = custom_cuda.convolution_forward(x, self.conv2.weight, self.conv2.bias, self.conv2.stride, self.conv2.padding)
        x = self.relu2(x)
        x = self.maxpool2(x)
        
        # Custom CUDA kernel for conv3
        x = custom_cuda.convolution_forward(x, self.conv3.weight, self.conv3.bias, self.conv3.stride, self.conv3.padding)
        x = self.relu3(x)
        
        # Custom CUDA kernel for conv4
        x = custom_cuda.convolution_forward(x, self.conv4.weight, self.conv4.bias, self.conv4.stride, self.conv4.padding)
        x = self.relu4(x)
        
        # Custom CUDA kernel for conv5
        x = custom_cuda.convolution_forward(x, self.conv5.weight, self.conv5.bias, self.conv5.stride, self.conv5.padding)
        x = self.relu5(x)
        x = self.maxpool3(x)
        
        x = torch.flatten(x, 1)
        
        x = self.fc1(x)
        x = self.relu6(x)
        x = self.dropout1(x)
        
        x = self.fc2(x)
        x = self.relu7(x)
        x = self.dropout2(x)
        
        x = self.fc3(x)
        
        return x

# Test code
batch_size = 1024
num_classes = 1000

def get_inputs():
    return [torch.rand(batch_size, 3, 224, 224)]

def get_init_inputs():
    return [num_classes]