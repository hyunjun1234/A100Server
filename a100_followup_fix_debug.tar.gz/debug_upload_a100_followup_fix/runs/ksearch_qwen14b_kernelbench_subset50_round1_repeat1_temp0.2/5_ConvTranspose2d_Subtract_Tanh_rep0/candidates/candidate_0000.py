import torch
import torch.nn as nn
from torch.utils.cpp_extension import load

# Load custom CUDA kernel
conv_transpose_cuda = load(name="conv_transpose_cuda", sources=["conv_transpose_cuda.cu"])

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape, stride=2, padding=1, output_padding=1):
        super(ModelNew, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.output_padding = output_padding
        self.bias = nn.Parameter(torch.randn(bias_shape))
        self.weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size, kernel_size))

    def forward(self, x):
        # Custom CUDA kernel for ConvTranspose2d
        output = conv_transpose_cuda.conv_transpose2d(
            x, self.weight, self.bias, self.stride, self.padding, self.output_padding
        )
        return output

# CUDA kernel implementation (conv_transpose_cuda.cu)
# This file should contain the CUDA kernel code for conv_transpose2d

# Example CUDA kernel code (conv_transpose_cuda.cu)
"""
#include <torch/extension.h>

__global__ void conv_transpose2d_forward_kernel(
    const float* input, const float* weight, float* output,
    int batch_size, int in_channels, int out_channels, int height, int width,
    int kernel_size, int stride, int padding, int output_padding,
    const float* bias) {
    // Implement the forward pass of ConvTranspose2d using CUDA
}

at::Tensor conv_transpose2d_forward(
    const at::Tensor& input, const at::Tensor& weight, const at::Tensor& bias,
    int stride, int padding, int output_padding) {
    // Implement the wrapper function to call the CUDA kernel
}
"""

# Test the implementation
batch_size = 32
in_channels = 64  
out_channels = 64  
height = width = 256 
kernel_size = 4
bias_shape = (out_channels, 1, 1)

def get_inputs():
    return [torch.rand(batch_size, in_channels, height, width)]

def get_init_inputs():
    return [in_channels, out_channels, kernel_size, bias_shape]

# Compare with reference implementation
model_ref = Model(*get_init_inputs())
model_opt = ModelNew(*get_init_inputs())

input_data = get_inputs()[0]

output_ref = model_ref(input_data)
output_opt = model_opt(input_data)

# Check correctness
assert torch.allclose(output_ref, output_opt, atol=1e-5), "Output mismatch between reference and optimized models"

# Measure performance
import time

start_time = time.time()
for _ in range(100):
    output_ref = model_ref(input_data)
end_time = time.time()
ref_time = end_time - start_time

start_time = time.time()
for _ in range(100):
    output_opt = model_opt(input_data)
end_time = time.time()
opt_time = end_time - start_time

print(f"Reference time: {ref_time:.4f} seconds")
print(f"Optimized time: {opt_time:.4f} seconds")
print(f"Speedup: {ref_time / opt_time:.2f}x")