import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

# Define the CUDA kernel
cuda_kernel_code = """
extern "C" __global__ void matrix_scalar_multiply_kernel(float* A, float* C, float s, int M, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    int idy = blockIdx.y * blockDim.y + threadIdx.y;

    if (idx < N && idy < M) {
        int index = idy * N + idx;
        C[index] = A[index] * s;
    }
}
"""

# Load the CUDA kernel
matrix_scalar_multiply_cuda = load_inline(name="matrix_scalar_multiply",
                                          sources=[cuda_kernel_code],
                                          verbose=True,
                                          extra_cuda_cflags=['--expt-relaxed-constexpr'])

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, A: torch.Tensor, s: float) -> torch.Tensor:
        """
        Performs matrix-scalar multiplication using a custom CUDA kernel.

        Args:
            A: Input matrix of shape (M, N)
            s: Scalar value

        Returns:
            C: Resulting matrix of shape (M, N)
        """
        M, N = A.shape
        C = torch.empty_like(A)

        # Define block and grid dimensions
        threads_per_block = (16, 16)
        blocks_per_grid_x = (N + threads_per_block[0] - 1) // threads_per_block[0]
        blocks_per_grid_y = (M + threads_per_block[1] - 1) // threads_per_block[1]
        blocks_per_grid = (blocks_per_grid_x, blocks_per_grid_y)

        # Launch the CUDA kernel
        matrix_scalar_multiply_cuda.matrix_scalar_multiply_kernel[A.type(), C.type(), torch.float32, int, int](
            A.data_ptr(), C.data_ptr(), s, M, N, blocks_per_grid, threads_per_block
        )

        return C

# Test the implementation
M = 16384 * 4
N = 4096 * 4

def get_inputs():
    A = torch.rand(M, N).cuda()
    s = 3.14
    return [A, s]

def get_init_inputs():
    return []  # No special initialization inputs needed

# Create the model and run the forward pass
model = ModelNew().cuda()
A, s = get_inputs()
C = model(A, s)

# Verify the result
reference_model = Model().cuda()
reference_C = reference_model(A, s)
assert torch.allclose(C, reference_C, atol=1e-7), "The custom CUDA kernel does not produce the correct result."

print("Custom CUDA kernel implementation is correct.")