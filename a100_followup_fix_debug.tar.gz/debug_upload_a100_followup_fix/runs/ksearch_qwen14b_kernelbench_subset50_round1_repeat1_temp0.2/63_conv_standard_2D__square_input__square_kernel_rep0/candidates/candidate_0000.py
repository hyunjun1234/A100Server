import torch
from torch.utils.cpp_extension import load_inline
import torch.nn as nn

# Inline CUDA code for the custom convolution kernel
cuda_code = """
extern "C" __global__
void custom_conv2d(const float* input, const float* weight, float* output,
                   int batch_size, int in_channels, int out_channels, int height, int width,
                   int kernel_size, int stride, int padding, int dilation, int groups) {
    // Thread indices
    int bx = blockIdx.x;
    int by = blockIdx.y;
    int bz = blockIdx.z;
    int tx = threadIdx.x;
    int ty = threadIdx.y;
    int tz = threadIdx.z;

    // Calculate global indices
    int n = bz; // batch index
    int c_out = by; // output channel index
    int h_out = bx; // output height index
    int w_out = tx; // output width index

    // Calculate input indices
    int h_in = h_out * stride - padding;
    int w_in = w_out * stride - padding;

    // Initialize output value
    float output_value = 0.0f;

    // Perform convolution
    for (int c_in = 0; c_in < in_channels; ++c_in) {
        for (int kh = 0; kh < kernel_size; ++kh) {
            int h_k = h_in + kh * dilation;
            if (h_k >= 0 && h_k < height) {
                for (int kw = 0; kw < kernel_size; ++kw) {
                    int w_k = w_in + kw * dilation;
                    if (w_k >= 0 && w_k < width) {
                        int input_idx = (n * in_channels + c_in) * height * width + h_k * width + w_k;
                        int weight_idx = (c_out * in_channels + c_in) * kernel_size * kernel_size + kh * kernel_size + kw;
                        output_value += input[input_idx] * weight[weight_idx];
                    }
                }
            }
        }
    }

    // Store the result in the output tensor
    int output_idx = (n * out_channels + c_out) * height * width / stride / stride + h_out * width / stride + w_out;
    output[output_idx] = output_value;
}
"""

# Load the CUDA extension
custom_conv2d = load_inline("custom_conv2d", cuda_code, ["-lcudart"], verbose=True)

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size, kernel_size))
        if bias:
            self.bias = nn.Parameter(torch.randn(out_channels))
        else:
            self.register_parameter('bias', None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, in_channels, height, width = x.size()
        height_out = (height + 2 * self.padding - self.dilation * (self.kernel_size - 1) - 1) // self.stride + 1
        width_out = (width + 2 * self.padding - self.dilation * (self.kernel_size - 1) - 1) // self.stride + 1
        output = torch.zeros((batch_size, self.out_channels, height_out, width_out), device=x.device)

        # Flatten weight tensor for easier indexing
        weight_flat = self.weight.view(self.out_channels, in_channels * self.kernel_size * self.kernel_size)

        # Launch the custom CUDA kernel
        custom_conv2d.custom_conv2d(
            x.contiguous().data_ptr(),
            weight_flat.contiguous().data_ptr(),
            output.data_ptr(),
            batch_size, in_channels, self.out_channels, height, width,
            self.kernel_size, self.stride, self.padding, self.dilation, self.groups,
            grid=(height_out, self.out_channels, batch_size),
            block=(width_out, 1, 1),
            stream=torch.cuda.current_stream().cuda_stream
        )

        if self.bias is not None:
            output += self.bias.view(1, self.out_channels, 1, 1)

        return output

# Test code
batch_size = 16
in_channels = 16
out_channels = 128
kernel_size = 3
width = 1024
height = 1024

def get_inputs():
    x = torch.rand(batch_size, in_channels, height, width, device='cuda')
    return [x]

def get_init_inputs():
    return [in_channels, out_channels, kernel_size]  # Provide in_channels, out_channels, kernel_size for initialization

# Example usage
model_ref = Model(in_channels, out_channels, kernel_size).cuda()
model_new = ModelNew(in_channels, out_channels, kernel_size).cuda()

x = get_inputs()[0]
y_ref = model_ref(x)
y_new = model_new(x)

print("Reference Output Shape:", y_ref.shape)
print("Custom Output Shape:", y_new.shape)

# Check correctness
assert torch.allclose(y_ref, y_new, atol=1e-5), "Output mismatch"
print("Correctness check passed.")

# Measure performance
import time

# Warm-up
for _ in range(10):
    y_ref = model_ref(x)
    y_new = model_new(x)

# Measure reference time
start_time = time.time()
for _ in range(100):
    y_ref = model_ref(x)
torch.cuda.synchronize()
reference_time = time.time() - start_time

# Measure custom time
start_time = time.time()
for _ in range(100):
    y_new = model_new(x)
torch.cuda.synchronize()
custom_time = time.time() - start_time

print(f"Reference Time: {reference_time:.4f} seconds")
print(f"Custom Time: {custom_time:.4f} seconds")
print(f"Speedup: {reference_time / custom_time:.2fx}")