import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

# CUDA kernel code
cuda_code = """
__global__ void conv_transpose2d_cuda(
    const float* input, 
    const float* weight, 
    float* output,
    int batch_size, 
    int in_channels, 
    int out_channels, 
    int height_in, 
    int width_in, 
    int kernel_h, 
    int kernel_w, 
    int stride_h, 
    int stride_w, 
    int padding_h, 
    int padding_w, 
    int output_padding_h, 
    int output_padding_w, 
    int groups) {
    int out_n = blockIdx.x;
    int out_c = blockIdx.y / groups;
    int group_id = blockIdx.y % groups;
    int out_h = blockIdx.z / (out_channels / groups);
    int out_w = blockIdx.z % (out_channels / groups);

    if (out_n >= batch_size || out_c >= out_channels || out_h >= (height_in - 1) * stride_h + kernel_h - padding_h - output_padding_h || out_w >= (width_in - 1) * stride_w + kernel_w - padding_w - output_padding_w) {
        return;
    }

    int input_h_start = (out_h - output_padding_h) / stride_h - padding_h;
    int input_w_start = (out_w - output_padding_w) / stride_w - padding_w;
    int weight_offset = (out_c * in_channels / groups) * kernel_h * kernel_w + group_id * in_channels / groups * kernel_h * kernel_w;

    float sum = 0.0;
    for (int kh = 0; kh < kernel_h; ++kh) {
        int ih = input_h_start + kh;
        if (ih < 0 || ih >= height_in) continue;
        for (int kw = 0; kw < kernel_w; ++kw) {
            int iw = input_w_start + kw;
            if (iw < 0 || iw >= width_in) continue;
            int input_index = out_n * in_channels * height_in * width_in + group_id * in_channels / groups * height_in * width_in + ih * width_in * in_channels / groups + iw * in_channels / groups;
            int weight_index = weight_offset + kh * kernel_w * in_channels / groups + kw * in_channels / groups;
            sum += input[input_index] * weight[weight_index];
        }
    }

    int output_index = out_n * out_channels * ((height_in - 1) * stride_h + kernel_h - padding_h - output_padding_h) * ((width_in - 1) * stride_w + kernel_w - padding_w - output_padding_w) + out_c * ((height_in - 1) * stride_h + kernel_h - padding_h - output_padding_w) + out_h * ((width_in - 1) * stride_w + kernel_w - padding_w - output_padding_w) + out_w;
    output[output_index] = sum;
}
"""

# Load the CUDA kernel as a PyTorch extension
conv_transpose2d_cuda_module = load_inline(name='conv_transpose2d_cuda_module',
                                           cpp_sources='',
                                           cuda_sources=cuda_code,
                                           extra_cuda_cflags=['-arch=sm_80', '-lineinfo'])

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: int = 1, padding: int = 0, output_padding: int = 0, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.output_padding = output_padding
        self.groups = groups
        self.weight = nn.Parameter(torch.randn(out_channels, in_channels // groups, *kernel_size))
        if bias:
            self.bias = nn.Parameter(torch.randn(out_channels))
        else:
            self.register_parameter('bias', None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, in_channels, height_in, width_in = x.size()
        kernel_h, kernel_w = self.kernel_size
        height_out = (height_in - 1) * self.stride + kernel_h - self.padding - self.output_padding
        width_out = (width_in - 1) * self.stride + kernel_w - self.padding - self.output_padding

        output = torch.zeros(batch_size, self.out_channels, height_out, width_out, device=x.device)

        conv_transpose2d_cuda_module.conv_transpose2d_cuda[x.device.type](
            x.contiguous(),
            self.weight.contiguous(),
            output,
            batch_size,
            self.in_channels,
            self.out_channels,
            height_in,
            width_in,
            kernel_h,
            kernel_w,
            self.stride,
            self.stride,
            self.padding,
            self.padding,
            self.output_padding,
            self.output_padding,
            self.groups
        )

        if self.bias is not None:
            output += self.bias.view(1, -1, 1, 1)

        return output

# Test code
batch_size = 8
in_channels = 64
out_channels = 64
kernel_size = (3, 7)  # larger asymmetric kernel
width = 512
height = 512

def get_inputs():
    x = torch.rand(batch_size, in_channels, height, width)
    return [x]

def get_init_inputs():
    return [in_channels, out_channels, kernel_size]  # Provide in_channels, out_channels, kernel_size for initialization