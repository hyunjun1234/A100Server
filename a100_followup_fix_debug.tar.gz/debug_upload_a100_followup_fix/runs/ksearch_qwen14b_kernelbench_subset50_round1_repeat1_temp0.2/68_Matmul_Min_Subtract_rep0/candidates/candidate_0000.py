import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline
import os

# Define the CUDA kernel code
cuda_code = """
__global__ void matmul_min_subtract_kernel(float* input, float* output, float* weight, float bias, int batch_size, int in_features, int out_features, float constant) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    int idy = blockIdx.y * blockDim.y + threadIdx.y;

    if (idx < batch_size && idy < out_features) {
        float sum = 0.0f;
        for (int k = 0; k < in_features; ++k) {
            sum += input[idx * in_features + k] * weight[idy * in_features + k];
        }
        sum += bias;
        float min_val = fminf(sum, constant);
        output[idx * out_features + idy] = min_val - constant;
    }
}
"""

# Load the CUDA kernel
cuda_module = load_inline(
    name="cuda_module",
    sources=[cuda_code],
    verbose=True,
    extra_cuda_cflags=["-arch=sm_80", "-O3"]
)

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, constant):
        super(ModelNew, self).__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.constant = nn.Parameter(torch.tensor(constant))

    def forward(self, x):
        # Get the weight and bias from the linear layer
        weight = self.linear.weight.data
        bias = self.linear.bias.data
        constant = self.constant.data.item()

        # Allocate memory for the output
        output = torch.empty_like(x)

        # Define block and grid dimensions
        threads_per_block = (16, 16)
        blocks_per_grid_x = (x.size(0) + threads_per_block[0] - 1) // threads_per_block[0]
        blocks_per_grid_y = (x.size(1) + threads_per_block[1] - 1) // threads_per_block[1]
        blocks_per_grid = (blocks_per_grid_x, blocks_per_grid_y)

        # Launch the CUDA kernel
        cuda_module.matmul_min_subtract_kernel[x.size(0), x.size(1), threads_per_block](
            x.data_ptr(),
            output.data_ptr(),
            weight.data_ptr(),
            bias.item(),
            x.size(0),
            x.size(1),
            output.size(1),
            constant
        )

        return output

# Example usage
batch_size = 128
in_features = 16384
out_features = 16384
constant = 2.0

model = ModelNew(in_features, out_features, constant)
input_data = torch.rand(batch_size, in_features)

output = model(input_data)
print(output)