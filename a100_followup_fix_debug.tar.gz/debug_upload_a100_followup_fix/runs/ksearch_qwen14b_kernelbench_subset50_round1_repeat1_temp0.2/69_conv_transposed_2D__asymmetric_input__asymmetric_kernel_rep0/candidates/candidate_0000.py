import torch
import torch.nn as nn
from torch.utils.cpp_extension import load

# Load the custom CUDA kernel
conv_transpose2d_cuda = load(name='conv_transpose2d_cuda', sources=['conv_transpose2d_cuda.cpp'])

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1), padding: tuple = (0, 0), output_padding: tuple = (0, 0), dilation: tuple = (1, 1), groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv_transpose2d = nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, dilation=dilation, groups=groups, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return conv_transpose2d_cuda.conv_transpose2d(x, self.conv_transpose2d.weight, self.conv_transpose2d.bias, self.conv_transpose2d.stride, self.conv_transpose2d.padding, self.conv_transpose2d.output_padding, self.conv_transpose2d.dilation, self.conv_transpose2d.groups)

# Test code
batch_size = 64
in_channels = 64
out_channels = 128
kernel_size = (3, 5)
height_in = 128
width_in = 256

def get_inputs():
    x = torch.rand(batch_size, in_channels, height_in, width_in)
    return [x]

def get_init_inputs():
    return [in_channels, out_channels, kernel_size]  # Provide in_channels, out_channels, kernel_size for initialization