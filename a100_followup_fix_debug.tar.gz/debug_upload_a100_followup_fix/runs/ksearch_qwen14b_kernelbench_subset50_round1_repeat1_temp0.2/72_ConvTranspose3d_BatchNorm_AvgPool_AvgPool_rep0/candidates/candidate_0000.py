import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

# CUDA kernel implementations
cuda_code = """
extern "C" __global__ void conv_transpose_3d_kernel(
    float* input, float* weight, float* output,
    int batch_size, int in_channels, int out_channels,
    int depth, int height, int width, int kernel_size, int stride, int padding) {
    // TODO: Implement the 3D transposed convolution kernel
}

extern "C" __global__ void batch_norm_3d_kernel(
    float* input, float* running_mean, float* running_var, float* output,
    float* gamma, float* beta, float eps, int batch_size, int channels,
    int depth, int height, int width) {
    // TODO: Implement the batch normalization kernel
}

extern "C" __global__ void avg_pool_3d_kernel(
    float* input, float* output, int batch_size, int channels,
    int depth, int height, int width, int pool_size) {
    // TODO: Implement the average pooling kernel
}
"""

# Load the CUDA kernels
conv_transpose_3d = load_inline(name="conv_transpose_3d", sources=[cuda_code], verbose=True)
batch_norm_3d = load_inline(name="batch_norm_3d", sources=[cuda_code], verbose=True)
avg_pool_3d = load_inline(name="avg_pool_3d", sources=[cuda_code], verbose=True)

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, bias_shape):
        super(ModelNew, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.bias_shape = bias_shape

        # Initialize weights and biases
        self.weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size, kernel_size, kernel_size))
        self.bias = nn.Parameter(torch.randn(*bias_shape))
        self.running_mean = nn.Parameter(torch.zeros(out_channels), requires_grad=False)
        self.running_var = nn.Parameter(torch.ones(out_channels), requires_grad=False)
        self.gamma = nn.Parameter(torch.ones(out_channels))
        self.beta = nn.Parameter(torch.zeros(out_channels))

    def forward(self, x):
        # 3D Transposed Convolution
        output_shape = (
            x.size(0), self.out_channels,
            (x.size(2) - 1) * self.stride + self.kernel_size - 2 * self.padding,
            (x.size(3) - 1) * self.stride + self.kernel_size - 2 * self.padding,
            (x.size(4) - 1) * self.stride + self.kernel_size - 2 * self.padding
        )
        output = torch.zeros(output_shape, device=x.device)
        grid = (output_shape[0] * output_shape[1] * output_shape[2], 1)
        block = (1, 1, 1)
        conv_transpose_3d.conv_transpose_3d_kernel[x.device](
            x.contiguous(), self.weight.contiguous(), output.contiguous(),
            x.size(0), self.in_channels, self.out_channels,
            x.size(2), x.size(3), x.size(4), self.kernel_size, self.stride, self.padding,
            grid=grid, block=block
        )

        # Batch Normalization
        output = output.view(output_shape[0], self.out_channels, -1)
        output = (output - self.running_mean.view(1, -1, 1)) / torch.sqrt(self.running_var.view(1, -1, 1) + 1e-5)
        output = output * self.gamma.view(1, -1, 1) + self.beta.view(1, -1, 1)
        output = output.view(output_shape)

        # First Average Pooling
        output = output.permute(0, 1, 4, 2, 3).contiguous()
        output_shape = (output_shape[0], output_shape[1], output_shape[4] // 2, output_shape[2] // 2, output_shape[3])
        output = torch.zeros(output_shape, device=x.device)
        grid = (output_shape[0] * output_shape[1] * output_shape[2], 1)
        block = (1, 1, 1)
        avg_pool_3d.avg_pool_3d_kernel[x.device](
            x.contiguous(), output.contiguous(),
            output_shape[0], output_shape[1],
            output_shape[2], output_shape[3], output_shape[4], 2,
            grid=grid, block=block
        )

        # Second Average Pooling
        output = output.permute(0, 1, 3, 2, 4).contiguous()
        output_shape = (output_shape[0], output_shape[1], output_shape[3] // 2, output_shape[2], output_shape[4])
        output = torch.zeros(output_shape, device=x.device)
        grid = (output_shape[0] * output_shape[1] * output_shape[2], 1)
        block = (1, 1, 1)
        avg_pool_3d.avg_pool_3d_kernel[x.device](
            x.contiguous(), output.contiguous(),
            output_shape[0], output_shape[1],
            output_shape[2], output_shape[3], output_shape[4], 2,
            grid=grid, block=block
        )

        return output

# Example usage
batch_size = 64
in_channels = 3
out_channels = 16
depth, height, width = 32, 32, 32
kernel_size = 3
stride = 2
padding = 1
bias_shape = (out_channels, 1, 1, 1)

model_new = ModelNew(in_channels, out_channels, kernel_size, stride, padding, bias_shape)
inputs = torch.rand(batch_size, in_channels, depth, height, width)
output = model_new(inputs)
print(output.shape)