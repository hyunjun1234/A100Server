import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

# Load the custom CUDA kernel
custom_cuda_kernel = load_inline(
    name='custom_cuda_kernel',
    sources=[
        '''
        #include <ATen/ATen.h>
        #include <ATen/cuda/CUDAContext.h>
        #include <ATen/cuda/DeviceUtils.h>

        extern "C" __global__ void transposed_conv1d_kernel(
            const float* input, const float* weight, float* output,
            int batch_size, int in_channels, int out_channels, int length,
            int kernel_size, int stride, int padding, int dilation
        ) {
            int b = blockIdx.x;
            int c = blockIdx.y;
            int i = threadIdx.x;

            if (b >= batch_size || c >= out_channels || i >= length) return;

            // Calculate the start index for the input
            int input_start = i * stride - padding;

            // Initialize the output value
            float sum = 0.0f;

            for (int k = 0; k < kernel_size; ++k) {
                int input_idx = input_start + k * dilation;
                if (input_idx >= 0 && input_idx < length) {
                    int weight_idx = c * in_channels * kernel_size + k * in_channels;
                    for (int ic = 0; ic < in_channels; ++ic) {
                        sum += input[b * in_channels * length + ic * length + input_idx] * weight[weight_idx + ic];
                    }
                }
            }

            output[b * out_channels * length + c * length + i] = sum;
        }
        '''],
    extra_cflags=['-O3', '-arch=sm_80', '-std=c++14'],
    extra_cuda_cflags=['-O3', '-arch=sm_80', '-std=c++14']
)

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size))
        if bias:
            self.bias = nn.Parameter(torch.randn(out_channels))
        else:
            self.register_parameter('bias', None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, _, length = x.size()
        output_length = (length - 1) * self.stride + self.kernel_size - 2 * self.padding
        output = torch.zeros(batch_size, self.out_channels, output_length, device=x.device)

        # Launch the custom CUDA kernel
        grid = (batch_size, self.out_channels, (output_length + 255) // 256)
        block = (256,)
        custom_cuda_kernel.transposed_conv1d_kernel<<<grid, block>>>(
            x.contiguous().data_ptr(), self.weight.contiguous().data_ptr(), output.data_ptr(),
            batch_size, self.in_channels, self.out_channels, length,
            self.kernel_size, self.stride, self.padding, self.dilation
        )

        if self.bias is not None:
            output = output + self.bias.view(1, -1, 1).expand_as(output)

        return output

# Test code
batch_size = 32
in_channels = 32
out_channels = 64
kernel_size = 5
length = 131072
stride = 1
padding = 0
dilation = 3

def get_inputs():
    x = torch.rand(batch_size, in_channels, length)
    return [x]

def get_init_inputs():
    return [in_channels, out_channels, kernel_size, stride, padding, dilation]

# Create models
model_ref = Model(in_channels, out_channels, kernel_size, stride, padding, dilation)
model_new = ModelNew(in_channels, out_channels, kernel_size, stride, padding, dilation)

# Get inputs
inputs = get_inputs()

# Run reference model
output_ref = model_ref(*inputs)

# Run new model
output_new = model_new(*inputs)

# Check correctness
assert torch.allclose(output_ref, output_new, atol=1e-5), "Output mismatch between reference and optimized implementations."

# Measure performance
import time

start_time = time.time()
for _ in range(10):
    output_ref = model_ref(*inputs)
end_time = time.time()
print(f"Reference model time: {end_time - start_time} seconds")

start_time = time.time()
for _ in range(10):
    output_new = model_new(*inputs)
end_time = time.time()
print(f"Optimized model time: {end_time - start_time} seconds")