import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

# Inline CUDA code for the custom convolution kernel
cuda_conv_code = """
#include <torch/extension.h>

__global__ void custom_conv1d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int dilation
) {
    int b = blockIdx.x / (out_channels * ((length + dilation * (kernel_size - 1)) / stride));
    int c = (blockIdx.x % (out_channels * ((length + dilation * (kernel_size - 1)) / stride))) / ((length + dilation * (kernel_size - 1)) / stride);
    int t = blockIdx.x % ((length + dilation * (kernel_size - 1)) / stride);

    int input_start = b * in_channels * length + c * length;
    int output_start = b * out_channels * ((length + dilation * (kernel_size - 1)) / stride) + c * ((length + dilation * (kernel_size - 1)) / stride) + t;

    float sum = 0.0f;
    for (int k = 0; k < kernel_size; ++k) {
        int input_pos = input_start + t * stride + k * dilation;
        if (input_pos >= 0 && input_pos < length) {
            sum += input[input_pos] * weight[c * kernel_size + k];
        }
    }

    if (bias) {
        sum += bias[c];
    }

    output[output_start] = sum;
}

at::Tensor custom_conv1d_forward(
    const at::Tensor& input, const at::Tensor& weight, const at::Tensor& bias,
    int kernel_size, int stride, int dilation
) {
    auto output = at::zeros({
        input.size(0), weight.size(0),
        (input.size(2) + dilation * (kernel_size - 1)) / stride
    }, input.options());

    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int out_channels = weight.size(0);
    int length = input.size(2);

    custom_conv1d_kernel<<<batch_size * out_channels * ((length + dilation * (kernel_size - 1)) / stride), 1>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels, length,
        kernel_size, stride, dilation
    );

    return output;
}
"""

# Load the custom CUDA kernel
custom_conv1d = load_inline(
    name="custom_conv1d",
    sources=[cuda_conv_code],
    extra_cuda_cflags=["--expt-relaxed-constexpr"],
    extra_cflags=["-O3"]
)

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, dilation: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size))
        if bias:
            self.bias = nn.Parameter(torch.randn(out_channels))
        else:
            self.register_parameter('bias', None)
        self.kernel_size = kernel_size
        self.stride = stride
        self.dilation = dilation

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.bias is not None:
            return custom_conv1d.custom_conv1d_forward(x, self.weight, self.bias, self.kernel_size, self.stride, self.dilation)
        else:
            return custom_conv1d.custom_conv1d_forward(x, self.weight, torch.zeros(1), self.kernel_size, self.stride, self.dilation)

# Test the implementation
batch_size = 64
in_channels = 64
out_channels = 128
kernel_size = 3
length = 524280
stride = 3
dilation = 4

model_ref = Model(in_channels, out_channels, kernel_size, stride, dilation)
model_opt = ModelNew(in_channels, out_channels, kernel_size, stride, dilation)

x = torch.rand(batch_size, in_channels, length).cuda()
y_ref = model_ref(x)
y_opt = model_opt(x)

# Check correctness
assert torch.allclose(y_ref, y_opt, atol=1e-5), "The outputs do not match!"

# Measure performance
import time

start_time = time.time()
for _ in range(10):
    y_ref = model_ref(x)
end_time = time.time()
print(f"Reference time: {end_time - start_time} seconds")

start_time = time.time()
for _ in range(10):
    y_opt = model_opt(x)
end_time = time.time()
print(f"Optimized time: {end_time - start_time} seconds")