import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from torch.utils.cpp_extension import load

# Load custom CUDA kernel
cuda_gelu = load(name="cuda_gelu", sources=["cuda_gelu_kernel.cu"])

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, x):
        # Use the custom CUDA kernel for GELU
        return cuda_gelu.gelu_forward(x)

# CUDA kernel implementation (cuda_gelu_kernel.cu)
"""
#include <torch/extension.h>

__device__ float gelu_device(float x) {
    const float kAlpha = 0.044715;
    const float kBeta = sqrt(2.0f / M_PI);
    return 0.5f * x * (1.0f + tanhf(kBeta * (x + kAlpha * x * x * x)));
}

__global__ void gelu_forward_kernel(const float* input, float* output, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        output[idx] = gelu_device(input[idx]);
    }
}

at::Tensor gelu_forward(const at::Tensor& input) {
    auto output = at::zeros_like(input);
    int size = input.numel();
    int threads_per_block = 256;
    int blocks_per_grid = (size + threads_per_block - 1) / threads_per_block;

    gelu_forward_kernel<<<blocks_per_grid, threads_per_block>>>(input.data_ptr<float>(), output.data_ptr<float>(), size);
    return output;
}
"""

batch_size = 8192
dim = 8192

def get_inputs():
    return [torch.rand(batch_size, dim, device='cuda')]

def get_init_inputs():
    return []

# Example usage
model_ref = Model().cuda()
model_opt = ModelNew().cuda()

inputs = get_inputs()
input_tensor = inputs[0]

output_ref = model_ref(input_tensor)
output_opt = model_opt(input_tensor)

print("Reference Output:", output_ref)
print("Optimized Output:", output_opt)

# Check correctness
assert torch.allclose(output_ref, output_opt, atol=1e-6), "Output mismatch between reference and optimized implementations"

# Measure performance
import time

# Warm-up
for _ in range(10):
    _ = model_ref(input_tensor)
    _ = model_opt(input_tensor)

# Measure reference performance
start_time = time.time()
for _ in range(100):
    _ = model_ref(input_tensor)
reference_time = time.time() - start_time

# Measure optimized performance
start_time = time.time()
for _ in range(100):
    _ = model_opt(input_tensor)
optimized_time = time.time() - start_time

print(f"Reference Time: {reference_time} seconds")
print(f"Optimized Time: {optimized_time} seconds")
print(f"Speedup: {reference_time / optimized_time}x")