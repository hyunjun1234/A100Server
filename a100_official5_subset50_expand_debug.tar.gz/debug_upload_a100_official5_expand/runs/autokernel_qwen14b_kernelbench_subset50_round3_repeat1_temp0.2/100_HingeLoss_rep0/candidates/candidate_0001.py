import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void hinge_loss_kernel(const float* predictions, const float* targets, float* output, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        float diff = 1 - predictions[idx] * targets[idx];
        output[idx] = diff > 0 ? diff : 0;
    }
}

torch::Tensor hinge_loss_cuda(torch::Tensor predictions, torch::Tensor targets) {
    auto output = torch::empty_like(predictions);
    int N = predictions.numel();
    hinge_loss_kernel<<<(N+255)/256, 256>>>(
        predictions.data_ptr<float>(), targets.data_ptr<float>(), output.data_ptr<float>(), N);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "hinge_loss_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, predictions, targets):
        return torch.mean(_get_mod().hinge_loss_cuda(predictions, targets))
