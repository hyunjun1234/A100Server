import torch
import torch.nn as nn
import torch.nn.functional as F
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void bn_relu_conv_avg_pool_forward(
    const float* input, float* output,
    const float* weight, const float* bias,
    const float* running_mean, const float* running_var,
    float eps, int N, int C, int H, int W) {
    int n = blockIdx.x;
    int c = blockIdx.y;
    int h = blockIdx.z * blockDim.z + threadIdx.z;
    int w = threadIdx.x;

    if (n < N && c < C && h < H && w < W) {
        int in_idx = n * C * H * W + c * H * W + h * W + w;
        int out_idx = n * C * H * W / 4 + c * H * W / 4 + h / 2 * W / 2 + w / 2;

        float x = input[in_idx];
        float norm = (x - running_mean[c]) / sqrtf(running_var[c] + eps);
        float relu = fmaxf(0.0f, norm);
        float conv = relu * weight[c];
        atomicAdd(&output[out_idx], conv);
    }
}

torch::Tensor bn_relu_conv_avg_pool_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    torch::Tensor running_mean, torch::Tensor running_var, float eps) {
    auto output = torch::zeros({input.size(0), weight.size(0), input.size(2) / 2, input.size(3) / 2}, input.options());
    int N = input.size(0);
    int C = input.size(1);
    int H = input.size(2);
    int W = input.size(3);

    dim3 threads(16, 16, 4);
    dim3 blocks(N, C, (H + threads.z - 1) / threads.z);

    bn_relu_conv_avg_pool_forward<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        running_mean.data_ptr<float>(), running_var.data_ptr<float>(),
        eps, N, C, H, W);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "bn_relu_conv_avg_pool_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, num_input_features: int, num_output_features: int):
        super(ModelNew, self).__init__()
        self.transition = nn.Sequential(
            nn.BatchNorm2d(num_input_features),
            nn.ReLU(inplace=True),
            nn.Conv2d(num_input_features, num_output_features, kernel_size=1, bias=False),
            nn.AvgPool2d(kernel_size=2, stride=2)
        )

    def forward(self, x):
        if x.is_cuda:
            return _get_mod().bn_relu_conv_avg_pool_cuda(
                x, self.transition[2].weight, self.transition[2].bias,
                self.transition[0].running_mean, self.transition[0].running_var, self.transition[0].eps)
        else:
            return self.transition(x)
