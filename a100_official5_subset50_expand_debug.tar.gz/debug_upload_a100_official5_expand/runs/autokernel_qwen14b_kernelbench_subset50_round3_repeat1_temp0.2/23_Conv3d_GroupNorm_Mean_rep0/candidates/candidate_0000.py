import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void conv3d_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int D, int H, int W, int kernel_size) {
    int b = blockIdx.x / (out_channels * D * H);
    int c_out = (blockIdx.x % (out_channels * D * H)) / (D * H);
    int d = (blockIdx.x % (D * H)) / H;
    int h = (blockIdx.x % H);
    int w = threadIdx.x;

    if (b < batch_size && c_out < out_channels && d < D && h < H && w < W) {
        float sum = 0.0f;
        for (int c_in = 0; c_in < in_channels; ++c_in) {
            for (int kd = 0; kd < kernel_size; ++kd) {
                for (int kh = 0; kh < kernel_size; ++kh) {
                    for (int kw = 0; kw < kernel_size; ++kw) {
                        int in_d = d + kd - kernel_size / 2;
                        int in_h = h + kh - kernel_size / 2;
                        int in_w = w + kw - kernel_size / 2;
                        if (in_d >= 0 && in_d < D && in_h >= 0 && in_h < H && in_w >= 0 && in_w < W) {
                            int input_idx = b * in_channels * D * H * W + c_in * D * H * W + in_d * H * W + in_h * W + in_w;
                            int weight_idx = c_out * in_channels * kernel_size * kernel_size * kernel_size + c_in * kernel_size * kernel_size * kernel_size + kd * kernel_size * kernel_size + kh * kernel_size + kw;
                            sum += input[input_idx] * weight[weight_idx];
                        }
                    }
                }
            }
        }
        int output_idx = b * out_channels * D * H * W + c_out * D * H * W + d * H * W + h * W + w;
        output[output_idx] = sum;
    }
}

torch::Tensor conv3d_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int D, int H, int W, int kernel_size) {
    auto output = torch::zeros({batch_size, out_channels, D, H, W}, input.options());
    int num_threads = W;
    int num_blocks = batch_size * out_channels * D * H;
    conv3d_kernel<<<num_blocks, num_threads>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, out_channels, D, H, W, kernel_size);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, num_groups):
        super().__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size)
        self.group_norm = nn.GroupNorm(num_groups, out_channels)

    def forward(self, x):
        weight = self.conv.weight.view(-1)
        x = _get_mod().conv3d_cuda(x, weight, x.size(0), x.size(1), self.conv.out_channels, x.size(2), x.size(3), x.size(4), self.conv.kernel_size[0])
        x = self.group_norm(x)
        x = x.mean(dim=[1, 2, 3, 4])
        return x
