import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv3d_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int D, int H, int W, int kernel_size) {
    int b = blockIdx.x / (out_channels * D * H * W);
    int out_c = (blockIdx.x % (out_channels * D * H * W)) / (D * H * W);
    int d = ((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) / (H * W);
    int h = (((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) % (H * W)) / W;
    int w = (((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) % (H * W)) % W;

    if (b < batch_size && out_c < out_channels && d < D && h < H && w < W) {
        float sum = 0.0f;
        for (int ic = 0; ic < in_channels; ++ic) {
            for (int kd = 0; kd < kernel_size; ++kd) {
                for (int kh = 0; kh < kernel_size; ++kh) {
                    for (int kw = 0; kw < kernel_size; ++kw) {
                        int di = d + kd - kernel_size / 2;
                        int hi = h + kh - kernel_size / 2;
                        int wi = w + kw - kernel_size / 2;
                        if (di >= 0 && di < D && hi >= 0 && hi < H && wi >= 0 && wi < W) {
                            int input_idx = b * in_channels * D * H * W + ic * D * H * W + di * H * W + hi * W + wi;
                            int weight_idx = out_c * in_channels * kernel_size * kernel_size * kernel_size + ic * kernel_size * kernel_size * kernel_size + kd * kernel_size * kernel_size + kh * kernel_size + kw;
                            sum += input[input_idx] * weight[weight_idx];
                        }
                    }
                }
            }
        }
        int output_idx = b * out_channels * D * H * W + out_c * D * H * W + d * H * W + h * W + w;
        output[output_idx] = sum;
    }
}

__global__ void group_norm_kernel(const float* input, float* output, const float* gamma, const float* beta, int batch_size, int out_channels, int num_groups, int D, int H, int W) {
    int b = blockIdx.x / (out_channels * D * H * W);
    int out_c = (blockIdx.x % (out_channels * D * H * W)) / (D * H * W);
    int d = ((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) / (H * W);
    int h = (((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) % (H * W)) / W;
    int w = (((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) % (H * W)) % W;

    if (b < batch_size && out_c < out_channels && d < D && h < H && w < W) {
        int group = out_c / (out_channels / num_groups);
        int group_size = out_channels / num_groups;
        int group_start = group * group_size;
        int group_end = group_start + group_size;

        float sum = 0.0f;
        float sum_sq = 0.0f;
        for (int c = group_start; c < group_end; ++c) {
            int input_idx = b * out_channels * D * H * W + c * D * H * W + d * H * W + h * W + w;
            sum += input[input_idx];
            sum_sq += input[input_idx] * input[input_idx];
        }

        float mean = sum / group_size;
        float var = (sum_sq / group_size) - (mean * mean);
        float inv_std = rsqrtf(var + 1e-5f);

        int output_idx = b * out_channels * D * H * W + out_c * D * H * W + d * H * W + h * W + w;
        output[output_idx] = gamma[out_c] * (input[input_idx] - mean) * inv_std + beta[out_c];
    }
}

__global__ void mean_kernel(const float* input, float* output, int batch_size, int out_channels, int D, int H, int W) {
    int b = blockIdx.x / (out_channels * D * H * W);
    int out_c = (blockIdx.x % (out_channels * D * H * W)) / (D * H * W);
    int d = ((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) / (H * W);
    int h = (((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) % (H * W)) / W;
    int w = (((blockIdx.x % (out_channels * D * H * W)) % (D * H * W)) % (H * W)) % W;

    if (b < batch_size && out_c < out_channels && d < D && h < H && w < W) {
        int input_idx = b * out_channels * D * H * W + out_c * D * H * W + d * H * W + h * W + w;
        atomicAdd(output + b, input[input_idx]);
    }
}

torch::Tensor conv3d_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int D, int H, int W, int kernel_size) {
    auto output = torch::zeros({batch_size, out_channels, D, H, W}, input.options());
    conv3d_kernel<<<(batch_size * out_channels * D * H * W + 255) / 256, 256>>>(
        input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, out_channels, D, H, W, kernel_size);
    return output;
}

torch::Tensor group_norm_cuda(torch::Tensor input, torch::Tensor gamma, torch::Tensor beta, int batch_size, int out_channels, int num_groups, int D, int H, int W) {
    auto output = torch::zeros_like(input);
    group_norm_kernel<<<(batch_size * out_channels * D * H * W + 255) / 256, 256>>>(
        input.data_ptr<float>(), output.data_ptr<float>(), gamma.data_ptr<float>(), beta.data_ptr<float>(), batch_size, out_channels, num_groups, D, H, W);
    return output;
}

torch::Tensor mean_cuda(torch::Tensor input, int batch_size, int out_channels, int D, int H, int W) {
    auto output = torch::zeros({batch_size}, input.options());
    mean_kernel<<<(batch_size * out_channels * D * H * W + 255) / 256, 256>>>(
        input.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_channels, D, H, W);
    return output;
}

TORCH_LIBRARY(my_ops, m) {
    m.def("conv3d_cuda", &conv3d_cuda);
    m.def("group_norm_cuda", &group_norm_cuda);
    m.def("mean_cuda", &mean_cuda);
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv3d_cuda", "group_norm_cuda", "mean_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, num_groups):
        super().__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size)
        self.group_norm = nn.GroupNorm(num_groups, out_channels)

    def forward(self, x):
        batch_size, in_channels, D, H, W = x.size()
        weight = self.conv.weight
        gamma = self.group_norm.weight
        beta = self.group_norm.bias

        x = _get_mod().conv3d_cuda(x, weight, batch_size, in_channels, out_channels, D, H, W, kernel_size)
        x = _get_mod().group_norm_cuda(x, gamma, beta, batch_size, out_channels, self.group_norm.num_groups, D, H, W)
        x = _get_mod().mean_cuda(x, batch_size, out_channels, D, H, W).view(batch_size, 1)

        return x
