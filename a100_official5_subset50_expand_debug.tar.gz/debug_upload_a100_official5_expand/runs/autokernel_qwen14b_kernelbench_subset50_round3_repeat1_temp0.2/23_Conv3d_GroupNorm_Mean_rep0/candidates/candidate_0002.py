import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv3d_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int D, int H, int W, int kernel_size) {
    int b = blockIdx.x / (out_channels * D * H * W);
    int oc = (blockIdx.x % (out_channels * D * H * W)) / (D * H * W);
    int d = (blockIdx.x % (D * H * W)) / (H * W);
    int h = (blockIdx.x % (H * W)) / W;
    int w = blockIdx.x % W;

    if (b < batch_size && oc < out_channels && d < D && h < H && w < W) {
        float sum = 0.0f;
        for (int ic = 0; ic < in_channels; ++ic) {
            for (int kd = 0; kd < kernel_size; ++kd) {
                for (int kh = 0; kh < kernel_size; ++kh) {
                    for (int kw = 0; kw < kernel_size; ++kw) {
                        int di = d + kd - kernel_size / 2;
                        int hi = h + kh - kernel_size / 2;
                        int wi = w + kw - kernel_size / 2;
                        if (di >= 0 && di < D && hi >= 0 && hi < H && wi >= 0 && wi < W) {
                            int input_idx = b * in_channels * D * H * W + ic * D * H * W + di * H * W + hi * W + wi;
                            int weight_idx = oc * in_channels * kernel_size * kernel_size * kernel_size + ic * kernel_size * kernel_size * kernel_size + kd * kernel_size * kernel_size + kh * kernel_size + kw;
                            sum += input[input_idx] * weight[weight_idx];
                        }
                    }
                }
            }
        }
        int output_idx = b * out_channels * D * H * W + oc * D * H * W + d * H * W + h * W + w;
        output[output_idx] = sum;
    }
}

__global__ void group_norm_kernel(const float* input, float* output, const float* gamma, const float* beta, int batch_size, int out_channels, int num_groups, int D, int H, int W) {
    int b = blockIdx.x / (out_channels * D * H * W);
    int c = blockIdx.x % (out_channels * D * H * W);
    int g = c / (out_channels / num_groups);
    int gc = c % (out_channels / num_groups);

    if (b < batch_size && c < out_channels) {
        float sum = 0.0f;
        float sum_sq = 0.0f;
        int count = D * H * W;
        for (int d = 0; d < D; ++d) {
            for (int h = 0; h < H; ++h) {
                for (int w = 0; w < W; ++w) {
                    int idx = b * out_channels * D * H * W + c * D * H * W + d * H * W + h * W + w;
                    sum += input[idx];
                    sum_sq += input[idx] * input[idx];
                }
            }
        }

        float mean = sum / count;
        float var = (sum_sq / count) - mean * mean;
        float inv_std = rsqrtf(var + 1e-5f);

        for (int d = 0; d < D; ++d) {
            for (int h = 0; h < H; ++h) {
                for (int w = 0; w < W; ++w) {
                    int idx = b * out_channels * D * H * W + c * D * H * W + d * H * W + h * W + w;
                    output[idx] = gamma[g] * (input[idx] - mean) * inv_std + beta[g];
                }
            }
        }
    }
}

__global__ void mean_kernel(const float* input, float* output, int batch_size, int out_channels, int D, int H, int W) {
    int b = blockIdx.x;
    if (b < batch_size) {
        float sum = 0.0f;
        int count = out_channels * D * H * W;
        for (int c = 0; c < out_channels; ++c) {
            for (int d = 0; d < D; ++d) {
                for (int h = 0; h < H; ++h) {
                    for (int w = 0; w < W; ++w) {
                        int idx = b * out_channels * D * H * W + c * D * H * W + d * H * W + h * W + w;
                        sum += input[idx];
                    }
                }
            }
        }
        output[b] = sum / count;
    }
}

torch::Tensor conv3d_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int D, int H, int W, int kernel_size) {
    auto output = torch::zeros({batch_size, out_channels, D, H, W}, input.options());
    conv3d_kernel<<<(batch_size * out_channels * D * H * W + 255) / 256, 256>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, out_channels, D, H, W, kernel_size);
    return output;
}

torch::Tensor group_norm_cuda(torch::Tensor input, torch::Tensor gamma, torch::Tensor beta, int batch_size, int out_channels, int num_groups, int D, int H, int W) {
    auto output = torch::zeros_like(input);
    group_norm_kernel<<<(batch_size * out_channels * D * H * W + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), gamma.data_ptr<float>(), beta.data_ptr<float>(), batch_size, out_channels, num_groups, D, H, W);
    return output;
}

torch::Tensor mean_cuda(torch::Tensor input, int batch_size, int out_channels, int D, int H, int W) {
    auto output = torch::zeros({batch_size}, input.options());
    mean_kernel<<<batch_size, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_channels, D, H, W);
    return output;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("conv3d_cuda", &conv3d_cuda, "Conv3d CUDA");
    m.def("group_norm_cuda", &group_norm_cuda, "GroupNorm CUDA");
    m.def("mean_cuda", &mean_cuda, "Mean CUDA");
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv3d_cuda", "group_norm_cuda", "mean_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, num_groups):
        super().__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size)
        self.group_norm = nn.GroupNorm(num_groups, out_channels)

    def forward(self, x):
        weight = self.conv.weight.contiguous()
        bias = self.conv.bias.contiguous()
        gamma = self.group_norm.weight.contiguous()
        beta = self.group_norm.bias.contiguous()

        x = _get_mod().conv3d_cuda(x, weight, x.size(0), x.size(1), self.conv.out_channels, x.size(2), x.size(3), x.size(4), self.conv.kernel_size[0])
        x = _get_mod().group_norm_cuda(x, gamma, beta, x.size(0), self.group_norm.num_channels, self.group_norm.num_groups, x.size(2), x.size(3), x.size(4))
        x = _get_mod().mean_cuda(x, x.size(0), x.size(1), x.size(2), x.size(3), x.size(4))

        return x
