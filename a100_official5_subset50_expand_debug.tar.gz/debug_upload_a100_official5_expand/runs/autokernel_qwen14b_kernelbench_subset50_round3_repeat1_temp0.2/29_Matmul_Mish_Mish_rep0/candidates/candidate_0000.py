import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void mish_kernel(const float* input, float* output, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        float val = input[idx];
        float sigmoid_val = 1.0f / (1.0f + expf(-val));
        output[idx] = val * sigmoid_val * (1.0f + sigmoid_val);
    }
}

__global__ void linear_kernel(const float* input, const float* weight, const float* bias, float* output, int N, int M, int K) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (row < N && col < M) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += input[row * K + k] * weight[k * M + col];
        }
        output[row * M + col] = sum + bias[col];
    }
}

torch::Tensor linear_mish_cuda(torch::Tensor input, torch::Tensor weight, torch::Tensor bias) {
    int N = input.size(0);
    int M = weight.size(1);
    int K = weight.size(0);
    auto output = torch::empty({N, M}, input.options());
    linear_kernel<<<(N + 15) / 16, (M + 15) / 16>>>(input.data_ptr<float>(), weight.data_ptr<float>(), bias.data_ptr<float>(), output.data_ptr<float>(), N, M, K);
    mish_kernel<<<(N * M + 255) / 256, 256>>>(output.data_ptr<float>(), output.data_ptr<float>(), N * M);
    mish_kernel<<<(N * M + 255) / 256, 256>>>(output.data_ptr<float>(), output.data_ptr<float>(), N * M);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "linear_mish_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features):
        super(ModelNew, self).__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x):
        return _get_mod().linear_mish_cuda(x, self.linear.weight, self.linear.bias)
