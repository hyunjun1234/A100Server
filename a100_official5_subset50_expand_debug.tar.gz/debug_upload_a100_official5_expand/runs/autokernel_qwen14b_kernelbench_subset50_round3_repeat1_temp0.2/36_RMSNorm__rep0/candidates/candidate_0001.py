import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void rms_norm_kernel(const float* input, float* output, const float* eps, int batch_size, int num_features, int dim1, int dim2) {
    int b = blockIdx.x / (num_features * dim1 * dim2);
    int f = (blockIdx.x / (dim1 * dim2)) % num_features;
    int i = (blockIdx.x / dim2) % dim1;
    int j = blockIdx.x % dim2;

    int idx = b * num_features * dim1 * dim2 + f * dim1 * dim2 + i * dim2 + j;
    float sum = 0.0f;
    for (int k = 0; k < batch_size; ++k) {
        float val = input[k * num_features * dim1 * dim2 + f * dim1 * dim2 + i * dim2 + j];
        sum += val * val;
    }
    sum /= batch_size;
    sum += eps[0];
    float rms = sqrtf(sum);
    output[idx] = input[idx] / rms;
}

torch::Tensor rms_norm_cuda(torch::Tensor input, float eps, int batch_size, int num_features, int dim1, int dim2) {
    auto output = torch::empty_like(input);
    int total_elements = batch_size * num_features * dim1 * dim2;
    rms_norm_kernel<<<(total_elements + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), &eps, batch_size, num_features, dim1, dim2);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "rms_norm_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, num_features: int, eps: float = 1e-5):
        super(ModelNew, self).__init__()
        self.num_features = num_features
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, num_features, dim1, dim2 = x.size()
        return _get_mod().rms_norm_cuda(x, self.eps, batch_size, num_features, dim1, dim2)
