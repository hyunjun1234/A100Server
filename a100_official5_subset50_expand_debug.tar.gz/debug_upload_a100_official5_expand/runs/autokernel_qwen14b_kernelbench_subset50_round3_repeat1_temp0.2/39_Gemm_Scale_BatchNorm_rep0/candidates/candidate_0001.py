import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void gemm_kernel(const float* input, const float* weight, float* output, int batch_size, int in_features, int out_features) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < batch_size && col < out_features) {
        float sum = 0.0f;
        for (int k = 0; k < in_features; ++k) {
            sum += input[row * in_features + k] * weight[k * out_features + col];
        }
        output[row * out_features + col] = sum;
    }
}

__global__ void scale_kernel(const float* input, const float* scale, float* output, int batch_size, int out_features) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;

    if (idx < batch_size * out_features) {
        output[idx] = input[idx] * scale[idx % out_features];
    }
}

__global__ void bn_kernel(const float* input, float* output, float* running_mean, float* running_var, float* scale, float* bias, int batch_size, int out_features, float eps) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < batch_size && col < out_features) {
        float mean = running_mean[col];
        float var = running_var[col];
        float x = input[row * out_features + col];
        float norm = (x - mean) / sqrt(var + eps);
        output[row * out_features + col] = norm * scale[col] + bias[col];
    }
}

torch::Tensor gemm_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_features, int out_features) {
    auto output = torch::empty({batch_size, out_features}, input.options());
    dim3 threads(32, 32);
    dim3 blocks((out_features + threads.x - 1) / threads.x, (batch_size + threads.y - 1) / threads.y);
    gemm_kernel<<<blocks, threads>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_features, out_features);
    return output;
}

torch::Tensor scale_cuda(torch::Tensor input, torch::Tensor scale, int batch_size, int out_features) {
    auto output = torch::empty_like(input);
    dim3 threads(256);
    dim3 blocks((batch_size * out_features + threads.x - 1) / threads.x);
    scale_kernel<<<blocks, threads>>>(input.data_ptr<float>(), scale.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_features);
    return output;
}

torch::Tensor bn_cuda(torch::Tensor input, torch::Tensor running_mean, torch::Tensor running_var, torch::Tensor scale, torch::Tensor bias, int batch_size, int out_features, float eps) {
    auto output = torch::empty_like(input);
    dim3 threads(32, 32);
    dim3 blocks((out_features + threads.x - 1) / threads.x, (batch_size + threads.y - 1) / threads.y);
    bn_kernel<<<blocks, threads>>>(input.data_ptr<float>(), output.data_ptr<float>(), running_mean.data_ptr<float>(), running_var.data_ptr<float>(), scale.data_ptr<float>(), bias.data_ptr<float>(), batch_size, out_features, eps);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "gemm_cuda", "scale_cuda", "bn_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scale_shape, eps=1e-5, momentum=0.1):
        super().__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.scale = nn.Parameter(torch.randn(scale_shape))
        self.bn = nn.BatchNorm1d(out_features, eps=eps, momentum=momentum)

    def forward(self, x):
        mod = _get_mod()
        x = mod.gemm_cuda(x, self.gemm.weight, x.size(0), self.gemm.in_features, self.gemm.out_features)
        x = mod.scale_cuda(x, self.scale, x.size(0), self.gemm.out_features)
        x = mod.bn_cuda(x, self.bn.running_mean, self.bn.running_var, self.bn.weight, self.bn.bias, x.size(0), self.gemm.out_features, self.bn.eps)
        return x
