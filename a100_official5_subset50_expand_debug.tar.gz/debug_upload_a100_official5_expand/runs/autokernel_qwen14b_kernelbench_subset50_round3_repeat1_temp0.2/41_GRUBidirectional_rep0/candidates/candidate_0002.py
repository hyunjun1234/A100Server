import torch
import torch.nn as nn
import torch.nn.functional as F

class ModelNew(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers=3, bias=True, batch_first=False):
        super(ModelNew, self).__init__()
        self.gru = nn.GRU(input_size, hidden_size, num_layers, bias, batch_first, dropout=0, bidirectional=True)
        self.num_layers = num_layers
        self.hidden_size = hidden_size
        self.batch_size = None

    def forward(self, x, h0):
        if self.batch_size is None:
            self.batch_size = h0.size(1)
            self.h0 = torch.randn((self.num_layers * 2, self.batch_size, self.hidden_size)).to(x.device)
        else:
            self.h0 = h0
        output, h_n = self.gru(x, self.h0)
        return output
