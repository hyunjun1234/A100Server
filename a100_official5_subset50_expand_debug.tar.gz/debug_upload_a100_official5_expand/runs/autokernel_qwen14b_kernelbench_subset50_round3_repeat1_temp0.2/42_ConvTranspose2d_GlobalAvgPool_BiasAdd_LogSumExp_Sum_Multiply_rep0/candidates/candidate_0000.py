import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void conv_transpose_kernel(const float* input, float* output, const float* weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size) {
    int b = blockIdx.x / (out_channels * width);
    int oc = (blockIdx.x % (out_channels * width)) / width;
    int w = blockIdx.x % width;
    int h = blockIdx.y;

    int input_h = h * 2 - kernel_size + 1;
    int input_w = w * 2 - kernel_size + 1;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kh = 0; kh < kernel_size; ++kh) {
            for (int kw = 0; kw < kernel_size; ++kw) {
                int ih = input_h + kh;
                int iw = input_w + kw;
                if (ih >= 0 && ih < height && iw >= 0 && iw < width) {
                    sum += input[b * in_channels * height * width + ic * height * width + ih * width + iw] *
                           weight[oc * in_channels * kernel_size * kernel_size + ic * kernel_size * kernel_size + kh * kernel_size + kw];
                }
            }
        }
    }

    output[b * out_channels * height * width + oc * height * width + h * width + w] = sum;
}

__global__ void add_bias_kernel(float* x, const float* bias, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x / (out_channels * width);
    int oc = (blockIdx.x % (out_channels * width)) / width;
    int w = blockIdx.x % width;
    int h = blockIdx.y;

    x[b * out_channels * height * width + oc * height * width + h * width + w] += bias[oc];
}

__global__ void logsumexp_kernel(float* x, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x / out_channels;
    int oc = blockIdx.x % out_channels;

    extern __shared__ float sdata[];
    int tid = threadIdx.x;
    int i = b * out_channels * height * width + oc * height * width + tid;

    float max_val = -INFINITY;
    for (int j = 0; j < height * width; j += blockDim.x) {
        if (i + j < batch_size * out_channels * height * width) {
            max_val = fmaxf(max_val, x[i + j]);
        }
    }

    __syncthreads();

    float sum = 0.0f;
    for (int j = 0; j < height * width; j += blockDim.x) {
        if (i + j < batch_size * out_channels * height * width) {
            sum += expf(x[i + j] - max_val);
        }
    }

    sdata[tid] = sum;
    __syncthreads();

    for (unsigned int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) {
            sdata[tid] += sdata[tid + s];
        }
        __syncthreads();
    }

    if (tid == 0) {
        x[b * out_channels + oc] = max_val + logf(sdata[0]);
    }
}

__global__ void sum_kernel(float* x, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x;
    int oc = blockIdx.y;

    extern __shared__ float sdata[];
    int tid = threadIdx.x;
    int i = b * out_channels * height * width + oc * height * width + tid;

    float sum = 0.0f;
    for (int j = 0; j < height * width; j += blockDim.x) {
        if (i + j < batch_size * out_channels * height * width) {
            sum += x[i + j];
        }
    }

    sdata[tid] = sum;
    __syncthreads();

    for (unsigned int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) {
            sdata[tid] += sdata[tid + s];
        }
        __syncthreads();
    }

    if (tid == 0) {
        x[b * out_channels + oc] = sdata[0];
    }
}

__global__ void multiply_kernel(float* x, int batch_size, int out_channels) {
    int b = blockIdx.x;
    int oc = blockIdx.y;
    int i = b * out_channels + oc;
    x[i] *= 10.0f;
}

torch::Tensor conv_transpose_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size) {
    auto output = torch::zeros({batch_size, out_channels, height * 2 - kernel_size + 1, width * 2 - kernel_size + 1}, input.options());
    conv_transpose_kernel<<<(batch_size * out_channels * width + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), weight.data_ptr<float>(), batch_size, in_channels, out_channels, height, width, kernel_size);
    return output;
}

torch::Tensor add_bias_cuda(torch::Tensor x, torch::Tensor bias, int batch_size, int out_channels, int height, int width) {
    add_bias_kernel<<<(batch_size * out_channels * width + 255) / 256, 256>>>(x.data_ptr<float>(), bias.data_ptr<float>(), batch_size, out_channels, height, width);
    return x;
}

torch::Tensor logsumexp_cuda(torch::Tensor x, int batch_size, int out_channels, int height, int width) {
    auto output = torch::zeros({batch_size, out_channels}, x.options());
    logsumexp_kernel<<<batch_size * out_channels, 256, 256 * sizeof(float)>>>(x.data_ptr<float>(), batch_size, out_channels, height, width);
    return output;
}

torch::Tensor sum_cuda(torch::Tensor x, int batch_size, int out_channels, int height, int width) {
    auto output = torch::zeros({batch_size, out_channels}, x.options());
    sum_kernel<<<batch_size * out_channels, 256, 256 * sizeof(float)>>>(x.data_ptr<float>(), batch_size, out_channels, height, width);
    return output;
}

torch::Tensor multiply_cuda(torch::Tensor x, int batch_size, int out_channels) {
    multiply_kernel<<<batch_size * out_channels, 256>>>(x.data_ptr<float>(), batch_size, out_channels);
    return x;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose_cuda", "add_bias_cuda", "logsumexp_cuda", "sum_cuda", "multiply_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape):
        super().__init__()
        self.conv_transpose_weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size, kernel_size))
        self.bias = nn.Parameter(torch.randn(bias_shape))

    def forward(self, x):
        batch_size, in_channels, height, width = x.size()
        out_height = height * 2 - kernel_size + 1
        out_width = width * 2 - kernel_size + 1

        x = _get_mod().conv_transpose_cuda(x, self.conv_transpose_weight, batch_size, in_channels, out_channels, height, width, kernel_size)
        x = _get_mod().add_bias_cuda(x, self.bias, batch_size, out_channels, out_height, out_width)
        x = _get_mod().logsumexp_cuda(x, batch_size, out_channels, out_height, out_width)
        x = _get_mod().sum_cuda(x, batch_size, out_channels, out_height, out_width)
        x = _get_mod().multiply_cuda(x, batch_size, out_channels)
        return x
