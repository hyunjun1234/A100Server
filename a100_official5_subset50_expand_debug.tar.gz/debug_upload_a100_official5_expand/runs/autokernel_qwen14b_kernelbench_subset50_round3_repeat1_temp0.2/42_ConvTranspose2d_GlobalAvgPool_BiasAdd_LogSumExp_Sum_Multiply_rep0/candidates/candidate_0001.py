import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void conv_transpose_kernel(const float* input, float* output, const float* weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size) {
    int b = blockIdx.x / (out_channels * width);
    int oc = (blockIdx.x % (out_channels * width)) / width;
    int w = blockIdx.x % width;
    int h = blockIdx.y;

    int input_h = h * 2 - kernel_size + 1;
    int input_w = w * 2 - kernel_size + 1;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kh = 0; kh < kernel_size; ++kh) {
            for (int kw = 0; kw < kernel_size; ++kw) {
                int ih = input_h + kh;
                int iw = input_w + kw;
                if (ih >= 0 && ih < height && iw >= 0 && iw < width) {
                    sum += input[b * in_channels * height * width + ic * height * width + ih * width + iw] *
                           weight[oc * in_channels * kernel_size * kernel_size + ic * kernel_size * kernel_size + kh * kernel_size + kw];
                }
            }
        }
    }

    output[b * out_channels * height * width + oc * height * width + h * width + w] = sum;
}

__global__ void add_bias_kernel(float* output, const float* bias, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x / (out_channels * width);
    int oc = (blockIdx.x % (out_channels * width)) / width;
    int w = blockIdx.x % width;
    int h = blockIdx.y;

    output[b * out_channels * height * width + oc * height * width + h * width + w] += bias[oc];
}

__global__ void logsumexp_kernel(float* output, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x / out_channels;
    int oc = blockIdx.x % out_channels;

    float max_val = -INFINITY;
    for (int h = 0; h < height; ++h) {
        for (int w = 0; w < width; ++w) {
            max_val = fmaxf(max_val, output[b * out_channels * height * width + oc * height * width + h * width + w]);
        }
    }

    float sum_exp = 0.0f;
    for (int h = 0; h < height; ++h) {
        for (int w = 0; w < width; ++w) {
            sum_exp += expf(output[b * out_channels * height * width + oc * height * width + h * width + w] - max_val);
        }
    }

    output[b * out_channels * height * width + oc * height * width] = max_val + logf(sum_exp);
}

__global__ void sum_kernel(float* output, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x;
    int oc = blockIdx.y;

    float sum = 0.0f;
    for (int h = 0; h < height; ++h) {
        for (int w = 0; w < width; ++w) {
            sum += output[b * out_channels * height * width + oc * height * width + h * width + w];
        }
    }

    output[b * out_channels + oc] = sum;
}

__global__ void multiply_kernel(float* output, int batch_size, int out_channels, int height, int width, float scalar) {
    int b = blockIdx.x / out_channels;
    int oc = blockIdx.x % out_channels;
    int h = blockIdx.y;
    int w = blockIdx.z;

    output[b * out_channels * height * width + oc * height * width + h * width + w] *= scalar;
}

torch::Tensor conv_transpose_cuda(torch::Tensor input, torch::Tensor weight, int kernel_size) {
    auto output = torch::zeros_like(input, torch::dtype(torch::kFloat32).device(torch::kCUDA));
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int out_channels = weight.size(0);
    int height = input.size(2);
    int width = input.size(3);

    dim3 threads(16, 16);
    dim3 blocks((batch_size * out_channels * width + threads.x - 1) / threads.x, (height + threads.y - 1) / threads.y);
    conv_transpose_kernel<<<blocks, threads>>>(input.data_ptr<float>(), output.data_ptr<float>(), weight.data_ptr<float>(), batch_size, in_channels, out_channels, height, width, kernel_size);

    return output;
}

torch::Tensor add_bias_cuda(torch::Tensor output, torch::Tensor bias) {
    int batch_size = output.size(0);
    int out_channels = output.size(1);
    int height = output.size(2);
    int width = output.size(3);

    dim3 threads(16, 16);
    dim3 blocks((batch_size * out_channels * width + threads.x - 1) / threads.x, height);
    add_bias_kernel<<<blocks, threads>>>(output.data_ptr<float>(), bias.data_ptr<float>(), batch_size, out_channels, height, width);

    return output;
}

torch::Tensor logsumexp_cuda(torch::Tensor output) {
    int batch_size = output.size(0);
    int out_channels = output.size(1);
    int height = output.size(2);
    int width = output.size(3);

    dim3 threads(16, 16);
    dim3 blocks(batch_size * out_channels);
    logsumexp_kernel<<<blocks, threads>>>(output.data_ptr<float>(), batch_size, out_channels, height, width);

    return output;
}

torch::Tensor sum_cuda(torch::Tensor output) {
    int batch_size = output.size(0);
    int out_channels = output.size(1);
    int height = output.size(2);
    int width = output.size(3);

    dim3 threads(16, 16);
    dim3 blocks(batch_size * out_channels, height);
    sum_kernel<<<blocks, threads>>>(output.data_ptr<float>(), batch_size, out_channels, height, width);

    return output;
}

torch::Tensor multiply_cuda(torch::Tensor output, float scalar) {
    int batch_size = output.size(0);
    int out_channels = output.size(1);
    int height = output.size(2);
    int width = output.size(3);

    dim3 threads(16, 16);
    dim3 blocks(batch_size * out_channels, height, width);
    multiply_kernel<<<blocks, threads>>>(output.data_ptr<float>(), batch_size, out_channels, height, width, scalar);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape):
        super().__init__()
        self.conv_transpose_weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size, kernel_size))
        self.bias = nn.Parameter(torch.randn(bias_shape))

    def forward(self, x):
        x = _get_mod().conv_transpose_cuda(x, self.conv_transpose_weight, self.conv_transpose_weight.size(2))
        x = torch.mean(x, dim=(2, 3), keepdim=True)
        x = _get_mod().add_bias_cuda(x, self.bias)
        x = _get_mod().logsumexp_cuda(x)
        x = _get_mod().sum_cuda(x)
        x = _get_mod().multiply_cuda(x, 10.0)
        return x
