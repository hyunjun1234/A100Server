import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void add_bias_kernel(const float* input, const float* bias, float* output, int N, int C, int H, int W) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N * C * H * W) {
        int n = idx / (C * H * W);
        int c = (idx / (H * W)) % C;
        int h = (idx / W) % H;
        int w = idx % W;
        output[idx] = input[idx] + bias[c];
    }
}

__global__ void logsumexp_kernel(const float* input, float* output, int N, int C, int H, int W) {
    extern __shared__ float shared_mem[];
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    int tid = threadIdx.x;
    int stride = blockDim.x;

    float max_val = -1e38;
    for (int i = idx; i < N * C * H * W; i += stride) {
        int n = i / (C * H * W);
        int c = (i / (H * W)) % C;
        int h = (i / W) % H;
        int w = i % W;
        max_val = fmaxf(max_val, input[i]);
    }

    shared_mem[tid] = max_val;
    __syncthreads();

    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) {
            shared_mem[tid] = fmaxf(shared_mem[tid], shared_mem[tid + s]);
        }
        __syncthreads();
    }

    float max_val_final = shared_mem[0];
    __syncthreads();

    float sum_exp = 0.0f;
    for (int i = idx; i < N * C * H * W; i += stride) {
        int n = i / (C * H * W);
        int c = (i / (H * W)) % C;
        int h = (i / W) % H;
        int w = i % W;
        sum_exp += expf(input[i] - max_val_final);
    }

    shared_mem[tid] = sum_exp;
    __syncthreads();

    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) {
            shared_mem[tid] += shared_mem[tid + s];
        }
        __syncthreads();
    }

    float sum_exp_final = shared_mem[0];
    __syncthreads();

    for (int i = idx; i < N * C * H * W; i += stride) {
        int n = i / (C * H * W);
        int c = (i / (H * W)) % C;
        int h = (i / W) % H;
        int w = i % W;
        output[i] = max_val_final + logf(sum_exp_final);
    }
}

__global__ void sum_kernel(const float* input, float* output, int N, int C, int H, int W) {
    extern __shared__ float shared_mem[];
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    int tid = threadIdx.x;
    int stride = blockDim.x;

    float sum = 0.0f;
    for (int i = idx; i < N * C * H * W; i += stride) {
        sum += input[i];
    }

    shared_mem[tid] = sum;
    __syncthreads();

    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) {
            shared_mem[tid] += shared_mem[tid + s];
        }
        __syncthreads();
    }

    float sum_final = shared_mem[0];
    __syncthreads();

    if (tid == 0) {
        output[blockIdx.x] = sum_final;
    }
}

torch::Tensor conv_transpose_add_bias_logsumexp_sum_cuda(torch::Tensor input, torch::Tensor weight, torch::Tensor bias, int kernel_size) {
    auto output = torch::conv_transpose2d(input, weight, {}, kernel_size, 0, 1, 1, 0);
    int N = output.size(0);
    int C = output.size(1);
    int H = output.size(2);
    int W = output.size(3);

    add_bias_kernel<<<(N * C * H * W + 255) / 256, 256>>>(output.data_ptr<float>(), bias.data_ptr<float>(), output.data_ptr<float>(), N, C, H, W);
    logsumexp_kernel<<<(N * C * H * W + 255) / 256, 256, 256 * sizeof(float)>>>(output.data_ptr<float>(), output.data_ptr<float>(), N, C, H, W);
    sum_kernel<<<N, 256, 256 * sizeof(float)>>>(output.data_ptr<float>(), output.data_ptr<float>(), N, C, H, W);

    return output.view({N, 1});
}

TORCH_LIBRARY(conv_transpose_cuda, m) {
    m.def("conv_transpose_add_bias_logsumexp_sum_cuda", &conv_transpose_add_bias_logsumexp_sum_cuda);
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose_add_bias_logsumexp_sum_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape):
        super().__init__()
        self.conv_transpose = nn.ConvTranspose2d(in_channels, out_channels, kernel_size)
        self.bias = nn.Parameter(torch.randn(bias_shape))

    def forward(self, x):
        weight = self.conv_transpose.weight
        bias = self.bias.view(-1, 1, 1, 1)
        return _get_mod().conv_transpose_add_bias_logsumexp_sum_cuda(x, weight, bias, self.conv_transpose.kernel_size[0]) * 10.0
