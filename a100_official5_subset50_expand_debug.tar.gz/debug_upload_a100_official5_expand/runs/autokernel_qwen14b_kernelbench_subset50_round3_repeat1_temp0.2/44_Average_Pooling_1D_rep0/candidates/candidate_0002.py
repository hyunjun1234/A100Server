import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs 1D Average Pooling using a custom CUDA kernel.
    """
    def __init__(self, kernel_size: int, stride: int = 1, padding: int = 0):
        """
        Initializes the 1D Average Pooling layer.

        Args:
            kernel_size (int): Size of the pooling window.
            stride (int, optional): Stride of the pooling operation. Defaults to 1.
            padding (int, optional): Padding applied to the input tensor. Defaults to 0.
        """
        super(ModelNew, self).__init__()
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Applies 1D Average Pooling to the input tensor using a custom CUDA kernel.

        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_channels, input_length).

        Returns:
            torch.Tensor: Output tensor with 1D Average Pooling applied, shape (batch_size, in_channels, output_length).
        """
        # Fallback to PyTorch implementation if CUDA kernel is not available
        if not x.is_cuda:
            return nn.functional.avg_pool1d(x, kernel_size=self.kernel_size, stride=self.stride, padding=self.padding)

        # Custom CUDA kernel implementation
        from kernels.cuda._compile import compile_cuda

        CUDA_SRC = r"""
        #include <torch/extension.h>
        #include <cuda_runtime.h>

        __global__ void avg_pool1d_kernel(const float* input, float* output, int batch_size, int in_channels, int input_length, int kernel_size, int stride, int padding) {
            int batch_idx = blockIdx.x / (in_channels * ((input_length + 2 * padding - kernel_size) / stride + 1));
            int channel_idx = (blockIdx.x % (in_channels * ((input_length + 2 * padding - kernel_size) / stride + 1))) / ((input_length + 2 * padding - kernel_size) / stride + 1);
            int output_idx = blockIdx.x % ((input_length + 2 * padding - kernel_size) / stride + 1);

            int input_start = output_idx * stride - padding;
            int input_end = input_start + kernel_size;

            float sum = 0.0f;
            for (int i = input_start; i < input_end; ++i) {
                if (i >= 0 && i < input_length) {
                    sum += input[batch_idx * in_channels * input_length + channel_idx * input_length + i];
                }
            }

            output[batch_idx * in_channels * ((input_length + 2 * padding - kernel_size) / stride + 1) + channel_idx * ((input_length + 2 * padding - kernel_size) / stride + 1) + output_idx] = sum / kernel_size;
        }

        torch::Tensor avg_pool1d_cuda(torch::Tensor input, int kernel_size, int stride, int padding) {
            int batch_size = input.size(0);
            int in_channels = input.size(1);
            int input_length = input.size(2);
            int output_length = (input_length + 2 * padding - kernel_size) / stride + 1;

            auto output = torch::empty({batch_size, in_channels, output_length}, input.options());
            avg_pool1d_kernel<<<(batch_size * in_channels * output_length + 255) / 256, 256>>>(
                input.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, input_length, kernel_size, stride, padding);
            return output;
        }
        """

        _mod = compile_cuda(CUDA_SRC, "avg_pool1d_cuda")
        return _mod.avg_pool1d_cuda(x, self.kernel_size, self.stride, self.padding)

batch_size = 64
in_channels = 128
input_length = 65536
kernel_size = 8
stride = 1
padding = 4

def get_inputs():
    x = torch.rand(batch_size, in_channels, input_length).cuda()
    return [x]

def get_init_inputs():
    return [kernel_size, stride, padding]
