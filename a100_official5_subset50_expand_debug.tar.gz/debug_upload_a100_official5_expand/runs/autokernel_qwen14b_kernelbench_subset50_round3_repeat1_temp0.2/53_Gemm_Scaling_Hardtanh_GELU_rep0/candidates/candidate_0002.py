import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void gemm_kernel(const float* input, const float* weight, float* output, int M, int N, int K) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += input[row * K + k] * weight[k * N + col];
        }
        output[row * N + col] = sum;
    }
}

__global__ void scale_kernel(float* data, float scale, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        data[idx] *= scale;
    }
}

__global__ void hardtanh_kernel(float* data, float min_val, float max_val, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        data[idx] = fmaxf(min_val, fminf(max_val, data[idx]));
    }
}

__global__ void gelu_kernel(float* data, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        float x = data[idx];
        data[idx] = x * 0.5f * (1.0f + tanhf(0.7978845608028654f * (x + 0.044715f * x * x * x)));
    }
}

torch::Tensor gemm_cuda(torch::Tensor input, torch::Tensor weight, int M, int N, int K) {
    auto output = torch::empty({M, N}, input.options());
    gemm_kernel<<<(M+15)/16, (N+15)/16>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), M, N, K);
    return output;
}

torch::Tensor scale_cuda(torch::Tensor input, float scale, int size) {
    auto output = torch::empty_like(input);
    scale_kernel<<<(size+255)/256, 256>>>(input.data_ptr<float>(), scale, size);
    return output;
}

torch::Tensor hardtanh_cuda(torch::Tensor input, float min_val, float max_val, int size) {
    auto output = torch::empty_like(input);
    hardtanh_kernel<<<(size+255)/256, 256>>>(input.data_ptr<float>(), min_val, max_val, size);
    return output;
}

torch::Tensor gelu_cuda(torch::Tensor input, int size) {
    auto output = torch::empty_like(input);
    gelu_kernel<<<(size+255)/256, 256>>>(input.data_ptr<float>(), size);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "gemm_cuda", "scale_cuda", "hardtanh_cuda", "gelu_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scaling_factor, hardtanh_min, hardtanh_max):
        super().__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.scaling_factor = scaling_factor
        self.hardtanh_min = hardtanh_min
        self.hardtanh_max = hardtanh_max

    def forward(self, x):
        mod = _get_mod()
        x = mod.gemm_cuda(x, self.gemm.weight, x.size(0), self.gemm.out_features, self.gemm.in_features)
        x = mod.scale_cuda(x, self.scaling_factor, x.numel())
        x = mod.hardtanh_cuda(x, self.hardtanh_min, self.hardtanh_max, x.numel())
        x = mod.gelu_cuda(x, x.numel())
        return x
