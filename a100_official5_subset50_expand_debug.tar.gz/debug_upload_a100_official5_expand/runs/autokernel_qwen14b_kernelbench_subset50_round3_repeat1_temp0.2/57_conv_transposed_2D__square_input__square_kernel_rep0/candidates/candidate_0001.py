import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose2d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels, int kernel_size,
    int stride, int padding, int output_padding, int groups,
    int height, int width, int height_out, int width_out) {
    
    int b = blockIdx.x / (out_channels * height_out);
    int oc = (blockIdx.x % (out_channels * height_out)) / height_out;
    int oy = blockIdx.x % height_out;
    int ox = threadIdx.x;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int ky = 0; ky < kernel_size; ++ky) {
            for (int kx = 0; kx < kernel_size; ++kx) {
                int ix = ox - kx * stride + padding;
                int iy = oy - ky * stride + padding;
                if (ix >= 0 && ix < width && iy >= 0 && iy < height) {
                    int input_idx = b * in_channels * height * width + ic * height * width + iy * width + ix;
                    int weight_idx = oc * in_channels * kernel_size * kernel_size + ic * kernel_size * kernel_size + ky * kernel_size + kx;
                    sum += input[input_idx] * weight[weight_idx];
                }
            }
        }
    }

    int output_idx = b * out_channels * height_out * width_out + oc * height_out * width_out + oy * width_out + ox;
    output[output_idx] = sum + bias[oc];
}

torch::Tensor conv_transpose2d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int in_channels, int out_channels, int kernel_size,
    int stride, int padding, int output_padding, int groups,
    int height, int width, int height_out, int width_out) {
    
    auto output = torch::zeros({batch_size, out_channels, height_out, width_out}, input.options());
    int num_blocks = batch_size * out_channels * height_out;
    int threads_per_block = width_out;
    conv_transpose2d_kernel<<<num_blocks, threads_per_block>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels, kernel_size,
        stride, padding, output_padding, groups,
        height, width, height_out, width_out);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose2d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, output_padding: int = 0, groups: int = 1, bias: bool = False):
        super().__init__()
        self.conv_transpose2d = nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, groups=groups, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        try:
            weight = self.conv_transpose2d.weight.contiguous()
            bias = self.conv_transpose2d.bias.contiguous() if self.conv_transpose2d.bias is not None else torch.zeros(out_channels, device=x.device)
            return _get_mod().conv_transpose2d_cuda(
                x, weight, bias,
                self.conv_transpose2d.in_channels, self.conv_transpose2d.out_channels, self.conv_transpose2d.kernel_size[0],
                self.conv_transpose2d.stride[0], self.conv_transpose2d.padding[0], self.conv_transpose2d.output_padding[0], self.conv_transpose2d.groups,
                x.size(2), x.size(3), x.size(2) * self.conv_transpose2d.stride[0] - 2 * self.conv_transpose2d.padding[0] + self.conv_transpose2d.kernel_size[0] + self.conv_transpose2d.output_padding[0],
                x.size(3) * self.conv_transpose2d.stride[0] - 2 * self.conv_transpose2d.padding[0] + self.conv_transpose2d.kernel_size[0] + self.conv_transpose2d.output_padding[0]
            )
        except Exception as e:
            print(f"CUDA kernel failed: {e}")
            return self.conv_transpose2d(x)
