import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose3d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int depth_in, int height_in, int width_in,
    int depth_out, int height_out, int width_out,
    int kernel_depth, int kernel_height, int kernel_width,
    int stride_d, int stride_h, int stride_w,
    int padding_d, int padding_h, int padding_w,
    int output_padding_d, int output_padding_h, int output_padding_w,
    int groups) {
    int b = blockIdx.x / (out_channels * depth_out * height_out * width_out);
    int oc = (blockIdx.x % (out_channels * depth_out * height_out * width_out)) / (depth_out * height_out * width_out);
    int d_out = (blockIdx.x % (depth_out * height_out * width_out)) / (height_out * width_out);
    int h_out = (blockIdx.x % (height_out * width_out)) / width_out;
    int w_out = blockIdx.x % width_out;

    int d_in_start = d_out * stride_d - padding_d;
    int h_in_start = h_out * stride_h - padding_h;
    int w_in_start = w_out * stride_w - padding_w;

    float sum = 0.0f;
    for (int g = 0; g < groups; ++g) {
        int in_group = g * in_channels / groups;
        int out_group = g * out_channels / groups;
        for (int kd = 0; kd < kernel_depth; ++kd) {
            int d_in = d_in_start + kd;
            if (d_in < 0 || d_in >= depth_in) continue;
            for (int kh = 0; kh < kernel_height; ++kh) {
                int h_in = h_in_start + kh;
                if (h_in < 0 || h_in >= height_in) continue;
                for (int kw = 0; kw < kernel_width; ++kw) {
                    int w_in = w_in_start + kw;
                    if (w_in < 0 || w_in >= width_in) continue;
                    int input_idx = b * in_channels * depth_in * height_in * width_in +
                                    (in_group + (d_in * height_in + h_in) * width_in + w_in);
                    int weight_idx = out_group * kernel_depth * kernel_height * kernel_width * in_channels / groups +
                                     (kd * kernel_height * kernel_width * in_channels / groups +
                                      kh * kernel_width * in_channels / groups +
                                      kw * in_channels / groups +
                                      (in_group + (d_in * height_in + h_in) * width_in + w_in));
                    sum += input[input_idx] * weight[weight_idx];
                }
            }
        }
    }

    int output_idx = b * out_channels * depth_out * height_out * width_out +
                     oc * depth_out * height_out * width_out +
                     d_out * height_out * width_out +
                     h_out * width_out +
                     w_out;
    output[output_idx] = sum + (bias ? bias[oc] : 0.0f);
}

torch::Tensor conv_transpose3d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int depth_in, int height_in, int width_in,
    int depth_out, int height_out, int width_out,
    int kernel_depth, int kernel_height, int kernel_width,
    int stride_d, int stride_h, int stride_w,
    int padding_d, int padding_h, int padding_w,
    int output_padding_d, int output_padding_h, int output_padding_w,
    int groups) {
    auto output = torch::zeros({batch_size, out_channels, depth_out, height_out, width_out}, input.options());
    int num_threads = 256;
    int num_blocks = (batch_size * out_channels * depth_out * height_out * width_out + num_threads - 1) / num_threads;
    conv_transpose3d_kernel<<<num_blocks, num_threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        depth_in, height_in, width_in,
        depth_out, height_out, width_out,
        kernel_depth, kernel_height, kernel_width,
        stride_d, stride_h, stride_w,
        padding_d, padding_h, padding_w,
        output_padding_d, output_padding_h, output_padding_w,
        groups);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1, 1), padding: tuple = (0, 0, 0), output_padding: tuple = (0, 0, 0), groups: int = 1, bias: bool = False):
        super().__init__()
        self.conv_transpose3d = nn.ConvTranspose3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, groups=groups, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        try:
            return _get_mod().conv_transpose3d_cuda(
                x, self.conv_transpose3d.weight, self.conv_transpose3d.bias,
                x.size(0), x.size(1), self.conv_transpose3d.out_channels,
                x.size(2), x.size(3), x.size(4),
                self.conv_transpose3d.output_size(x)[2], self.conv_transpose3d.output_size(x)[3], self.conv_transpose3d.output_size(x)[4],
                self.conv_transpose3d.kernel_size[0], self.conv_transpose3d.kernel_size[1], self.conv_transpose3d.kernel_size[2],
                self.conv_transpose3d.stride[0], self.conv_transpose3d.stride[1], self.conv_transpose3d.stride[2],
                self.conv_transpose3d.padding[0], self.conv_transpose3d.padding[1], self.conv_transpose3d.padding[2],
                self.conv_transpose3d.output_padding[0], self.conv_transpose3d.output_padding[1], self.conv_transpose3d.output_padding[2],
                self.conv_transpose3d.groups
            )
        except Exception as e:
            print(f"CUDA kernel failed: {e}")
            return self.conv_transpose3d(x)
