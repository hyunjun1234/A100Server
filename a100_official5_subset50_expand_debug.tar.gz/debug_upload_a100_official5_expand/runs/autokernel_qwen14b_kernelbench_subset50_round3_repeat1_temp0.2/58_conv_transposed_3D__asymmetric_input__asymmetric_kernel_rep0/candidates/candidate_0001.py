import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose3d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int depth_in, int height_in, int width_in,
    int depth_out, int height_out, int width_out,
    int kernel_depth, int kernel_height, int kernel_width,
    int stride_d, int stride_h, int stride_w,
    int padding_d, int padding_h, int padding_w,
    int output_padding_d, int output_padding_h, int output_padding_w,
    int groups) {
    int b = blockIdx.x / (out_channels * depth_out * height_out);
    int oc = (blockIdx.x / (depth_out * height_out)) % out_channels;
    int d_out = (blockIdx.x / height_out) % depth_out;
    int h_out = (blockIdx.x % height_out);

    int d_in = d_out * stride_d - padding_d + output_padding_d;
    int h_in = h_out * stride_h - padding_h + output_padding_h;

    for (int w_out = threadIdx.x; w_out < width_out; w_out += blockDim.x) {
        int w_in = w_out * stride_w - padding_w + output_padding_w;
        float sum = 0.0f;

        for (int ic = 0; ic < in_channels; ++ic) {
            for (int kd = 0; kd < kernel_depth; ++kd) {
                int d = d_in + kd;
                if (d < 0 || d >= depth_in) continue;

                for (int kh = 0; kh < kernel_height; ++kh) {
                    int h = h_in + kh;
                    if (h < 0 || h >= height_in) continue;

                    for (int kw = 0; kw < kernel_width; ++kw) {
                        int w = w_in + kw;
                        if (w < 0 || w >= width_in) continue;

                        int input_idx = b * in_channels * depth_in * height_in * width_in +
                                       ic * depth_in * height_in * width_in +
                                       d * height_in * width_in +
                                       h * width_in +
                                       w;
                        int weight_idx = oc * in_channels * kernel_depth * kernel_height * kernel_width +
                                         ic * kernel_depth * kernel_height * kernel_width +
                                         kd * kernel_height * kernel_width +
                                         kh * kernel_width +
                                         kw;
                        sum += input[input_idx] * weight[weight_idx];
                    }
                }
            }
        }

        if (bias != nullptr) {
            sum += bias[oc];
        }

        int output_idx = b * out_channels * depth_out * height_out * width_out +
                         oc * depth_out * height_out * width_out +
                         d_out * height_out * width_out +
                         h_out * width_out +
                         w_out;
        output[output_idx] = sum;
    }
}

torch::Tensor conv_transpose3d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int depth_in, int height_in, int width_in,
    int depth_out, int height_out, int width_out,
    int kernel_depth, int kernel_height, int kernel_width,
    int stride_d, int stride_h, int stride_w,
    int padding_d, int padding_h, int padding_w,
    int output_padding_d, int output_padding_h, int output_padding_w,
    int groups) {
    auto output = torch::zeros({batch_size, out_channels, depth_out, height_out, width_out}, input.options());
    int threads = 256;
    int blocks = batch_size * out_channels * depth_out * height_out;
    conv_transpose3d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.defined() ? bias.data_ptr<float>() : nullptr,
        batch_size, in_channels, out_channels,
        depth_in, height_in, width_in,
        depth_out, height_out, width_out,
        kernel_depth, kernel_height, kernel_width,
        stride_d, stride_h, stride_w,
        padding_d, padding_h, padding_w,
        output_padding_d, output_padding_h, output_padding_w,
        groups);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1, 1), padding: tuple = (0, 0, 0), output_padding: tuple = (0, 0, 0), groups: int = 1, bias: bool = False):
        super().__init__()
        self.conv_transpose3d = nn.ConvTranspose3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, groups=groups, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv_transpose3d.weight
        bias = self.conv_transpose3d.bias if self.conv_transpose3d.bias is not None else torch.zeros(self.conv_transpose3d.out_channels, device=x.device)
        
        batch_size, in_channels, depth_in, height_in, width_in = x.shape
        _, out_channels, kernel_depth, kernel_height, kernel_width = weight.shape
        stride_d, stride_h, stride_w = self.conv_transpose3d.stride
        padding_d, padding_h, padding_w = self.conv_transpose3d.padding
        output_padding_d, output_padding_h, output_padding_w = self.conv_transpose3d.output_padding
        groups = self.conv_transpose3d.groups
        
        depth_out = (depth_in - 1) * stride_d - 2 * padding_d + kernel_depth + output_padding_d
        height_out = (height_in - 1) * stride_h - 2 * padding_h + kernel_height + output_padding_h
        width_out = (width_in - 1) * stride_w - 2 * padding_w + kernel_width + output_padding_w
        
        return _get_mod().conv_transpose3d_cuda(
            x, weight, bias,
            batch_size, in_channels, out_channels,
            depth_in, height_in, width_in,
            depth_out, height_out, width_out,
            kernel_depth, kernel_height, kernel_width,
            stride_d, stride_h, stride_w,
            padding_d, padding_h, padding_w,
            output_padding_d, output_padding_h, output_padding_w,
            groups)
