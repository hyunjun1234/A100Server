import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv3d_kernel(
    const float* input, 
    const float* weight, 
    float* output, 
    int batch_size, 
    int in_channels, 
    int out_channels, 
    int height, 
    int width, 
    int depth, 
    int kernel_size, 
    int stride, 
    int padding, 
    int dilation, 
    int groups) {
    
    int b = blockIdx.x / (out_channels * (height_out * width_out));
    int oc = (blockIdx.x / (height_out * width_out)) % out_channels;
    int oh = (blockIdx.x / width_out) % height_out;
    int ow = blockIdx.x % width_out;

    int ih = oh * stride - padding;
    int iw = ow * stride - padding;
    int id = 0;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kh = 0; kh < kernel_size; ++kh) {
            for (int kw = 0; kw < kernel_size; ++kw) {
                if (ih + kh * dilation >= 0 && ih + kh * dilation < height && iw + kw * dilation >= 0 && iw + kw * dilation < width) {
                    sum += input[b * in_channels * height * width * depth + ic * height * width * depth + (ih + kh * dilation) * width * depth + (iw + kw * dilation) * depth + id] *
                           weight[oc * in_channels * kernel_size * kernel_size * depth + ic * kernel_size * kernel_size * depth + kh * kernel_size * depth + kw * depth + id];
                }
            }
        }
    }

    output[b * out_channels * height_out * width_out + oc * height_out * width_out + oh * width_out + ow] = sum;
}

torch::Tensor conv3d_cuda(
    torch::Tensor input, 
    torch::Tensor weight, 
    int out_channels, 
    int height_out, 
    int width_out) {
    
    auto output = torch::zeros({input.size(0), out_channels, height_out, width_out, input.size(4)});
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int height = input.size(2);
    int width = input.size(3);
    int depth = input.size(4);
    int kernel_size = weight.size(2);
    int stride = 1;
    int padding = 0;
    int dilation = 1;
    int groups = 1;

    int threads = 256;
    int blocks = (output.numel() + threads - 1) / threads;
    conv3d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), 
        weight.data_ptr<float>(), 
        output.data_ptr<float>(), 
        batch_size, 
        in_channels, 
        out_channels, 
        height, 
        width, 
        depth, 
        kernel_size, 
        stride, 
        padding, 
        dilation, 
        groups);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, groups: int = 1, bias: bool = False):
        super().__init__()
        self.conv3d = nn.Conv3d(in_channels, out_channels, (kernel_size, kernel_size, 1), stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv3d.weight
        out_channels = weight.size(0)
        height_out = (x.size(2) + 2 * self.conv3d.padding[0] - self.conv3d.dilation[0] * (self.conv3d.kernel_size[0] - 1) - 1) // self.conv3d.stride[0] + 1
        width_out = (x.size(3) + 2 * self.conv3d.padding[1] - self.conv3d.dilation[1] * (self.conv3d.kernel_size[1] - 1) - 1) // self.conv3d.stride[1] + 1
        return _get_mod().conv3d_cuda(x, weight, out_channels, height_out, width_out)
