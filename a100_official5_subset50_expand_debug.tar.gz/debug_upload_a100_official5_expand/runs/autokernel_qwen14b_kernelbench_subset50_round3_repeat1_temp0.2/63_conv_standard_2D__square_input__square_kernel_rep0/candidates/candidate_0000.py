import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv2d_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size, int stride, int padding, int dilation, int groups) {
    int b = blockIdx.x / (out_channels * (height + 2 * padding) / stride);
    int oc = (blockIdx.x % (out_channels * (height + 2 * padding) / stride)) / ((height + 2 * padding) / stride);
    int oy = (blockIdx.x % (out_channels * (height + 2 * padding) / stride)) % ((height + 2 * padding) / stride);
    int ox = threadIdx.x;

    int ix = oy * stride - padding + ox * dilation;
    int iy = oy * stride - padding;

    if (ix >= 0 && ix < width && iy >= 0 && iy < height) {
        float sum = 0.0f;
        for (int ic = 0; ic < in_channels; ic++) {
            for (int ky = 0; ky < kernel_size; ky++) {
                for (int kx = 0; kx < kernel_size; kx++) {
                    int wi = oc * in_channels * kernel_size * kernel_size + ic * kernel_size * kernel_size + ky * kernel_size + kx;
                    int ii = b * in_channels * height * width + ic * height * width + iy * width + ix;
                    sum += weight[wi] * input[ii];
                }
            }
        }
        int oo = b * out_channels * (height + 2 * padding) / stride * (width + 2 * padding) / stride + oc * (height + 2 * padding) / stride * (width + 2 * padding) / stride + oy * (width + 2 * padding) / stride + ox;
        output[oo] = sum;
    }
}

torch::Tensor conv2d_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size, int stride, int padding, int dilation, int groups) {
    auto output = torch::zeros({batch_size, out_channels, (height + 2 * padding) / stride, (width + 2 * padding) / stride}, input.options());
    int num_threads = (width + 2 * padding) / stride;
    int num_blocks = batch_size * out_channels * (height + 2 * padding) / stride;
    conv2d_kernel<<<num_blocks, num_threads>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, out_channels, height, width, kernel_size, stride, padding, dilation, groups);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv2d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, groups: int = 1, bias: bool = False):
        super().__init__()
        self.conv2d = nn.Conv2d(in_channels, out_channels, (kernel_size, kernel_size), stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv2d.weight.contiguous()
        bias = self.conv2d.bias.contiguous() if self.conv2d.bias is not None else None
        batch_size, in_channels, height, width = x.size()
        out_channels = self.conv2d.out_channels
        kernel_size = self.conv2d.kernel_size[0]
        stride = self.conv2d.stride[0]
        padding = self.conv2d.padding[0]
        dilation = self.conv2d.dilation[0]
        groups = self.conv2d.groups
        
        output = _get_mod().conv2d_cuda(x, weight, batch_size, in_channels, out_channels, height, width, kernel_size, stride, padding, dilation, groups)
        
        if bias is not None:
            output += bias.view(1, -1, 1, 1)
        
        return output
