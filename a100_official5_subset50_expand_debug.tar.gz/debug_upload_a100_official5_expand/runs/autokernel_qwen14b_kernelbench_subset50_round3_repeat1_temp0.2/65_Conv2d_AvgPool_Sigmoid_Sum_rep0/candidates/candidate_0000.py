import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void conv_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size, int stride, int padding) {
    int b = blockIdx.x / (out_channels * (height + 2 * padding - kernel_size + 1) * (width + 2 * padding - kernel_size + 1));
    int oc = (blockIdx.x / ((height + 2 * padding - kernel_size + 1) * (width + 2 * padding - kernel_size + 1))) % out_channels;
    int h = ((blockIdx.x / (width + 2 * padding - kernel_size + 1)) % (height + 2 * padding - kernel_size + 1)) - padding;
    int w = (blockIdx.x % (width + 2 * padding - kernel_size + 1)) - padding;

    if (b < batch_size && oc < out_channels && h >= 0 && h < height && w >= 0 && w < width) {
        float sum = 0.0f;
        for (int ic = 0; ic < in_channels; ++ic) {
            for (int kh = 0; kh < kernel_size; ++kh) {
                for (int kw = 0; kw < kernel_size; ++kw) {
                    int ih = h + kh;
                    int iw = w + kw;
                    if (ih >= 0 && ih < height && iw >= 0 && iw < width) {
                        sum += input[b * in_channels * height * width + ic * height * width + ih * width + iw] * weight[oc * in_channels * kernel_size * kernel_size + ic * kernel_size * kernel_size + kh * kernel_size + kw];
                    }
                }
            }
        }
        output[b * out_channels * height * width + oc * height * width + h * width + w] = sum;
    }
}

__global__ void avg_pool_kernel(const float* input, float* output, int batch_size, int out_channels, int height, int width, int pool_kernel_size, int stride) {
    int b = blockIdx.x / (out_channels * (height / pool_kernel_size) * (width / pool_kernel_size));
    int oc = (blockIdx.x / ((height / pool_kernel_size) * (width / pool_kernel_size))) % out_channels;
    int oh = (blockIdx.x / (width / pool_kernel_size)) % (height / pool_kernel_size);
    int ow = blockIdx.x % (width / pool_kernel_size);

    if (b < batch_size && oc < out_channels && oh < height / pool_kernel_size && ow < width / pool_kernel_size) {
        float sum = 0.0f;
        for (int kh = 0; kh < pool_kernel_size; ++kh) {
            for (int kw = 0; kw < pool_kernel_size; ++kw) {
                sum += input[b * out_channels * height * width + oc * height * width + (oh * pool_kernel_size + kh) * width + ow * pool_kernel_size + kw];
            }
        }
        output[b * out_channels * (height / pool_kernel_size) * (width / pool_kernel_size) + oc * (height / pool_kernel_size) * (width / pool_kernel_size) + oh * (width / pool_kernel_size) + ow] = sum / (pool_kernel_size * pool_kernel_size);
    }
}

__global__ void sigmoid_kernel(const float* input, float* output, int size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < size) {
        output[idx] = 1.0f / (1.0f + expf(-input[idx]));
    }
}

__global__ void sum_kernel(const float* input, float* output, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x / (out_channels * height * width);
    int oc = (blockIdx.x / (height * width)) % out_channels;
    int h = (blockIdx.x / width) % height;
    int w = blockIdx.x % width;

    if (b < batch_size && oc < out_channels && h < height && w < width) {
        atomicAdd(&output[b * out_channels + oc], input[b * out_channels * height * width + oc * height * width + h * width + w]);
    }
}

torch::Tensor conv_avg_pool_sigmoid_sum_cuda(torch::Tensor input, torch::Tensor weight, int out_channels, int kernel_size, int pool_kernel_size) {
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int height = input.size(2);
    int width = input.size(3);

    auto conv_output = torch::empty({batch_size, out_channels, height, width}, input.options());
    conv_kernel<<<(batch_size * out_channels * (height + 2 * (kernel_size / 2) - kernel_size + 1) * (width + 2 * (kernel_size / 2) - kernel_size + 1) + 255) / 256, 256>>>(input.data_ptr<float>(), weight.data_ptr<float>(), conv_output.data_ptr<float>(), batch_size, in_channels, out_channels, height, width, kernel_size, 1, kernel_size / 2);

    int pooled_height = (height + 2 * (pool_kernel_size / 2) - pool_kernel_size) / pool_kernel_size + 1;
    int pooled_width = (width + 2 * (pool_kernel_size / 2) - pool_kernel_size) / pool_kernel_size + 1;
    auto pool_output = torch::empty({batch_size, out_channels, pooled_height, pooled_width}, input.options());
    avg_pool_kernel<<<(batch_size * out_channels * pooled_height * pooled_width + 255) / 256, 256>>>(conv_output.data_ptr<float>(), pool_output.data_ptr<float>(), batch_size, out_channels, height, width, pool_kernel_size, pool_kernel_size);

    auto sigmoid_output = torch::empty_like(pool_output);
    sigmoid_kernel<<<(batch_size * out_channels * pooled_height * pooled_width + 255) / 256, 256>>>(pool_output.data_ptr<float>(), sigmoid_output.data_ptr<float>(), batch_size * out_channels * pooled_height * pooled_width);

    auto sum_output = torch::zeros({batch_size, out_channels}, input.options());
    sum_kernel<<<(batch_size * out_channels * pooled_height * pooled_width + 255) / 256, 256>>>(sigmoid_output.data_ptr<float>(), sum_output.data_ptr<float>(), batch_size, out_channels, pooled_height, pooled_width);

    return sum_output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_avg_pool_sigmoid_sum_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, pool_kernel_size):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size)
        self.avg_pool = nn.AvgPool2d(pool_kernel_size)

    def forward(self, x):
        weight = self.conv.weight.view(out_channels, in_channels, kernel_size, kernel_size)
        return _get_mod().conv_avg_pool_sigmoid_sum_cuda(x, weight, out_channels, kernel_size, pool_kernel_size)
