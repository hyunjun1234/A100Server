import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

extern "C" __global__ void conv_transpose2d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int height, int width, int kernel_h, int kernel_w,
    int stride, int padding, int output_padding, int groups) {
    
    int b = blockIdx.x / (out_channels * (height + 2 * padding + output_padding));
    int c_out = (blockIdx.x / (height + 2 * padding + output_padding)) % out_channels;
    int h_out = (blockIdx.x % (height + 2 * padding + output_padding)) - padding;
    int w_out = threadIdx.x;

    if (h_out < 0 || h_out >= height || w_out < 0 || w_out >= width) return;

    float sum = 0.0f;
    for (int c_in = 0; c_in < in_channels; ++c_in) {
        for (int kh = 0; kh < kernel_h; ++kh) {
            for (int kw = 0; kw < kernel_w; ++kw) {
                int h_in = h_out * stride - output_padding + kh;
                int w_in = w_out * stride - output_padding + kw;
                if (h_in >= 0 && h_in < height && w_in >= 0 && w_in < width) {
                    int input_idx = b * in_channels * height * width + c_in * height * width + h_in * width + w_in;
                    int weight_idx = c_out * in_channels * kernel_h * kernel_w + c_in * kernel_h * kernel_w + kh * kernel_w + kw;
                    sum += input[input_idx] * weight[weight_idx];
                }
            }
        }
    }

    int output_idx = b * out_channels * (height + 2 * padding + output_padding) * width + c_out * (height + 2 * padding + output_padding) * width + h_out * width + w_out;
    output[output_idx] = sum + (bias ? bias[c_out] : 0.0f);
}

torch::Tensor conv_transpose2d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int height, int width, int kernel_h, int kernel_w,
    int stride, int padding, int output_padding, int groups) {
    
    auto output = torch::zeros({batch_size, out_channels, height + 2 * padding + output_padding, width}, input.options());
    int threads = width;
    int blocks = batch_size * out_channels * (height + 2 * padding + output_padding);

    conv_transpose2d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        height, width, kernel_h, kernel_w,
        stride, padding, output_padding, groups);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose2d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: int = 1, padding: int = 0, output_padding: int = 0, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv_transpose2d = nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, groups=groups, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv_transpose2d.weight
        bias = self.conv_transpose2d.bias if self.conv_transpose2d.bias is not None else torch.zeros(weight.size(0), device=x.device)
        batch_size, in_channels, height, width = x.size()
        kernel_h, kernel_w = self.conv_transpose2d.kernel_size
        stride = self.conv_transpose2d.stride[0]
        padding = self.conv_transpose2d.padding[0]
        output_padding = self.conv_transpose2d.output_padding[0]
        groups = self.conv_transpose2d.groups

        return _get_mod().conv_transpose2d_cuda(
            x, weight, bias,
            batch_size, in_channels, out_channels,
            height, width, kernel_h, kernel_w,
            stride, padding, output_padding, groups)
