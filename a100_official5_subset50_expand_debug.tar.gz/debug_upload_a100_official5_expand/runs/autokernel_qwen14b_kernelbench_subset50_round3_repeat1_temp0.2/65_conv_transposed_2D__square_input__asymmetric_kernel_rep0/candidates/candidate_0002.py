import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose2d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int height, int width, int kernel_h, int kernel_w,
    int stride, int padding, int output_padding, int groups) {
    
    int b = blockIdx.z;
    int oc = blockIdx.y;
    int ic = blockIdx.x * groups + threadIdx.x;
    int oh = blockIdx.y * stride - padding + output_padding;
    int ow = blockIdx.x * stride - padding + output_padding;

    if (oc >= out_channels || ic >= in_channels || oh < 0 || oh >= height || ow < 0 || ow >= width) {
        return;
    }

    float sum = 0.0f;
    for (int kh = 0; kh < kernel_h; ++kh) {
        for (int kw = 0; kw < kernel_w; ++kw) {
            int ih = oh - kh * stride;
            int iw = ow - kw * stride;
            if (ih >= 0 && ih < height && iw >= 0 && iw < width) {
                int input_idx = b * in_channels * height * width + ic * height * width + ih * width + iw;
                int weight_idx = oc * in_channels * kernel_h * kernel_w + ic * kernel_h * kernel_w + kh * kernel_w + kw;
                sum += input[input_idx] * weight[weight_idx];
            }
        }
    }

    int output_idx = b * out_channels * height * width + oc * height * width + oh * width + ow;
    output[output_idx] = sum + bias[oc];
}

torch::Tensor conv_transpose2d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int height, int width, int kernel_h, int kernel_w,
    int stride, int padding, int output_padding, int groups) {
    
    auto output = torch::zeros({batch_size, out_channels, height, width}, input.options());
    dim3 threads(32, 1, 1);
    dim3 blocks((width + stride - 1) / stride, (height + stride - 1) / stride, batch_size * out_channels);

    conv_transpose2d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        height, width, kernel_h, kernel_w,
        stride, padding, output_padding, groups);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose2d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: int = 1, padding: int = 0, output_padding: int = 0, groups: int = 1, bias: bool = False):
        super().__init__()
        self.conv_transpose2d = nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, groups=groups, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv_transpose2d.weight
        bias = self.conv_transpose2d.bias
        batch_size, in_channels, height, width = x.size()
        out_channels, _, kernel_h, kernel_w = weight.size()
        stride = self.conv_transpose2d.stride[0]
        padding = self.conv_transpose2d.padding[0]
        output_padding = self.conv_transpose2d.output_padding[0]
        groups = self.conv_transpose2d.groups

        return _get_mod().conv_transpose2d_cuda(
            x, weight, bias,
            batch_size, in_channels, out_channels,
            height, width, kernel_h, kernel_w,
            stride, padding, output_padding, groups)
