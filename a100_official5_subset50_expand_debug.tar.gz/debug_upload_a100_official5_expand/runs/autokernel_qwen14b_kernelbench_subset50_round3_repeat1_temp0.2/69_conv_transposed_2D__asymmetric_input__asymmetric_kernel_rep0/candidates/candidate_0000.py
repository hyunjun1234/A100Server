import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

extern "C" __global__ void conv_transpose2d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int height_in, int width_in, int height_out, int width_out,
    int kernel_height, int kernel_width, int stride_height, int stride_width,
    int padding_height, int padding_width, int output_padding_height, int output_padding_width,
    int dilation_height, int dilation_width, int groups) {
    
    int b = blockIdx.x / (out_channels * height_out * width_out);
    int oc = (blockIdx.x / (height_out * width_out)) % out_channels;
    int oh = (blockIdx.x / width_out) % height_out;
    int ow = blockIdx.x % width_out;

    int ic = threadIdx.x;
    int kh = blockIdx.y / kernel_width;
    int kw = blockIdx.y % kernel_width;

    if (b < batch_size && oc < out_channels && oh < height_out && ow < width_out && ic < in_channels) {
        int ih = oh * stride_height - padding_height + kh * dilation_height;
        int iw = ow * stride_width - padding_width + kw * dilation_width;

        if (ih >= 0 && ih < height_in && iw >= 0 && iw < width_in) {
            atomicAdd(&output[b * out_channels * height_out * width_out + oc * height_out * width_out + oh * width_out + ow],
                      input[b * in_channels * height_in * width_in + ic * height_in * width_in + ih * width_in + iw] *
                      weight[oc * in_channels * kernel_height * kernel_width + ic * kernel_height * kernel_width + kh * kernel_width + kw]);
        }
    }

    if (threadIdx.x == 0 && blockIdx.y == 0) {
        if (bias != nullptr) {
            atomicAdd(&output[b * out_channels * height_out * width_out + oc * height_out * width_out + oh * width_out + ow], bias[oc]);
        }
    }
}

torch::Tensor conv_transpose2d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int height_in, int width_in, int height_out, int width_out,
    int kernel_height, int kernel_width, int stride_height, int stride_width,
    int padding_height, int padding_width, int output_padding_height, int output_padding_width,
    int dilation_height, int dilation_width, int groups) {
    
    auto output = torch::zeros({batch_size, out_channels, height_out, width_out}, input.options());
    dim3 threads(1, 1);
    dim3 blocks(batch_size * out_channels * height_out * width_out, kernel_height * kernel_width);

    conv_transpose2d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        height_in, width_in, height_out, width_out,
        kernel_height, kernel_width, stride_height, stride_width,
        padding_height, padding_width, output_padding_height, output_padding_width,
        dilation_height, dilation_width, groups);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose2d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1), padding: tuple = (0, 0), output_padding: tuple = (0, 0), dilation: tuple = (1, 1), groups: int = 1, bias: bool = False):
        super().__init__()
        self.conv_transpose2d = nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, dilation=dilation, groups=groups, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv_transpose2d.weight
        bias = self.conv_transpose2d.bias if self.conv_transpose2d.bias is not None else torch.zeros(self.conv_transpose2d.out_channels, device=x.device)
        
        batch_size, in_channels, height_in, width_in = x.shape
        out_channels, _, kernel_height, kernel_width = weight.shape
        stride_height, stride_width = self.conv_transpose2d.stride
        padding_height, padding_width = self.conv_transpose2d.padding
        output_padding_height, output_padding_width = self.conv_transpose2d.output_padding
        dilation_height, dilation_width = self.conv_transpose2d.dilation
        groups = self.conv_transpose2d.groups
        
        height_out = (height_in - 1) * stride_height - 2 * padding_height + dilation_height * (kernel_height - 1) + output_padding_height + 1
        width_out = (width_in - 1) * stride_width - 2 * padding_width + dilation_width * (kernel_width - 1) + output_padding_width + 1
        
        return _get_mod().conv_transpose2d_cuda(
            x, weight, bias,
            batch_size, in_channels, out_channels,
            height_in, width_in, height_out, width_out,
            kernel_height, kernel_width, stride_height, stride_width,
            padding_height, padding_width, output_padding_height, output_padding_width,
            dilation_height, dilation_width, groups)
