import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose2d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int height_in, int width_in, int height_out, int width_out,
    int kernel_h, int kernel_w, int stride_h, int stride_w,
    int padding_h, int padding_w, int output_padding_h, int output_padding_w,
    int dilation_h, int dilation_w, int groups) {
    
    int b = blockIdx.x / (out_channels * height_out * width_out);
    int oc = (blockIdx.x / (height_out * width_out)) % out_channels;
    int oh = (blockIdx.x / width_out) % height_out;
    int ow = blockIdx.x % width_out;

    int ic = threadIdx.x;
    int kh = threadIdx.y;
    int kw = threadIdx.z;

    if (b >= batch_size || oc >= out_channels || ic >= in_channels || kh >= kernel_h || kw >= kernel_w) {
        return;
    }

    float sum = 0.0f;
    int ih = oh * stride_h - padding_h + kh * dilation_h;
    int iw = ow * stride_w - padding_w + kw * dilation_w;

    if (ih >= 0 && ih < height_in && iw >= 0 && iw < width_in) {
        int input_idx = b * in_channels * height_in * width_in + ic * height_in * width_in + ih * width_in + iw;
        int weight_idx = oc * in_channels * kernel_h * kernel_w + ic * kernel_h * kernel_w + kh * kernel_w + kw;
        sum += input[input_idx] * weight[weight_idx];
    }

    __syncthreads();

    if (threadIdx.x == 0 && threadIdx.y == 0 && threadIdx.z == 0) {
        int output_idx = b * out_channels * height_out * width_out + oc * height_out * width_out + oh * width_out + ow;
        output[output_idx] = sum;
        if (bias != nullptr) {
            output[output_idx] += bias[oc];
        }
    }
}

torch::Tensor conv_transpose2d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int height_in, int width_in, int height_out, int width_out,
    int kernel_h, int kernel_w, int stride_h, int stride_w,
    int padding_h, int padding_w, int output_padding_h, int output_padding_w,
    int dilation_h, int dilation_w, int groups) {
    
    auto output = torch::zeros({batch_size, out_channels, height_out, width_out}, input.options());
    int threads_per_block = 256;
    dim3 blocks((batch_size * out_channels * height_out * width_out + threads_per_block - 1) / threads_per_block);
    dim3 threads(16, 16, 16);

    conv_transpose2d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        height_in, width_in, height_out, width_out,
        kernel_h, kernel_w, stride_h, stride_w,
        padding_h, padding_w, output_padding_h, output_padding_w,
        dilation_h, dilation_w, groups);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose2d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1), padding: tuple = (0, 0), output_padding: tuple = (0, 0), dilation: tuple = (1, 1), groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv_transpose2d = nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, dilation=dilation, groups=groups, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv_transpose2d.weight
        bias = self.conv_transpose2d.bias if self.conv_transpose2d.bias is not None else torch.zeros(self.conv_transpose2d.out_channels, device=x.device)
        
        batch_size, in_channels, height_in, width_in = x.size()
        out_channels = self.conv_transpose2d.out_channels
        kernel_h, kernel_w = self.conv_transpose2d.kernel_size
        stride_h, stride_w = self.conv_transpose2d.stride
        padding_h, padding_w = self.conv_transpose2d.padding
        output_padding_h, output_padding_w = self.conv_transpose2d.output_padding
        dilation_h, dilation_w = self.conv_transpose2d.dilation
        groups = self.conv_transpose2d.groups
        
        height_out = (height_in - 1) * stride_h - 2 * padding_h + dilation_h * (kernel_h - 1) + output_padding_h + 1
        width_out = (width_in - 1) * stride_w - 2 * padding_w + dilation_w * (kernel_w - 1) + output_padding_w + 1
        
        return _get_mod().conv_transpose2d_cuda(
            x, weight, bias,
            batch_size, in_channels, out_channels,
            height_in, width_in, height_out, width_out,
            kernel_h, kernel_w, stride_h, stride_w,
            padding_h, padding_w, output_padding_h, output_padding_w,
            dilation_h, dilation_w, groups)
