import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void conv_transpose_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int depth, int height, int width, int kernel_size, int stride, int padding) {
    // Implement the 3D transposed convolution kernel here
}

__global__ void batch_norm_kernel(const float* input, float* output, const float* weight, const float* bias, const float* running_mean, const float* running_var, float eps, int batch_size, int out_channels, int depth, int height, int width) {
    // Implement the batch normalization kernel here
}

__global__ void avg_pool_kernel(const float* input, float* output, int batch_size, int out_channels, int depth, int height, int width, int pool_size) {
    // Implement the average pooling kernel here
}

torch::Tensor conv_transpose_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int depth, int height, int width, int kernel_size, int stride, int padding) {
    auto output = torch::empty({batch_size, out_channels, depth * stride, height * stride, width * stride}, input.options());
    conv_transpose_kernel<<<(batch_size * out_channels * depth * height * width + 255) / 256, 256>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, out_channels, depth, height, width, kernel_size, stride, padding);
    return output;
}

torch::Tensor batch_norm_cuda(torch::Tensor input, torch::Tensor weight, torch::Tensor bias, torch::Tensor running_mean, torch::Tensor running_var, float eps, int batch_size, int out_channels, int depth, int height, int width) {
    auto output = torch::empty_like(input);
    batch_norm_kernel<<<(batch_size * out_channels * depth * height * width + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), weight.data_ptr<float>(), bias.data_ptr<float>(), running_mean.data_ptr<float>(), running_var.data_ptr<float>(), eps, batch_size, out_channels, depth, height, width);
    return output;
}

torch::Tensor avg_pool_cuda(torch::Tensor input, int batch_size, int out_channels, int depth, int height, int width, int pool_size) {
    auto output = torch::empty({batch_size, out_channels, depth / pool_size, height / pool_size, width / pool_size}, input.options());
    avg_pool_kernel<<<(batch_size * out_channels * depth * height * width + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_channels, depth, height, width, pool_size);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose_cuda", "batch_norm_cuda", "avg_pool_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, bias_shape):
        super().__init__()
        self.conv_transpose = nn.ConvTranspose3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding)
        self.batch_norm = nn.BatchNorm3d(out_channels)
        self.avg_pool1 = nn.AvgPool3d(kernel_size=2)
        self.avg_pool2 = nn.AvgPool3d(kernel_size=2)

    def forward(self, x):
        mod = _get_mod()
        x = mod.conv_transpose_cuda(x, self.conv_transpose.weight, x.size(0), self.conv_transpose.in_channels, self.conv_transpose.out_channels, x.size(2), x.size(3), x.size(4), self.conv_transpose.kernel_size[0], self.conv_transpose.stride[0], self.conv_transpose.padding[0])
        x = mod.batch_norm_cuda(x, self.batch_norm.weight, self.batch_norm.bias, self.batch_norm.running_mean, self.batch_norm.running_var, self.batch_norm.eps, x.size(0), self.batch_norm.num_features, x.size(2), x.size(3), x.size(4))
        x = mod.avg_pool_cuda(x, x.size(0), x.size(1), x.size(2), x.size(3), x.size(4), 2)
        x = mod.avg_pool_cuda(x, x.size(0), x.size(1), x.size(2), x.size(3), x.size(4), 2)
        return x
