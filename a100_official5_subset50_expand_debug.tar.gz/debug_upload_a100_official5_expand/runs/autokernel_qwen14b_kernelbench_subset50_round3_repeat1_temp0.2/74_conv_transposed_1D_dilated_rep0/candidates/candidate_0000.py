import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose1d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int padding, int dilation) {
    
    int b = blockIdx.z;
    int oc = blockIdx.y;
    int ox = blockIdx.x * blockDim.x + threadIdx.x;

    if (ox >= length) return;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int k = 0; k < kernel_size; ++k) {
            int ix = ox - k * dilation;
            if (ix >= 0 && ix < length) {
                sum += input[b * in_channels * length + ic * length + ix] *
                       weight[oc * in_channels * kernel_size + ic * kernel_size + k];
            }
        }
    }

    output[b * out_channels * length + oc * length + ox] = sum + bias[oc];
}

torch::Tensor conv_transpose1d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int kernel_size, int stride, int padding, int dilation) {
    
    auto output = torch::empty_like(input);
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int out_channels = weight.size(0);
    int length = input.size(2);

    dim3 threads(256);
    dim3 blocks((length + threads.x - 1) / threads.x, out_channels, batch_size);

    conv_transpose1d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels, length,
        kernel_size, stride, padding, dilation);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose1d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, bias: bool = False):
        super().__init__()
        self.conv1d_transpose = nn.ConvTranspose1d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, dilation=dilation, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.conv1d_transpose.bias is None:
            bias = torch.zeros(self.conv1d_transpose.out_channels, device=x.device)
        else:
            bias = self.conv1d_transpose.bias
        
        return _get_mod().conv_transpose1d_cuda(
            x, self.conv1d_transpose.weight, bias,
            self.conv1d_transpose.kernel_size[0],
            self.conv1d_transpose.stride[0],
            self.conv1d_transpose.padding[0],
            self.conv1d_transpose.dilation[0]
        )
