import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose1d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int padding, int dilation) {
    
    int b = blockIdx.x / (out_channels * (length + 2 * padding));
    int oc = (blockIdx.x % (out_channels * (length + 2 * padding))) / (length + 2 * padding);
    int ox = blockIdx.x % (length + 2 * padding);

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int k = 0; k < kernel_size; ++k) {
            int ix = ox - padding + k * dilation;
            if (ix >= 0 && ix < length) {
                sum += input[b * in_channels * length + ic * length + ix] *
                       weight[oc * in_channels * kernel_size + ic * kernel_size + k];
            }
        }
    }

    output[b * out_channels * (length + 2 * padding) + oc * (length + 2 * padding) + ox] = sum + (bias ? bias[oc] : 0.0f);
}

torch::Tensor conv_transpose1d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int in_channels, int out_channels, int length,
    int kernel_size, int stride, int padding, int dilation) {
    
    auto output = torch::empty({input.size(0), out_channels, length + 2 * padding}, input.options());
    int num_threads = 256;
    int num_blocks = (input.size(0) * out_channels * (length + 2 * padding) + num_threads - 1) / num_threads;
    conv_transpose1d_kernel<<<num_blocks, num_threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        input.size(0), in_channels, out_channels, length,
        kernel_size, stride, padding, dilation);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose1d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, bias: bool = False):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size))
        self.bias = nn.Parameter(torch.randn(out_channels)) if bias else None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.bias is not None:
            return _get_mod().conv_transpose1d_cuda(x, self.weight, self.bias, self.in_channels, self.out_channels, x.size(2), self.kernel_size, self.stride, self.padding, self.dilation)
        else:
            return _get_mod().conv_transpose1d_cuda(x, self.weight, torch.zeros(self.out_channels), self.in_channels, self.out_channels, x.size(2), self.kernel_size, self.stride, self.padding, self.dilation)
