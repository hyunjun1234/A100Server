import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv1d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int dilation) {
    
    int b = blockIdx.x / (out_channels * ((length - kernel_size * dilation) / stride + 1));
    int oc = (blockIdx.x % (out_channels * ((length - kernel_size * dilation) / stride + 1))) / ((length - kernel_size * dilation) / stride + 1);
    int ow = blockIdx.x % ((length - kernel_size * dilation) / stride + 1);

    int iw_start = ow * stride;
    int iw_end = iw_start + kernel_size * dilation;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int k = 0; k < kernel_size; ++k) {
            int iw = iw_start + k * dilation;
            if (iw >= 0 && iw < length) {
                sum += input[b * in_channels * length + ic * length + iw] * weight[oc * in_channels * kernel_size + ic * kernel_size + k];
            }
        }
    }

    output[b * out_channels * ((length - kernel_size * dilation) / stride + 1) + oc * ((length - kernel_size * dilation) / stride + 1) + ow] = sum + bias[oc];
}

torch::Tensor conv1d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int dilation) {
    
    auto output = torch::empty({batch_size, out_channels, (length - kernel_size * dilation) / stride + 1}, input.options());
    int num_blocks = batch_size * out_channels * ((length - kernel_size * dilation) / stride + 1);
    int threads_per_block = 256;
    conv1d_kernel<<<(num_blocks + threads_per_block - 1) / threads_per_block, threads_per_block>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels, length,
        kernel_size, stride, dilation);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv1d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, dilation: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv1d = nn.Conv1d(in_channels, out_channels, kernel_size, stride=stride, dilation=dilation, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _get_mod().conv1d_cuda(
            x, self.conv1d.weight, self.conv1d.bias,
            x.size(0), x.size(1), self.conv1d.out_channels, x.size(2),
            self.conv1d.kernel_size[0], self.conv1d.stride[0], self.conv1d.dilation[0]
        )
