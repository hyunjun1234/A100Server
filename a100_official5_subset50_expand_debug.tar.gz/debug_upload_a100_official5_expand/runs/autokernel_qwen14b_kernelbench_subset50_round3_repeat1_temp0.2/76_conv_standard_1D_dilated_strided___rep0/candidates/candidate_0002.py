import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

extern "C" __global__ void conv1d_cuda(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int length, int kernel_size, int stride, int dilation) {
    
    int b = blockIdx.x / (out_channels * ((length - kernel_size) / stride + 1));
    int oc = (blockIdx.x % (out_channels * ((length - kernel_size) / stride + 1))) / ((length - kernel_size) / stride + 1);
    int ow = blockIdx.x % ((length - kernel_size) / stride + 1);

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kw = 0; kw < kernel_size; ++kw) {
            int iw = ow * stride + kw * dilation;
            if (iw >= 0 && iw < length) {
                sum += input[b * in_channels * length + ic * length + iw] *
                       weight[oc * in_channels * kernel_size + ic * kernel_size + kw];
            }
        }
    }

    if (bias != nullptr) {
        sum += bias[oc];
    }

    output[b * out_channels * ((length - kernel_size) / stride + 1) + oc * ((length - kernel_size) / stride + 1) + ow] = sum;
}

torch::Tensor conv1d_cuda_wrapper(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int length, int kernel_size, int stride, int dilation) {
    
    auto output = torch::zeros({batch_size, out_channels, (length - kernel_size) / stride + 1}, input.options());
    int num_threads = 256;
    int num_blocks = (batch_size * out_channels * ((length - kernel_size) / stride + 1) + num_threads - 1) / num_threads;

    conv1d_cuda<<<num_blocks, num_threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.defined() ? bias.data_ptr<float>() : nullptr,
        batch_size, in_channels, out_channels, length, kernel_size, stride, dilation);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv1d_cuda_wrapper")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, dilation: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv1d = nn.Conv1d(in_channels, out_channels, kernel_size, stride=stride, dilation=dilation, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv1d.weight
        bias = self.conv1d.bias if self.conv1d.bias is not None else torch.zeros(out_channels, device=x.device)
        batch_size, in_channels, length = x.size()
        kernel_size = self.conv1d.kernel_size[0]
        stride = self.conv1d.stride[0]
        dilation = self.conv1d.dilation[0]
        return _get_mod()(x, weight, bias, batch_size, in_channels, self.conv1d.out_channels, length, kernel_size, stride, dilation)
