import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void max_kernel(const float* input, float* output, int N, int max_dim) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        int row = idx / max_dim;
        int col = idx % max_dim;
        float max_val = -FLT_MAX;
        for (int i = 0; i < max_dim; ++i) {
            max_val = fmaxf(max_val, input[row * max_dim + i]);
        }
        output[idx] = max_val;
    }
}

__global__ void mean_subtract_kernel(const float* input, float* output, int N, int max_dim) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        int row = idx / max_dim;
        int col = idx % max_dim;
        float sum = 0.0f;
        for (int i = 0; i < max_dim; ++i) {
            sum += input[row * max_dim + i];
        }
        float mean = sum / max_dim;
        output[idx] = input[idx] - mean;
    }
}

__global__ void gelu_kernel(const float* input, float* output, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        float x = input[idx];
        float cdf = 0.5f * (1.0f + tanhf(0.7978845608028654f * (x + 0.044715f * x * x * x)));
        output[idx] = x * cdf;
    }
}

torch::Tensor gemm_cuda(torch::Tensor input, torch::Tensor weight, torch::Tensor bias) {
    auto output = torch::empty_like(input);
    cublasHandle_t handle;
    cublasCreate(&handle);
    float alpha = 1.0f;
    float beta = 0.0f;
    cublasSgemm(handle, CUBLAS_OP_N, CUBLAS_OP_N, weight.size(0), input.size(0), input.size(1),
                &alpha, weight.data_ptr<float>(), weight.size(1),
                input.data_ptr<float>(), input.size(1),
                &beta, output.data_ptr<float>(), weight.size(0));
    cublasDestroy(handle);
    return output.add_(bias.view(-1, 1).expand_as(output));
}

torch::Tensor max_cuda(torch::Tensor input, int max_dim) {
    auto output = torch::empty_like(input);
    int N = input.numel();
    max_kernel<<<(N+255)/256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), N, max_dim);
    return output;
}

torch::Tensor mean_subtract_cuda(torch::Tensor input, int max_dim) {
    auto output = torch::empty_like(input);
    int N = input.numel();
    mean_subtract_kernel<<<(N+255)/256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), N, max_dim);
    return output;
}

torch::Tensor gelu_cuda(torch::Tensor input) {
    auto output = torch::empty_like(input);
    int N = input.numel();
    gelu_kernel<<<(N+255)/256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), N);
    return output;
}

std::vector<torch::Tensor> model_new_forward(torch::Tensor input, torch::Tensor weight, torch::Tensor bias, int max_dim) {
    input = gemm_cuda(input, weight, bias);
    input = max_cuda(input, max_dim);
    input = mean_subtract_cuda(input, max_dim);
    input = gelu_cuda(input);
    return {input};
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "model_new_forward")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, max_dim):
        super(ModelNew, self).__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.max_dim = max_dim

    def forward(self, x):
        return _get_mod()(x, self.gemm.weight, self.gemm.bias, self.max_dim)[0]
