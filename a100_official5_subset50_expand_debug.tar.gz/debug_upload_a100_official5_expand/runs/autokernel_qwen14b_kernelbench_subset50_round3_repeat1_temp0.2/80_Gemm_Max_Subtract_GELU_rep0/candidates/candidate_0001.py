import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void max_kernel(const float* input, float* output, int N, int max_dim, int batch_size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        int batch_idx = idx / max_dim;
        int col_idx = idx % max_dim;
        float max_val = -FLT_MAX;
        for (int i = 0; i < batch_size; ++i) {
            max_val = fmaxf(max_val, input[i * max_dim + col_idx]);
        }
        output[col_idx] = max_val;
    }
}

__global__ void subtract_mean_kernel(const float* input, float* output, const float* mean, int N, int batch_size) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        int batch_idx = idx / N;
        int col_idx = idx % N;
        output[batch_idx * N + col_idx] = input[batch_idx * N + col_idx] - mean[col_idx];
    }
}

__global__ void gelu_kernel(float* input, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        float x = input[idx];
        float cdf = 0.5f * (1.0f + tanhf(sqrtf(2.0f / M_PI) * (x + 0.044715f * powf(x, 3.0f))));
        input[idx] = x * cdf;
    }
}

torch::Tensor gemm_cuda(torch::Tensor input, torch::Tensor weight, torch::Tensor bias) {
    auto output = torch::empty_like(input);
    cublasHandle_t handle;
    cublasCreate(&handle);
    float alpha = 1.0f, beta = 0.0f;
    cublasSgemm(handle, CUBLAS_OP_N, CUBLAS_OP_N, weight.size(0), input.size(0), input.size(1),
                 &alpha, weight.data_ptr<float>(), weight.size(1),
                 input.data_ptr<float>(), input.size(1),
                 &beta, output.data_ptr<float>(), weight.size(0));
    cublasDestroy(handle);
    output.add_(bias.view(1, -1).expand_as(output));
    return output;
}

torch::Tensor max_cuda(torch::Tensor input, int max_dim, int batch_size) {
    auto output = torch::empty({input.size(max_dim)}, input.options());
    max_kernel<<<(input.size(max_dim) + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), input.size(max_dim), max_dim, batch_size);
    return output;
}

torch::Tensor subtract_mean_cuda(torch::Tensor input, torch::Tensor mean, int batch_size) {
    auto output = torch::empty_like(input);
    subtract_mean_kernel<<<(input.numel() + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), mean.data_ptr<float>(), input.size(1), batch_size);
    return output;
}

torch::Tensor gelu_cuda(torch::Tensor input) {
    gelu_kernel<<<(input.numel() + 255) / 256, 256>>>(input.data_ptr<float>(), input.numel());
    return input;
}

std::vector<torch::Tensor> model_new_forward(torch::Tensor input, torch::Tensor weight, torch::Tensor bias, int max_dim, int batch_size) {
    auto x = gemm_cuda(input, weight, bias);
    auto max_vals = max_cuda(x, max_dim, batch_size);
    auto mean = max_vals.mean(dim=0, keepdim=true);
    auto sub_mean = subtract_mean_cuda(x, mean, batch_size);
    auto gelu_out = gelu_cuda(sub_mean);
    return {gelu_out};
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "model_new_forward")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, max_dim):
        super(ModelNew, self).__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.max_dim = max_dim

    def forward(self, x):
        weight = self.gemm.weight
        bias = self.gemm.bias
        return _get_mod()(x, weight, bias, self.max_dim, x.size(0))[0]
