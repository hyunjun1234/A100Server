import torch
import torch.nn as nn

class ModelNew(nn.Module):
    def __init__(self, margin=1.0):
        super(ModelNew, self).__init__()
        self.margin = margin

    def forward(self, anchor, positive, negative):
        # Compute pairwise distances
        dist_ap = torch.norm(anchor - positive, dim=-1)
        dist_an = torch.norm(anchor - negative, dim=-1)
        
        # Compute triplet loss
        loss = torch.clamp(dist_ap - dist_an + self.margin, min=0.0)
        return torch.mean(loss)

batch_size = 32768
input_shape = (8192,)
dim = 1

def get_inputs():
    scale = torch.rand(())
    return [torch.rand(batch_size, *input_shape)*scale, torch.rand(batch_size, *input_shape), torch.rand(batch_size, *input_shape)]
    
def get_init_inputs():
    return [1.0]  # Default margin
