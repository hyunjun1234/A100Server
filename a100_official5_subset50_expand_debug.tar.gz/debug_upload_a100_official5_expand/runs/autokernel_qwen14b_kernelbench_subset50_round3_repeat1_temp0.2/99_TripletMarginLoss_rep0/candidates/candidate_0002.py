import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void triplet_margin_loss_kernel(
    const float* anchor, const float* positive, const float* negative,
    float* output, float margin, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        float dist_ap = 0.0f;
        float dist_an = 0.0f;
        for (int d = 0; d < 8192; ++d) {
            float diff_ap = anchor[idx * 8192 + d] - positive[idx * 8192 + d];
            float diff_an = anchor[idx * 8192 + d] - negative[idx * 8192 + d];
            dist_ap += diff_ap * diff_ap;
            dist_an += diff_an * diff_an;
        }
        dist_ap = sqrtf(dist_ap);
        dist_an = sqrtf(dist_an);
        float loss = fmaxf(0.0f, margin + dist_ap - dist_an);
        atomicAdd(output, loss);
    }
}

torch::Tensor triplet_margin_loss_cuda(
    torch::Tensor anchor, torch::Tensor positive, torch::Tensor negative, float margin) {
    int N = anchor.size(0);
    auto output = torch::zeros({1}, anchor.options());
    triplet_margin_loss_kernel<<<(N + 255) / 256, 256>>>(
        anchor.data_ptr<float>(), positive.data_ptr<float>(), negative.data_ptr<float>(),
        output.data_ptr<float>(), margin, N);
    return output / static_cast<float>(N);
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "triplet_margin_loss_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, margin=1.0):
        super().__init__()
        self.margin = margin

    def forward(self, anchor, positive, negative):
        return _get_mod().triplet_margin_loss_cuda(anchor, positive, negative, self.margin)
