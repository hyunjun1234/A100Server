import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_mul_scalar(x_ptrs, out_ptrs, scalar, numel, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < numel
    x = tl.load(x_ptrs + offsets, mask=mask)
    out = x * scalar
    tl.store(out_ptrs + offsets, out, mask=mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, s: float) -> torch.Tensor:
        C = torch.empty_like(A)
        numel = A.numel()
        grid = lambda meta: (triton.cdiv(numel, meta['BLOCK_SIZE']),)
        triton_mul_scalar[grid](A, C, s, numel, BLOCK_SIZE=1024)
        return C
