import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs matrix multiplication with improved memory layout and potential batch processing.
    """
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs matrix multiplication with optimizations.

        Args:
            A: Input tensor of shape (M, K).
            B: Input tensor of shape (N, K).

        Returns:
            Output tensor of shape (M, N).
        """
        # Ensure tensors are contiguous
        A = A.contiguous()
        B = B.contiguous()
        
        # Transpose B to match the expected shape for matrix multiplication
        B = B.t()
        
        # Perform matrix multiplication
        return torch.matmul(A, B)

def get_inputs():
    M = 1024 * 2
    K = 4096 * 2
    N = 2048 * 2
    
    # Generate random tensors
    A = torch.rand(M, K)
    B = torch.rand(N, K)
    
    # Move tensors to GPU if available
    if torch.cuda.is_available():
        A = A.cuda()
        B = B.cuda()
    
    return [A, B]

def get_init_inputs():
    return []  # No special initialization inputs needed

# Example usage
if __name__ == "__main__":
    model = ModelNew()
    A, B = get_inputs()
    output = model(A, B)
    print(output.shape)