import torch
import torch.nn as nn
import torch.jit

class ModelNew(nn.Module):
    """
    Optimized model that performs batched matrix multiplications (C = A * B^T)
    """
    def __init__(self):
        super(ModelNew, self).__init__()
    
    @torch.jit.script
    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs batched matrix multiplication.

        Args:
            A: Input tensor of shape (B, M, K).
            B: Input tensor of shape (B, N, K).

        Returns:
            Output tensor of shape (B, M, N).
        """
        return torch.bmm(A, B.transpose(1, 2))

BATCH_SIZE = 32
M = 1024 * 2
K = 4096 * 2
N = 2048 * 2

def get_inputs():
    A = torch.rand(BATCH_SIZE, M, K)
    B = torch.rand(BATCH_SIZE, N, K)
    return [A, B]

def get_init_inputs():
    return []  # No special initialization inputs needed

# Example usage
if __name__ == "__main__":
    model = ModelNew()
    A, B = get_inputs()
    output = model(A, B)
    print(output.shape)  # Should print: torch.Size([32, 2048, 4096])