import torch
import torch.nn as nn
import torch.nn.init as init

class ModelNew(nn.Module):
    """
    Optimized model that performs a matrix multiplication, scales the result, and applies batch normalization.
    """
    def __init__(self, in_features, out_features, scale_shape, eps=1e-5, momentum=0.1):
        super(ModelNew, self).__init__()
        self.gemm = nn.Linear(in_features, out_features)
        # Initialize weights using Xavier uniform
        init.xavier_uniform_(self.gemm.weight)
        init.constant_(self.gemm.bias, 0)
        
        self.scale = nn.Parameter(torch.full(scale_shape, 1.0))  # Initialize scale with small values
        self.bn = nn.BatchNorm1d(out_features, eps=eps, momentum=momentum)

    def forward(self, x):
        x = self.gemm(x)
        x = x * self.scale
        x = self.bn(x)
        return x

batch_size = 16384
in_features = 4096
out_features = 4096
scale_shape = (out_features,)

def get_inputs():
    return [torch.rand(batch_size, in_features)]

def get_init_inputs():
    return [in_features, out_features, scale_shape]

# Example usage
if __name__ == "__main__":
    inputs = get_inputs()
    model = ModelNew(*get_init_inputs())
    output = model(inputs[0])
    print(output.shape)  # Should print torch.Size([16384, 4096])