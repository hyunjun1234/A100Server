import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs a matrix multiplication, scales the result, and applies batch normalization.
    """
    def __init__(self, in_features, out_features, scale_shape, eps=1e-5, momentum=0.1):
        super(ModelNew, self).__init__()
        self.gemm = nn.Linear(in_features, out_features)
        # Initialize scale parameter with a smaller value to avoid large initial outputs
        self.scale = nn.Parameter(torch.full(scale_shape, 0.1))
        self.bn = nn.BatchNorm1d(out_features, eps=eps, momentum=momentum)

    def forward(self, x):
        x = self.gemm(x)
        x = x * self.scale
        x = self.bn(x)
        return x

batch_size = 16384
in_features = 4096
out_features = 4096
scale_shape = (out_features,)

def get_inputs():
    # Ensure input data is within a reasonable range
    return [torch.rand(batch_size, in_features) * 0.1]

def get_init_inputs():
    return [in_features, out_features, scale_shape]

# Example usage
if __name__ == "__main__":
    # Initialize model and inputs
    model = ModelNew(*get_init_inputs())
    inputs = get_inputs()
    
    # Forward pass
    output = model(inputs[0])
    
    # Print output shape and values for debugging
    print("Output shape:", output.shape)
    print("Output values:\n", output)