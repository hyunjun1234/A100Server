import torch
import torch.nn as nn
import torch.profiler

class ModelNew(nn.Module):
    """
    Performs batched matrix multiplication (C = A * B) where A, B, and C have the same batch dimension.
    Optimized for better memory layout and device utilization.
    """
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs batched matrix multiplication.

        Args:
            A: Input tensor of shape (batch_size, m, k).
            B: Input tensor of shape (batch_size, k, n).

        Returns:
            C: Output tensor of shape (batch_size, m, n).
        """
        # Ensure tensors are contiguous
        A = A.contiguous()
        B = B.contiguous()

        # Perform batched matrix multiplication
        return torch.bmm(A, B)

def get_inputs(device='cpu'):
    batch_size = 128
    m = 128 * 4
    k = 256 * 4
    n = 512 * 4

    A = torch.rand(batch_size, m, k).to(device)
    B = torch.rand(batch_size, k, n).to(device)
    return [A, B]

def get_init_inputs():
    return []  # No special initialization inputs needed

def profile_model():
    model = ModelNew().to('cuda')
    inputs = get_inputs(device='cuda')

    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]) as prof:
        with torch.no_grad():
            model(*inputs)

    print(prof.key_averages().table(sort_by="cuda_time_total", row_limit=10))

if __name__ == "__main__":
    # Example usage
    model = ModelNew().to('cuda')
    inputs = get_inputs(device='cuda')
    output = model(*inputs)
    print(output.shape)

    # Profile the model
    profile_model()