import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

class ModelNew(nn.Module):
    """
    Performs batched matrix multiplication (C = A * B) where A, B, and C have the same batch dimension.
    Optimized for reduced memory overhead and improved data locality.
    """
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs batched matrix multiplication.

        Args:
            A: Input tensor of shape (batch_size, m, k).
            B: Input tensor of shape (batch_size, k, n).

        Returns:
            C: Output tensor of shape (batch_size, m, n).
        """
        return torch.bmm(A, B)

def get_inputs(batch_size=128, m=128 * 4, k=256 * 4, n=512 * 4):
    A = torch.rand(batch_size, m, k).cuda().contiguous()
    B = torch.rand(batch_size, k, n).cuda().contiguous()
    return [A, B]

def train_model(model, optimizer, dataloader, epochs=1):
    model.train()
    for epoch in range(epochs):
        for A, B in dataloader:
            optimizer.zero_grad()
            C = model(A, B)
            loss = C.sum()  # Dummy loss for demonstration
            loss.backward()
            optimizer.step()

def main():
    batch_size = 128
    m = 128 * 4
    k = 256 * 4
    n = 512 * 4

    # Create dummy dataset
    A, B = get_inputs(batch_size, m, k, n)
    dataset = TensorDataset(A, B)
    dataloader = DataLoader(dataset, batch_size=batch_size, pin_memory=True)

    # Initialize model, optimizer
    model = ModelNew().cuda()
    optimizer = optim.SGD(model.parameters(), lr=0.01)

    # Train the model
    train_model(model, optimizer, dataloader, epochs=1)

if __name__ == "__main__":
    main()