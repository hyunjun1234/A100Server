import torch
import torch.nn as nn
import torch.nn.init as init

class ModelNew(nn.Module):
    """
    Optimized model that performs a matrix multiplication, applies Swish activation, and scales the result.
    """
    def __init__(self, in_features, out_features, scaling_factor):
        super(ModelNew, self).__init__()
        self.matmul = nn.Linear(in_features, out_features)
        self.scaling_factor = scaling_factor
        # Initialize weights using Xavier uniform initialization
        init.xavier_uniform_(self.matmul.weight)

    def forward(self, x):
        x = self.matmul(x)
        x = x * torch.sigmoid(x)  # Swish activation
        x = x * self.scaling_factor
        return x

batch_size = 128
in_features = 32768
out_features = 32768
scaling_factor = 2.0

def get_inputs():
    return [torch.rand(batch_size, in_features)]

def get_init_inputs():
    return [in_features, out_features, scaling_factor]

# Example usage
if __name__ == "__main__":
    # Initialize the model
    model = ModelNew(in_features, out_features, scaling_factor)
    
    # Get inputs
    inputs = get_inputs()[0]
    
    # Forward pass
    outputs = model(inputs)
    
    # Print the shape of the output to verify correctness
    print("Output shape:", outputs.shape)