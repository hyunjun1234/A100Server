import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs a matrix multiplication, applies Swish activation, and scales the result.
    """
    def __init__(self, in_features, out_features, scaling_factor):
        super(ModelNew, self).__init__()
        self.matmul = nn.Linear(in_features, out_features)
        self.scaling_factor = scaling_factor
        # Initialize weights using Xavier uniform
        nn.init.xavier_uniform_(self.matmul.weight)

    def forward(self, x):
        x = self.matmul(x)
        # Apply Swish activation
        x = x * torch.sigmoid(x)
        # Scale the result
        x = x * self.scaling_factor
        return x

# Debugging functions
def debug_swish(x):
    sigmoid_x = torch.sigmoid(x)
    swish_x = x * sigmoid_x
    print(f"Input: {x[:5]}")
    print(f"Sigmoid: {sigmoid_x[:5]}")
    print(f"Swish: {swish_x[:5]}")
    return swish_x

def debug_scaling(x, scaling_factor):
    scaled_x = x * scaling_factor
    print(f"Before Scaling: {x[:5]}")
    print(f"After Scaling: {scaled_x[:5]}")
    return scaled_x

batch_size = 128
in_features = 32768
out_features = 32768
scaling_factor = 2.0

def get_inputs():
    return [torch.rand(batch_size, in_features)]

def get_init_inputs():
    return [in_features, out_features, scaling_factor]

# Example usage
if __name__ == "__main__":
    inputs = get_inputs()[0]
    model = ModelNew(*get_init_inputs())
    
    # Forward pass with debugging
    x = model.matmul(inputs)
    x = debug_swish(x)
    output = debug_scaling(x, model.scaling_factor)
    
    print(f"Final Output: {output[:5]}")