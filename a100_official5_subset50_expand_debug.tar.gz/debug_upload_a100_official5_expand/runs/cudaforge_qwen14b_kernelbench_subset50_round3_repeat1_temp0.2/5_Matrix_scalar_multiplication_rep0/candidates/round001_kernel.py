import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs a matrix-scalar multiplication (C = A * s)
    with support for GPU acceleration.
    """
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, s: float) -> torch.Tensor:
        """
        Performs matrix-scalar multiplication.

        Args:
            A: Input matrix of shape (M, N)
            s: Scalar value

        Returns:
            C: Resulting matrix of shape (M, N)
        """
        return A * s

def get_inputs(device='cuda'):
    A = torch.rand(M, N, device=device)
    s = 3.14
    return [A, s]

def get_init_inputs():
    return []  # No special initialization inputs needed

# Constants
M = 16384 * 4
N = 4096 * 4

# Example usage
if __name__ == "__main__":
    # Check if CUDA is available and set the device accordingly
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    # Get inputs on the specified device
    A, s = get_inputs(device)
    
    # Create the model and move it to the device
    model = ModelNew().to(device)
    
    # Perform the forward pass
    C = model(A, s)
    
    print(f"Resulting matrix C on {device}: {C.shape}")