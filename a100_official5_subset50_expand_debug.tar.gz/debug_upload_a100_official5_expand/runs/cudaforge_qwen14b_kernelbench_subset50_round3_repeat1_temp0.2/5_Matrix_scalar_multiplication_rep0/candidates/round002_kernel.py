import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs batched matrix-scalar multiplication (C = A * s)
    """
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, s: float) -> torch.Tensor:
        """
        Performs batched matrix-scalar multiplication.

        Args:
            A: Input tensor of shape (B, M, N) where B is the batch size
            s: Scalar value

        Returns:
            C: Resulting tensor of shape (B, M, N)
        """
        return A * s

def get_inputs(batch_size=1):
    M = 16384 * 4
    N = 4096 * 4
    A = torch.rand(batch_size, M, N, pin_memory=True).cuda()
    s = 3.14
    return [A, s]

def get_init_inputs():
    return []  # No special initialization inputs needed

# Example usage
if __name__ == "__main__":
    import torch.cuda.profiler as profiler
    
    # Initialize model and move it to GPU
    model = ModelNew().cuda()
    
    # Get inputs
    A, s = get_inputs(batch_size=4)
    
    # Profile the model
    with profiler.profile():
        with profiler.record_function("model_inference"):
            C = model(A, s)
    
    print(C.shape)