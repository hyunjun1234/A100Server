import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs a single matrix multiplication (C = A * B) with a small K dimension.
    Utilizes efficient computation techniques to handle large tensors.
    """
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs matrix multiplication.

        Args:
            A: Input tensor of shape (M, K).
            B: Input tensor of shape (K, N).

        Returns:
            Output tensor of shape (M, N).
        """
        # Use torch.matmul for matrix multiplication
        return torch.matmul(A, B)

# Define the dimensions
M = 16384 * 2
N = 16384 * 2
K = 32 * 2

def get_inputs():
    # Generate random input tensors
    A = torch.rand(M, K, device='cuda' if torch.cuda.is_available() else 'cpu')
    B = torch.rand(K, N, device='cuda' if torch.cuda.is_available() else 'cpu')
    return [A, B]

def get_init_inputs():
    return []  # No special initialization inputs needed