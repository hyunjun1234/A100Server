import torch
import torch.nn as nn
import torch.cuda as cuda

class ModelNew(nn.Module):
    """
    Optimized model that performs a single matrix multiplication (C = A * B) with a small K dimension.
    Includes optimizations for memory bandwidth, batch processing, and data types.
    """
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs matrix multiplication with optimizations.

        Args:
            A: Input tensor of shape (M, K).
            B: Input tensor of shape (K, N).

        Returns:
            Output tensor of shape (M, N).
        """
        # Clear unused cache to free up memory
        cuda.empty_cache()
        
        # Perform matrix multiplication
        return torch.matmul(A, B)

def get_inputs(batch_size=16):
    """
    Generates input tensors in smaller batches to improve memory utilization.
    
    Args:
        batch_size: Number of smaller matrices to process in each batch.
        
    Returns:
        List of input tensors.
    """
    M = 16384 * 2 // batch_size
    N = 16384 * 2
    K = 32 * 2
    
    inputs = []
    for _ in range(batch_size):
        A = torch.rand(M, K).cuda()  # Move data to GPU
        B = torch.rand(K, N).cuda()  # Move data to GPU
        inputs.append((A, B))
    
    return inputs

def get_init_inputs():
    return []  # No special initialization inputs needed

# Example usage
if __name__ == "__main__":
    model = ModelNew().cuda()  # Move model to GPU
    inputs = get_inputs()
    
    for A, B in inputs:
        output = model(A, B)
        print(output.shape)