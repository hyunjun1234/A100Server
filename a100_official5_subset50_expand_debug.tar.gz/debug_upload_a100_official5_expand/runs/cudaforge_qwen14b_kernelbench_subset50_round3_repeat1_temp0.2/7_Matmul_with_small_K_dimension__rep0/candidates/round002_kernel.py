import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs batched matrix multiplications (C = A * B) with a small K dimension
    """
    def __init__(self, batch_size=4):
        super(ModelNew, self).__init__()
        self.batch_size = batch_size

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs batched matrix multiplication.

        Args:
            A: Input tensor of shape (B, M, K), where B is the batch size.
            B: Input tensor of shape (B, K, N).

        Returns:
            Output tensor of shape (B, M, N).
        """
        return torch.bmm(A, B)

def get_inputs(batch_size=4):
    M = 16384 * 2
    N = 16384 * 2
    K = 32 * 2
    
    A = torch.rand(batch_size, M, K).cuda()
    B = torch.rand(batch_size, K, N).cuda()
    return [A, B]

def get_init_inputs():
    return []  # No special initialization inputs needed

# Example usage
if __name__ == "__main__":
    batch_size = 4
    model = ModelNew(batch_size=batch_size).cuda()
    A, B = get_inputs(batch_size=batch_size)
    
    # Clear the cache once before starting the computation
    torch.cuda.empty_cache()
    
    # Perform the forward pass
    output = model(A, B)
    print(output.shape)