Upload the single archive:
  /home/jun/unified_bench/a100_open_kernel_feedback_20260624_105554.tar.gz

It contains:
- environment and GPU/CUDA/NCU information
- exact repository commits and dirty status
- configs and system env files
- result CSV/JSON files
- categorized errors and clusters
- log tails
- candidate/raw reply/verdict/task telemetry files (size-capped)

Model weights, caches and large build directories are excluded.
