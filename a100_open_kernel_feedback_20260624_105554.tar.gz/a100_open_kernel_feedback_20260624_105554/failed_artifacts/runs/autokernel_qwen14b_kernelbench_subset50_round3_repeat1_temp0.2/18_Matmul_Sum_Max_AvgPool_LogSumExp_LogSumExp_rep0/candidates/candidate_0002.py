import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void linear_kernel(const float* input, const float* weight, const float* bias, float* output, int batch_size, int in_features, int out_features) {
    int batch_idx = blockIdx.x;
    int out_idx = threadIdx.x;

    if (batch_idx < batch_size && out_idx < out_features) {
        float sum = bias[out_idx];
        for (int in_idx = 0; in_idx < in_features; ++in_idx) {
            sum += input[batch_idx * in_features + in_idx] * weight[out_idx * in_features + in_idx];
        }
        output[batch_idx * out_features + out_idx] = sum;
    }
}

__global__ void sum_kernel(const float* input, float* output, int batch_size, int features) {
    int batch_idx = blockIdx.x;
    int thread_idx = threadIdx.x;

    if (batch_idx < batch_size) {
        float sum = 0.0f;
        for (int i = 0; i < features; ++i) {
            sum += input[batch_idx * features + i];
        }
        output[batch_idx] = sum;
    }
}

__global__ void max_kernel(const float* input, float* output, int batch_size, int features) {
    int batch_idx = blockIdx.x;
    int thread_idx = threadIdx.x;

    if (batch_idx < batch_size) {
        float max_val = -INFINITY;
        for (int i = 0; i < features; ++i) {
            max_val = fmaxf(max_val, input[batch_idx * features + i]);
        }
        output[batch_idx] = max_val;
    }
}

__global__ void mean_kernel(const float* input, float* output, int batch_size, int features) {
    int batch_idx = blockIdx.x;
    int thread_idx = threadIdx.x;

    if (batch_idx < batch_size) {
        float sum = 0.0f;
        for (int i = 0; i < features; ++i) {
            sum += input[batch_idx * features + i];
        }
        output[batch_idx] = sum / features;
    }
}

__global__ void logsumexp_kernel(const float* input, float* output, int batch_size, int features) {
    int batch_idx = blockIdx.x;
    int thread_idx = threadIdx.x;

    if (batch_idx < batch_size) {
        float max_val = -INFINITY;
        for (int i = 0; i < features; ++i) {
            max_val = fmaxf(max_val, input[batch_idx * features + i]);
        }

        float sum = 0.0f;
        for (int i = 0; i < features; ++i) {
            sum += expf(input[batch_idx * features + i] - max_val);
        }
        output[batch_idx] = max_val + logf(sum);
    }
}

torch::Tensor linear_cuda(torch::Tensor input, torch::Tensor weight, torch::Tensor bias) {
    auto output = torch::empty_like(input);
    int batch_size = input.size(0);
    int in_features = input.size(1);
    int out_features = weight.size(0);
    linear_kernel<<<batch_size, out_features>>>(input.data_ptr<float>(), weight.data_ptr<float>(), bias.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_features, out_features);
    return output;
}

torch::Tensor sum_cuda(torch::Tensor input) {
    auto output = torch::empty({input.size(0)}, input.options());
    sum_kernel<<<input.size(0), 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), input.size(0), input.size(1));
    return output.view({input.size(0), 1});
}

torch::Tensor max_cuda(torch::Tensor input) {
    auto output = torch::empty({input.size(0)}, input.options());
    max_kernel<<<input.size(0), 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), input.size(0), input.size(1));
    return output.view({input.size(0), 1});
}

torch::Tensor mean_cuda(torch::Tensor input) {
    auto output = torch::empty({input.size(0)}, input.options());
    mean_kernel<<<input.size(0), 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), input.size(0), input.size(1));
    return output.view({input.size(0), 1});
}

torch::Tensor logsumexp_cuda(torch::Tensor input) {
    auto output = torch::empty({input.size(0)}, input.options());
    logsumexp_kernel<<<input.size(0), 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), input.size(0), input.size(1));
    return output.view({input.size(0), 1});
}

"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "linear_cuda", "sum_cuda", "max_cuda", "mean_cuda", "logsumexp_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x):
        mod = _get_mod()
        x = mod.linear_cuda(x, self.linear.weight, self.linear.bias)
        x = mod.sum_cuda(x)
        x = mod.max_cuda(x)
        x = mod.mean_cuda(x)
        x = mod.logsumexp_cuda(x)
        x = mod.logsumexp_cuda(x)
        return x
