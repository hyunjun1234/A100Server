import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Simple model that performs a LeakyReLU activation using a custom CUDA kernel.
    """
    def __init__(self, negative_slope: float = 0.01):
        """
        Initializes the LeakyReLU module.

        Args:
            negative_slope (float, optional): The negative slope of the activation function. Defaults to 0.01.
        """
        super(ModelNew, self).__init__()
        self.negative_slope = negative_slope
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Applies LeakyReLU activation to the input tensor using a custom CUDA kernel.

        Args:
            x (torch.Tensor): Input tensor of any shape.

        Returns:
            torch.Tensor: Output tensor with LeakyReLU applied, same shape as input.
        """
        if not x.is_cuda:
            raise ValueError("Input tensor must be on a CUDA device.")
        
        CUDA_SRC = r"""
        #include <torch/extension.h>
        #include <cuda_runtime.h>

        __global__ void leaky_relu_kernel(const float* input, float* output, int N, float negative_slope) {
            int idx = blockIdx.x * blockDim.x + threadIdx.x;
            if (idx < N) {
                output[idx] = input[idx] > 0 ? input[idx] : input[idx] * negative_slope;
            }
        }

        torch::Tensor leaky_relu_cuda(torch::Tensor input, float negative_slope) {
            auto output = torch::empty_like(input);
            int N = input.numel();
            leaky_relu_kernel<<<(N+255)/256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), N, negative_slope);
            return output;
        }
        """

        from kernels.cuda._compile import compile_cuda
        _mod = compile_cuda(CUDA_SRC, "leaky_relu_cuda")
        return _mod.leaky_relu_cuda(x, self.negative_slope)

batch_size = 4096
dim = 393216

def get_inputs():
    x = torch.rand(batch_size, dim).cuda()
    return [x]

def get_init_inputs():
    return []  # No special initialization inputs needed
