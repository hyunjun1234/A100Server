import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void hardsigmoid_kernel(const float* input, float* output, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        float val = input[idx] * 0.16666666666666666f + 0.5f;
        output[idx] = val > 0.0f ? (val < 1.0f ? val : 1.0f) : 0.0f;
    }
}

torch::Tensor hardsigmoid_cuda(torch::Tensor input) {
    auto output = torch::empty_like(input);
    int N = input.numel();
    hardsigmoid_kernel<<<(N+255)/256, 256>>>(
        input.data_ptr<float>(), output.data_ptr<float>(), N);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "hardsigmoid_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return _get_mod().hardsigmoid_cuda(x)
