import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void mish_kernel(const float* input, float* output, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        float val = input[idx];
        float e_val = exp(val);
        output[idx] = val * (1.0f - 1.0f / (1.0f + e_val));
    }
}

torch::Tensor mish_cuda(torch::Tensor input) {
    auto output = torch::empty_like(input);
    int N = input.numel();
    mish_kernel<<<(N+255)/256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), N);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "mish_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features):
        super(ModelNew, self).__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x):
        x = self.linear(x)
        x = _get_mod().mish_cuda(x)
        x = _get_mod().mish_cuda(x)
        return x
