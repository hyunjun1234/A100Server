import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Simple model that performs L1 normalization.
    """
    def __init__(self):
        """
        Initializes the L1 normalization layer.
        """
        super(ModelNew, self).__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Applies L1 normalization to the input tensor.

        Args:
            x (torch.Tensor): Input tensor of shape (..., dim, ...).

        Returns:
            torch.Tensor: Output tensor with L1 normalization applied, same shape as input.
        """
        l1_norm = torch.mean(torch.abs(x), dim=1, keepdim=True)
        # Avoid division by zero by adding a small epsilon
        l1_norm = torch.where(l1_norm == 0, torch.tensor(1e-10, device=x.device), l1_norm)
        return x / l1_norm

batch_size = 32768
# choose dim so total <2^31
dim = 65535

def get_inputs():
    x = torch.rand(batch_size, dim)
    return [x]

def get_init_inputs():
    return []
