import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void scale_kernel(const float* input, const float* scale, float* output, int N, int M) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N * M) {
        int row = idx / M;
        int col = idx % M;
        output[idx] = input[idx] * scale[col];
    }
}

extern "C" torch::Tensor gemm_scale_cuda(torch::Tensor input, torch::Tensor weight, torch::Tensor scale, int out_features) {
    auto output = torch::empty_like(input);
    int N = input.size(0);
    int M = input.size(1);

    float alpha = 1.0f;
    float beta = 0.0f;

    cublasHandle_t handle;
    cublasCreate(&handle);

    cublasSgemm(handle, CUBLAS_OP_N, CUBLAS_OP_N, out_features, N, M, &alpha,
                weight.data_ptr<float>(), out_features,
                input.data_ptr<float>(), M,
                &beta,
                output.data_ptr<float>(), out_features);

    cublasDestroy(handle);

    dim3 threads(256);
    dim3 blocks((N * M + threads.x - 1) / threads.x);
    scale_kernel<<<blocks, threads>>>(output.data_ptr<float>(), scale.data_ptr<float>(), output.data_ptr<float>(), N, M);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "gemm_scale_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scale_shape, eps=1e-5, momentum=0.1):
        super(ModelNew, self).__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.scale = nn.Parameter(torch.randn(scale_shape))
        self.bn = nn.BatchNorm1d(out_features, eps=eps, momentum=momentum)

    def forward(self, x):
        x = _get_mod().gemm_scale_cuda(x, self.gemm.weight, self.scale, self.gemm.out_features)
        x = self.bn(x)
        return x
