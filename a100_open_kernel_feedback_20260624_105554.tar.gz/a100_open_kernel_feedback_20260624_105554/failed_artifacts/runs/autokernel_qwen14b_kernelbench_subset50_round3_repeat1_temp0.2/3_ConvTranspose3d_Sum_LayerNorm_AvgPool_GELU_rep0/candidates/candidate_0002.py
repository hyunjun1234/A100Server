import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose_add_kernel(
    const float* input, const float* weight, const float* bias, float* output,
    int batch_size, int in_channels, int out_channels, int depth, int height, int width,
    int kernel_size_d, int kernel_size_h, int kernel_size_w, int stride_d, int stride_h, int stride_w,
    int padding_d, int padding_h, int padding_w, int output_padding_d, int output_padding_h, int output_padding_w,
    int sum_weight) {
    int b = blockIdx.x / (out_channels * depth * height * width);
    int oc = (blockIdx.x / (depth * height * width)) % out_channels;
    int d = (blockIdx.x / (height * width)) % depth;
    int h = (blockIdx.x / width) % height;
    int w = blockIdx.x % width;

    if (b >= batch_size || oc >= out_channels || d >= depth || h >= height || w >= width) return;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kd = -padding_d; kd <= kernel_size_d - padding_d - 1; ++kd) {
            for (int kh = -padding_h; kh <= kernel_size_h - padding_h - 1; ++kh) {
                for (int kw = -padding_w; kw <= kernel_size_w - padding_w - 1; ++kw) {
                    int id = d * stride_d - output_padding_d + kd;
                    int ih = h * stride_h - output_padding_h + kh;
                    int iw = w * stride_w - output_padding_w + kw;
                    if (id >= 0 && id < depth && ih >= 0 && ih < height && iw >= 0 && iw < width) {
                        int input_idx = b * in_channels * depth * height * width +
                                       ic * depth * height * width +
                                       id * height * width +
                                       ih * width +
                                       iw;
                        int weight_idx = oc * in_channels * kernel_size_d * kernel_size_h * kernel_size_w +
                                         ic * kernel_size_d * kernel_size_h * kernel_size_w +
                                         (kd + padding_d) * kernel_size_h * kernel_size_w +
                                         (kh + padding_h) * kernel_size_w +
                                         (kw + padding_w);
                        sum += input[input_idx] * weight[weight_idx];
                    }
                }
            }
        }
    }

    int output_idx = b * out_channels * depth * height * width +
                     oc * depth * height * width +
                     d * height * width +
                     h * width +
                     w;
    output[output_idx] = sum + bias[oc] + sum_weight;
}

torch::Tensor conv_transpose_add_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias, int batch_size, int in_channels, int out_channels,
    int depth, int height, int width, int kernel_size_d, int kernel_size_h, int kernel_size_w, int stride_d, int stride_h, int stride_w,
    int padding_d, int padding_h, int padding_w, int output_padding_d, int output_padding_h, int output_padding_w, float sum_weight) {
    auto output = torch::zeros({batch_size, out_channels, depth, height, width}, input.options());
    int num_threads = 256;
    int num_blocks = (batch_size * out_channels * depth * height * width + num_threads - 1) / num_threads;
    conv_transpose_add_kernel<<<num_blocks, num_threads>>>(
        input.data_ptr<float>(), weight.data_ptr<float>(), bias.data_ptr<float>(), output.data_ptr<float>(),
        batch_size, in_channels, out_channels, depth, height, width,
        kernel_size_d, kernel_size_h, kernel_size_w, stride_d, stride_h, stride_w,
        padding_d, padding_h, padding_w, output_padding_d, output_padding_h, output_padding_w,
        static_cast<int>(sum_weight));
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose_add_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, output_padding, sum_weight, norm_shape, pool_kernel_size):
        super(ModelNew, self).__init__()
        self.conv_transpose = nn.ConvTranspose3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding)
        self.sum_weight = nn.Parameter(torch.tensor(sum_weight))
        self.norm = nn.LayerNorm(norm_shape)
        self.avg_pool = nn.AvgPool3d(kernel_size=pool_kernel_size)
        self.gelu = nn.GELU()

    def forward(self, x):
        weight = self.conv_transpose.weight
        bias = self.conv_transpose.bias
        batch_size, in_channels, depth, height, width = x.size()
        kernel_size_d, kernel_size_h, kernel_size_w = self.conv_transpose.kernel_size
        stride_d, stride_h, stride_w = self.conv_transpose.stride
        padding_d, padding_h, padding_w = self.conv_transpose.padding
        output_padding_d, output_padding_h, output_padding_w = self.conv_transpose.output_padding
        sum_weight = self.sum_weight.item()

        x = _get_mod().conv_transpose_add_cuda(
            x, weight, bias, batch_size, in_channels, out_channels,
            depth, height, width, kernel_size_d, kernel_size_h, kernel_size_w, stride_d, stride_h, stride_w,
            padding_d, padding_h, padding_w, output_padding_d, output_padding_h, output_padding_w, sum_weight
        )

        x = self.norm(x)
        x = self.avg_pool(x)
        x = self.gelu(x)
        return x
