import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void conv_transpose_kernel(const float* input, float* output, const float* weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size) {
    int b = blockIdx.x / (out_channels * width);
    int c_out = (blockIdx.x % (out_channels * width)) / width;
    int x = blockIdx.x % width;
    int y = blockIdx.y;

    float sum = 0.0f;
    for (int c_in = 0; c_in < in_channels; ++c_in) {
        for (int ky = 0; ky < kernel_size; ++ky) {
            for (int kx = 0; kx < kernel_size; ++kx) {
                int ix = x - kx;
                int iy = y - ky;
                if (ix >= 0 && ix < width && iy >= 0 && iy < height) {
                    int input_idx = b * in_channels * height * width + c_in * height * width + iy * width + ix;
                    int weight_idx = c_out * in_channels * kernel_size * kernel_size + c_in * kernel_size * kernel_size + ky * kernel_size + kx;
                    sum += input[input_idx] * weight[weight_idx];
                }
            }
        }
    }

    int output_idx = b * out_channels * width * height + c_out * width * height + y * width + x;
    output[output_idx] = sum;
}

__global__ void global_avg_pool_kernel(const float* input, float* output, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x / out_channels;
    int c_out = blockIdx.x % out_channels;

    float sum = 0.0f;
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int input_idx = b * out_channels * height * width + c_out * height * width + y * width + x;
            sum += input[input_idx];
        }
    }

    int output_idx = b * out_channels + c_out;
    output[output_idx] = sum / (height * width);
}

__global__ void add_bias_kernel(float* input, const float* bias, int batch_size, int out_channels) {
    int b = blockIdx.x / out_channels;
    int c_out = blockIdx.x % out_channels;

    int input_idx = b * out_channels + c_out;
    input[input_idx] += bias[c_out];
}

__global__ void logsumexp_kernel(float* input, int batch_size, int out_channels) {
    int b = blockIdx.x / out_channels;
    int c_out = blockIdx.x % out_channels;

    int input_idx = b * out_channels + c_out;
    input[input_idx] = logf(expf(input[input_idx]) + 1.0f);
}

__global__ void sum_kernel(float* input, int batch_size, int out_channels) {
    int b = blockIdx.x;

    float sum = 0.0f;
    for (int c_out = 0; c_out < out_channels; ++c_out) {
        int input_idx = b * out_channels + c_out;
        sum += input[input_idx];
    }

    int output_idx = b;
    input[output_idx] = sum;
}

__global__ void multiply_kernel(float* input, int batch_size, float scalar) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < batch_size) {
        input[idx] *= scalar;
    }
}

torch::Tensor conv_transpose_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size) {
    auto output = torch::zeros({batch_size, out_channels, height, width}, input.options());
    conv_transpose_kernel<<<(batch_size * out_channels * width + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), weight.data_ptr<float>(), batch_size, in_channels, out_channels, height, width, kernel_size);
    return output;
}

torch::Tensor global_avg_pool_cuda(torch::Tensor input, int batch_size, int out_channels, int height, int width) {
    auto output = torch::zeros({batch_size, out_channels}, input.options());
    global_avg_pool_kernel<<<batch_size * out_channels, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_channels, height, width);
    return output;
}

torch::Tensor add_bias_cuda(torch::Tensor input, torch::Tensor bias, int batch_size, int out_channels) {
    add_bias_kernel<<<batch_size * out_channels, 256>>>(input.data_ptr<float>(), bias.data_ptr<float>(), batch_size, out_channels);
    return input;
}

torch::Tensor logsumexp_cuda(torch::Tensor input, int batch_size, int out_channels) {
    logsumexp_kernel<<<batch_size * out_channels, 256>>>(input.data_ptr<float>(), batch_size, out_channels);
    return input;
}

torch::Tensor sum_cuda(torch::Tensor input, int batch_size, int out_channels) {
    sum_kernel<<<batch_size, 256>>>(input.data_ptr<float>(), batch_size, out_channels);
    return input;
}

torch::Tensor multiply_cuda(torch::Tensor input, int batch_size, float scalar) {
    multiply_kernel<<<(batch_size + 255) / 256, 256>>>(input.data_ptr<float>(), batch_size, scalar);
    return input;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape):
        super().__init__()
        self.conv_transpose = nn.ConvTranspose2d(in_channels, out_channels, kernel_size)
        self.bias = nn.Parameter(torch.randn(bias_shape))

    def forward(self, x):
        batch_size, in_channels, height, width = x.size()
        weight = self.conv_transpose.weight.view(out_channels, in_channels, kernel_size, kernel_size).contiguous()

        x = _get_mod().conv_transpose_cuda(x, weight, batch_size, in_channels, out_channels, height, width, kernel_size)
        x = _get_mod().global_avg_pool_cuda(x, batch_size, out_channels, height, width)
        x = _get_mod().add_bias_cuda(x, self.bias, batch_size, out_channels)
        x = _get_mod().logsumexp_cuda(x, batch_size, out_channels)
        x = _get_mod().sum_cuda(x, batch_size, out_channels)
        x = _get_mod().multiply_cuda(x, batch_size, 10.0)

        return x.view(batch_size, 1)
