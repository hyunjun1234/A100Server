import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void conv_transpose_kernel(const float* input, float* output, const float* weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size) {
    int b = blockIdx.x / (out_channels * width);
    int oc = (blockIdx.x % (out_channels * width)) / width;
    int w = blockIdx.x % width;
    int h = blockIdx.y;

    int input_h = h * 2 - kernel_size + 1;
    int input_w = w * 2 - kernel_size + 1;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kh = 0; kh < kernel_size; ++kh) {
            for (int kw = 0; kw < kernel_size; ++kw) {
                int ih = input_h + kh;
                int iw = input_w + kw;
                if (ih >= 0 && ih < height && iw >= 0 && iw < width) {
                    sum += input[b * in_channels * height * width + ic * height * width + ih * width + iw] *
                           weight[oc * in_channels * kernel_size * kernel_size + ic * kernel_size * kernel_size + kh * kernel_size + kw];
                }
            }
        }
    }

    output[b * out_channels * height * width + oc * height * width + h * width + w] = sum;
}

__global__ void global_avg_pool_kernel(const float* input, float* output, int batch_size, int out_channels, int height, int width) {
    int b = blockIdx.x / out_channels;
    int oc = blockIdx.x % out_channels;

    float sum = 0.0f;
    for (int h = 0; h < height; ++h) {
        for (int w = 0; w < width; ++w) {
            sum += input[b * out_channels * height * width + oc * height * width + h * width + w];
        }
    }

    output[b * out_channels + oc] = sum / (height * width);
}

__global__ void add_bias_kernel(float* input, const float* bias, int batch_size, int out_channels) {
    int b = blockIdx.x / out_channels;
    int oc = blockIdx.x % out_channels;

    input[b * out_channels + oc] += bias[oc];
}

__global__ void log_sum_exp_kernel(float* input, int batch_size, int out_channels) {
    int b = blockIdx.x / out_channels;
    int oc = blockIdx.x % out_channels;

    float max_val = -INFINITY;
    for (int i = 0; i < out_channels; ++i) {
        max_val = fmaxf(max_val, input[b * out_channels + i]);
    }

    float sum = 0.0f;
    for (int i = 0; i < out_channels; ++i) {
        sum += expf(input[b * out_channels + i] - max_val);
    }

    input[b * out_channels + oc] = max_val + logf(sum);
}

__global__ void sum_kernel(float* input, int batch_size, int out_channels) {
    int b = blockIdx.x;

    float sum = 0.0f;
    for (int i = 0; i < out_channels; ++i) {
        sum += input[b * out_channels + i];
    }

    input[b] = sum;
}

__global__ void multiply_kernel(float* input, int batch_size, float scalar) {
    int b = blockIdx.x;

    input[b] *= scalar;
}

torch::Tensor conv_transpose_cuda(torch::Tensor input, torch::Tensor weight, int batch_size, int in_channels, int out_channels, int height, int width, int kernel_size) {
    auto output = torch::zeros({batch_size, out_channels, height, width}, input.options());
    conv_transpose_kernel<<<(batch_size * out_channels * width + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), weight.data_ptr<float>(), batch_size, in_channels, out_channels, height, width, kernel_size);
    return output;
}

torch::Tensor global_avg_pool_cuda(torch::Tensor input, int batch_size, int out_channels, int height, int width) {
    auto output = torch::zeros({batch_size, out_channels}, input.options());
    global_avg_pool_kernel<<<(batch_size * out_channels + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), batch_size, out_channels, height, width);
    return output;
}

torch::Tensor add_bias_cuda(torch::Tensor input, torch::Tensor bias, int batch_size, int out_channels) {
    add_bias_kernel<<<(batch_size * out_channels + 255) / 256, 256>>>(input.data_ptr<float>(), bias.data_ptr<float>(), batch_size, out_channels);
    return input;
}

torch::Tensor log_sum_exp_cuda(torch::Tensor input, int batch_size, int out_channels) {
    log_sum_exp_kernel<<<(batch_size * out_channels + 255) / 256, 256>>>(input.data_ptr<float>(), batch_size, out_channels);
    return input;
}

torch::Tensor sum_cuda(torch::Tensor input, int batch_size, int out_channels) {
    sum_kernel<<<batch_size, 256>>>(input.data_ptr<float>(), batch_size, out_channels);
    return input;
}

torch::Tensor multiply_cuda(torch::Tensor input, int batch_size, float scalar) {
    multiply_kernel<<<batch_size, 256>>>(input.data_ptr<float>(), batch_size, scalar);
    return input;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape):
        super().__init__()
        self.conv_transpose = nn.ConvTranspose2d(in_channels, out_channels, kernel_size)
        self.bias = nn.Parameter(torch.randn(bias_shape))

    def forward(self, x):
        weight = self.conv_transpose.weight
        bias = self.bias
        batch_size, in_channels, height, width = x.size()
        out_channels = weight.size(0)
        kernel_size = weight.size(2)

        x = _get_mod().conv_transpose_cuda(x, weight, batch_size, in_channels, out_channels, height, width, kernel_size)
        x = _get_mod().global_avg_pool_cuda(x, batch_size, out_channels, height, width)
        x = _get_mod().add_bias_cuda(x, bias, batch_size, out_channels)
        x = _get_mod().log_sum_exp_cuda(x, batch_size, out_channels)
        x = _get_mod().sum_cuda(x, batch_size, out_channels)
        x = _get_mod().multiply_cuda(x, batch_size, 10.0)

        return x
