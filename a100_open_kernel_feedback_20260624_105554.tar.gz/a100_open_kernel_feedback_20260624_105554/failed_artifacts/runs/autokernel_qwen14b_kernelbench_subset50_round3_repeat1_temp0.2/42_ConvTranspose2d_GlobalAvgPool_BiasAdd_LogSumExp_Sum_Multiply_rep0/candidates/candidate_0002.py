import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void global_avg_pool_cuda(const float* input, float* output, int N, int C, int H, int W) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N * C) {
        int n = idx / C;
        int c = idx % C;
        float sum = 0.0f;
        for (int h = 0; h < H; ++h) {
            for (int w = 0; w < W; ++w) {
                sum += input[n * C * H * W + c * H * W + h * W + w];
            }
        }
        output[n * C + c] = sum / (H * W);
    }
}

torch::Tensor global_avg_pool_cuda_wrapper(torch::Tensor input) {
    auto output = torch::empty({input.size(0), input.size(1)}, input.options());
    int N = input.size(0);
    int C = input.size(1);
    int H = input.size(2);
    int W = input.size(3);
    global_avg_pool_cuda<<<(N * C + 255) / 256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), N, C, H, W);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "global_avg_pool_cuda_wrapper")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, bias_shape):
        super().__init__()
        self.conv_transpose = nn.ConvTranspose2d(in_channels, out_channels, kernel_size)
        self.bias = nn.Parameter(torch.randn(bias_shape))

    def forward(self, x):
        x = self.conv_transpose(x)
        x = _get_mod().global_avg_pool_cuda_wrapper(x)
        x = x.view(x.size(0), x.size(1), 1, 1)  # Reshape to match original output shape
        x = x + self.bias
        x = torch.logsumexp(x, dim=1, keepdim=True)  # Log-sum-exp
        x = torch.sum(x, dim=(2, 3))  # Sum
        x = x * 10.0  # Multiplication
        return x
