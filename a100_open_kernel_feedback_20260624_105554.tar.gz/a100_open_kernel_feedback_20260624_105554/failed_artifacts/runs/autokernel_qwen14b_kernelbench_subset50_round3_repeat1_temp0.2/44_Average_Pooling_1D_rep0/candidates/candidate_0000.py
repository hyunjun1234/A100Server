import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void avg_pool1d_kernel(const float* input, float* output, int batch_size, int in_channels, int input_length, int kernel_size, int stride, int padding) {
    int b = blockIdx.x / (in_channels * ((input_length + 2 * padding - kernel_size) / stride + 1));
    int c = (blockIdx.x % (in_channels * ((input_length + 2 * padding - kernel_size) / stride + 1))) / ((input_length + 2 * padding - kernel_size) / stride + 1);
    int out_idx = blockIdx.x % ((input_length + 2 * padding - kernel_size) / stride + 1);

    int start = out_idx * stride - padding;
    int end = start + kernel_size;

    float sum = 0.0f;
    int count = 0;
    for (int i = start; i < end; ++i) {
        if (i >= 0 && i < input_length) {
            sum += input[b * in_channels * input_length + c * input_length + i];
            count++;
        }
    }

    output[b * in_channels * ((input_length + 2 * padding - kernel_size) / stride + 1) + c * ((input_length + 2 * padding - kernel_size) / stride + 1) + out_idx] = sum / count;
}

torch::Tensor avg_pool1d_cuda(torch::Tensor input, int kernel_size, int stride, int padding) {
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int input_length = input.size(2);
    int output_length = (input_length + 2 * padding - kernel_size) / stride + 1;

    auto output = torch::empty({batch_size, in_channels, output_length}, input.options());
    avg_pool1d_kernel<<<(batch_size * in_channels * output_length + 255) / 256, 256>>>(
        input.data_ptr<float>(), output.data_ptr<float>(), batch_size, in_channels, input_length, kernel_size, stride, padding);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "avg_pool1d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, kernel_size: int, stride: int = 1, padding: int = 0):
        super(ModelNew, self).__init__()
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _get_mod().avg_pool1d_cuda(x, self.kernel_size, self.stride, self.padding)
