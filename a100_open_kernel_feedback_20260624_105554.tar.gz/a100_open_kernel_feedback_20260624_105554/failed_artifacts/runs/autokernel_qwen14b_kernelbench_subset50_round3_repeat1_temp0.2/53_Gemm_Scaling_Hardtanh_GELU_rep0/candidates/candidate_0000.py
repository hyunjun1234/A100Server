import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void gemm_kernel(const float* A, const float* B, float* C, int M, int N, int K) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += A[row * K + k] * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}

__global__ void scale_kernel(float* x, float scaling_factor, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        x[idx] *= scaling_factor;
    }
}

__global__ void hardtanh_kernel(float* x, float min_val, float max_val, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        x[idx] = fminf(fmaxf(x[idx], min_val), max_val);
    }
}

__global__ void gelu_kernel(float* x, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        float cdf = 0.5f * (1.0f + tanhf(sqrtf(2.0f / M_PI) * (x[idx] + 0.044715f * powf(x[idx], 3.0f))));
        x[idx] = x[idx] * cdf;
    }
}

torch::Tensor gemm_cuda(torch::Tensor A, torch::Tensor B, int M, int N, int K) {
    auto C = torch::empty({M, N}, A.options());
    gemm_kernel<<<(M+15)/16, (N+15)/16>>>(A.data_ptr<float>(), B.data_ptr<float>(), C.data_ptr<float>(), M, N, K);
    return C;
}

torch::Tensor scale_cuda(torch::Tensor x, float scaling_factor) {
    scale_kernel<<<(x.numel()+255)/256, 256>>>(x.data_ptr<float>(), scaling_factor, x.numel());
    return x;
}

torch::Tensor hardtanh_cuda(torch::Tensor x, float min_val, float max_val) {
    hardtanh_kernel<<<(x.numel()+255)/256, 256>>>(x.data_ptr<float>(), min_val, max_val, x.numel());
    return x;
}

torch::Tensor gelu_cuda(torch::Tensor x) {
    gelu_kernel<<<(x.numel()+255)/256, 256>>>(x.data_ptr<float>(), x.numel());
    return x;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "gemm_cuda", "scale_cuda", "hardtanh_cuda", "gelu_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scaling_factor, hardtanh_min, hardtanh_max):
        super().__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.scaling_factor = scaling_factor
        self.hardtanh_min = hardtanh_min
        self.hardtanh_max = hardtanh_max

    def forward(self, x):
        weight = self.gemm.weight.contiguous()
        bias = self.gemm.bias.contiguous()
        
        x = _get_mod().gemm_cuda(x, weight, x.size(0), weight.size(1), weight.size(0))
        if bias is not None:
            x.add_(bias.view(1, -1).expand_as(x))
        
        x = _get_mod().scale_cuda(x, self.scaling_factor)
        x = _get_mod().hardtanh_cuda(x, self.hardtanh_min, self.hardtanh_max)
        x = _get_mod().gelu_cuda(x)
        
        return x
