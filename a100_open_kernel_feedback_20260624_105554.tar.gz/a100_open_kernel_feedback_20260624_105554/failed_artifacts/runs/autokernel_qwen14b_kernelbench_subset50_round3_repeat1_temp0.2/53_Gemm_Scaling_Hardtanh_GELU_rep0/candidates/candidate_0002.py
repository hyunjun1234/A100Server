import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>

__global__ void gemm_kernel(float* A, float* B, float* C, int M, int N, int K, float alpha, float beta) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += A[row * K + k] * B[k * N + col];
        }
        C[row * N + col] = alpha * sum + beta * C[row * N + col];
    }
}

torch::Tensor gemm_cuda(torch::Tensor A, torch::Tensor B, float alpha, float beta) {
    int M = A.size(0);
    int N = B.size(1);
    int K = A.size(1);

    auto C = torch::zeros({M, N}, A.options());

    dim3 threads(16, 16);
    dim3 blocks((N + threads.x - 1) / threads.x, (M + threads.y - 1) / threads.y);

    gemm_kernel<<<blocks, threads>>>(A.data_ptr<float>(), B.data_ptr<float>(), C.data_ptr<float>(), M, N, K, alpha, beta);
    return C;
}

torch::Tensor hardtanh_cuda(torch::Tensor x, float min_val, float max_val) {
    return torch::clamp(x, min_val, max_val);
}

torch::Tensor gelu_cuda(torch::Tensor x) {
    return 0.5f * x * (1.0f + torch::erf(x / std::sqrt(2.0f)));
}

torch::Tensor my_op_cuda(torch::Tensor x, torch::Tensor weight, torch::Tensor bias, float scaling_factor, float hardtanh_min, float hardtanh_max) {
    x = gemm_cuda(x, weight, 1.0f, 0.0f);
    x = x * scaling_factor;
    x = hardtanh_cuda(x, hardtanh_min, hardtanh_max);
    x = gelu_cuda(x);
    return x;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "my_op_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scaling_factor, hardtanh_min, hardtanh_max):
        super().__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.scaling_factor = scaling_factor
        self.hardtanh_min = hardtanh_min
        self.hardtanh_max = hardtanh_max

    def forward(self, x):
        return _get_mod().my_op_cuda(x, self.gemm.weight, self.gemm.bias, self.scaling_factor, self.hardtanh_min, self.hardtanh_max)
