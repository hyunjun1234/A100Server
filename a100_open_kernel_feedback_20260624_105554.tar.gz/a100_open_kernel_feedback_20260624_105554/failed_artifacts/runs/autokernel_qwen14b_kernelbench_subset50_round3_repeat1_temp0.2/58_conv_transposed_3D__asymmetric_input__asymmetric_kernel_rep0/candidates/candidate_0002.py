import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose3d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int depth_in, int height_in, int width_in,
    int depth_out, int height_out, int width_out,
    int kernel_depth, int kernel_height, int kernel_width,
    int stride_depth, int stride_height, int stride_width,
    int padding_depth, int padding_height, int padding_width,
    int output_padding_depth, int output_padding_height, int output_padding_width,
    int groups) {
    int b = blockIdx.x / (out_channels * depth_out * height_out);
    int oc = (blockIdx.x / (depth_out * height_out)) % out_channels;
    int d_out = (blockIdx.x / height_out) % depth_out;
    int h_out = (blockIdx.x % height_out);
    int w_out = threadIdx.x;

    float sum = 0.0f;
    if (oc < out_channels && d_out < depth_out && h_out < height_out && w_out < width_out) {
        for (int ic = 0; ic < in_channels; ++ic) {
            for (int kd = 0; kd < kernel_depth; ++kd) {
                for (int kh = 0; kh < kernel_height; ++kh) {
                    for (int kw = 0; kw < kernel_width; ++kw) {
                        int d_in = d_out * stride_depth - padding_depth + kd;
                        int h_in = h_out * stride_height - padding_height + kh;
                        int w_in = w_out * stride_width - padding_width + kw;

                        if (d_in >= 0 && d_in < depth_in && h_in >= 0 && h_in < height_in && w_in >= 0 && w_in < width_in) {
                            int input_idx = b * in_channels * depth_in * height_in * width_in +
                                           ic * depth_in * height_in * width_in +
                                           d_in * height_in * width_in +
                                           h_in * width_in +
                                           w_in;
                            int weight_idx = oc * in_channels * kernel_depth * kernel_height * kernel_width +
                                            ic * kernel_depth * kernel_height * kernel_width +
                                            kd * kernel_height * kernel_width +
                                            kh * kernel_width +
                                            kw;
                            sum += input[input_idx] * weight[weight_idx];
                        }
                    }
                }
            }
        }

        int output_idx = b * out_channels * depth_out * height_out * width_out +
                         oc * depth_out * height_out * width_out +
                         d_out * height_out * width_out +
                         h_out * width_out +
                         w_out;
        output[output_idx] = sum + bias[oc];
    }
}

torch::Tensor conv_transpose3d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int depth_in, int height_in, int width_in,
    int depth_out, int height_out, int width_out,
    int kernel_depth, int kernel_height, int kernel_width,
    int stride_depth, int stride_height, int stride_width,
    int padding_depth, int padding_height, int padding_width,
    int output_padding_depth, int output_padding_height, int output_padding_width,
    int groups) {
    auto output = torch::zeros({batch_size, out_channels, depth_out, height_out, width_out}, input.options());
    int threads = width_out;
    int blocks = batch_size * out_channels * depth_out * height_out;
    conv_transpose3d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        depth_in, height_in, width_in,
        depth_out, height_out, width_out,
        kernel_depth, kernel_height, kernel_width,
        stride_depth, stride_height, stride_width,
        padding_depth, padding_height, padding_width,
        output_padding_depth, output_padding_height, output_padding_width,
        groups);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1, 1), padding: tuple = (0, 0, 0), output_padding: tuple = (0, 0, 0), groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv_transpose3d = nn.ConvTranspose3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, groups=groups, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv_transpose3d.weight
        bias = self.conv_transpose3d.bias if self.conv_transpose3d.bias is not None else torch.zeros(self.conv_transpose3d.out_channels, device=x.device)
        
        batch_size, in_channels, depth_in, height_in, width_in = x.shape
        _, out_channels, kernel_depth, kernel_height, kernel_width = weight.shape
        stride_depth, stride_height, stride_width = self.conv_transpose3d.stride
        padding_depth, padding_height, padding_width = self.conv_transpose3d.padding
        output_padding_depth, output_padding_height, output_padding_width = self.conv_transpose3d.output_padding
        groups = self.conv_transpose3d.groups
        
        depth_out = (depth_in - 1) * stride_depth - 2 * padding_depth + kernel_depth + output_padding_depth
        height_out = (height_in - 1) * stride_height - 2 * padding_height + kernel_height + output_padding_height
        width_out = (width_in - 1) * stride_width - 2 * padding_width + kernel_width + output_padding_width
        
        return _get_mod().conv_transpose3d_cuda(
            x, weight, bias,
            batch_size, in_channels, out_channels,
            depth_in, height_in, width_in,
            depth_out, height_out, width_out,
            kernel_depth, kernel_height, kernel_width,
            stride_depth, stride_height, stride_width,
            padding_depth, padding_height, padding_width,
            output_padding_depth, output_padding_height, output_padding_width,
            groups)
