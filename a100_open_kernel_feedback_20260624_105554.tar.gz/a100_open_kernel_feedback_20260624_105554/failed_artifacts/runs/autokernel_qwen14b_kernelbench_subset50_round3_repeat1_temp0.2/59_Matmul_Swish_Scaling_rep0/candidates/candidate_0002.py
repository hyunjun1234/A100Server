import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void swish_kernel(const float* input, float* output, int N, float scaling_factor) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        float sigmoid_val = 1.0f / (1.0f + expf(-input[idx]));
        output[idx] = input[idx] * sigmoid_val * scaling_factor;
    }
}

torch::Tensor swish_cuda(torch::Tensor input, float scaling_factor) {
    auto output = torch::empty_like(input);
    int N = input.numel();
    swish_kernel<<<(N+255)/256, 256>>>(input.data_ptr<float>(), output.data_ptr<float>(), N, scaling_factor);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "swish_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scaling_factor):
        super().__init__()
        self.matmul = nn.Linear(in_features, out_features)
        self.scaling_factor = scaling_factor

    def forward(self, x):
        x = self.matmul(x)
        return _get_mod().swish_cuda(x, self.scaling_factor)
