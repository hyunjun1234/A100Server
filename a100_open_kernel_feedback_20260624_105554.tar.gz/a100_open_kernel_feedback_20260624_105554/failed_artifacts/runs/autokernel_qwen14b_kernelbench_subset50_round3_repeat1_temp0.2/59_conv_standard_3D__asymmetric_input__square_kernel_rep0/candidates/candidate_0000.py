import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv3d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int height, int width, int depth,
    int kernel_size, int stride, int padding, int dilation, int groups) {
    
    int b = blockIdx.x / (out_channels * (height_out * width_out));
    int oc = (blockIdx.x / (height_out * width_out)) % out_channels;
    int oh = (blockIdx.x / width_out) % height_out;
    int ow = blockIdx.x % width_out;

    int ih = oh * stride - padding;
    int iw = ow * stride - padding;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kh = 0; kh < kernel_size; ++kh) {
            for (int kw = 0; kw < kernel_size; ++kw) {
                if (ih + kh * dilation >= 0 && ih + kh * dilation < height &&
                    iw + kw * dilation >= 0 && iw + kw * dilation < width) {
                    int input_idx = b * in_channels * height * width * depth +
                                    ic * height * width * depth +
                                    (ih + kh * dilation) * width * depth +
                                    (iw + kw * dilation) * depth;
                    int weight_idx = oc * in_channels * kernel_size * kernel_size +
                                     ic * kernel_size * kernel_size +
                                     kh * kernel_size + kw;
                    sum += input[input_idx] * weight[weight_idx];
                }
            }
        }
    }

    int output_idx = b * out_channels * height_out * width_out +
                     oc * height_out * width_out +
                     oh * width_out + ow;
    output[output_idx] = sum + bias[oc];
}

torch::Tensor conv3d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int kernel_size, int stride, int padding, int dilation, int groups) {
    
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int out_channels = weight.size(0);
    int height = input.size(2);
    int width = input.size(3);
    int depth = input.size(4);

    int height_out = (height + 2 * padding - dilation * (kernel_size - 1) - 1) / stride + 1;
    int width_out = (width + 2 * padding - dilation * (kernel_size - 1) - 1) / stride + 1;

    auto output = torch::empty({batch_size, out_channels, height_out, width_out, depth}, input.options());

    dim3 threads(256);
    dim3 blocks((batch_size * out_channels * height_out * width_out + threads.x - 1) / threads.x);

    conv3d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        height, width, depth,
        kernel_size, stride, padding, dilation, groups);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv3d = nn.Conv3d(in_channels, out_channels, (kernel_size, kernel_size, 1), stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv3d.weight
        bias = self.conv3d.bias if self.conv3d.bias is not None else torch.zeros(weight.size(0), device=x.device)
        return _get_mod().conv3d_cuda(x, weight, bias, self.conv3d.kernel_size[0], self.conv3d.stride[0], self.conv3d.padding[0], self.conv3d.dilation[0], self.conv3d.groups)
