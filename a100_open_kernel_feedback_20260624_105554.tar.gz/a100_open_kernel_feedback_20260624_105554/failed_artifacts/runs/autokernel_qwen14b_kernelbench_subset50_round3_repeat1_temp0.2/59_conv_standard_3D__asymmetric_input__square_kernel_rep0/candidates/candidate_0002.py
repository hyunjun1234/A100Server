import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv3d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int height, int width, int depth,
    int kernel_size, int stride, int padding, int dilation, int groups) {
    
    int b = blockIdx.x / (out_channels * (height_out * width_out));
    int oc = (blockIdx.x % (out_channels * (height_out * width_out))) / (height_out * width_out);
    int oh = ((blockIdx.x % (out_channels * (height_out * width_out))) % (height_out * width_out)) / width_out;
    int ow = ((blockIdx.x % (out_channels * (height_out * width_out))) % (height_out * width_out)) % width_out;

    int ih_start = oh * stride - padding;
    int iw_start = ow * stride - padding;
    int id_start = 0;

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int kh = 0; kh < kernel_size; ++kh) {
            for (int kw = 0; kw < kernel_size; ++kw) {
                for (int kd = 0; kd < 1; ++kd) {
                    int ih = ih_start + kh * dilation;
                    int iw = iw_start + kw * dilation;
                    int id = id_start + kd * dilation;

                    if (ih >= 0 && ih < height && iw >= 0 && iw < width && id >= 0 && id < depth) {
                        int input_idx = (b * in_channels + ic) * height * width * depth + (ih * width + iw) * depth + id;
                        int weight_idx = (oc * in_channels + ic) * kernel_size * kernel_size * 1 + (kh * kernel_size + kw) * 1 + kd;
                        sum += input[input_idx] * weight[weight_idx];
                    }
                }
            }
        }
    }

    int output_idx = (b * out_channels + oc) * height_out * width_out + oh * width_out + ow;
    output[output_idx] = sum + bias[oc];
}

torch::Tensor conv3d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int height, int width, int depth,
    int kernel_size, int stride, int padding, int dilation, int groups) {
    
    auto output = torch::zeros({batch_size, out_channels, height_out, width_out}, input.options());
    int height_out = (height + 2 * padding - kernel_size) / stride + 1;
    int width_out = (width + 2 * padding - kernel_size) / stride + 1;

    dim3 threads(256);
    dim3 blocks((batch_size * out_channels * height_out * width_out + threads.x - 1) / threads.x);

    conv3d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        height, width, depth,
        kernel_size, stride, padding, dilation, groups);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv3d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv3d = nn.Conv3d(in_channels, out_channels, (kernel_size, kernel_size, 1), stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.weight = self.conv3d.weight
        self.bias = self.conv3d.bias if bias else torch.zeros(out_channels, device=self.weight.device)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, in_channels, height, width, depth = x.size()
        kernel_size = self.conv3d.kernel_size[0]
        stride = self.conv3d.stride[0]
        padding = self.conv3d.padding[0]
        dilation = self.conv3d.dilation[0]
        groups = self.conv3d.groups
        
        return _get_mod().conv3d_cuda(
            x, self.weight, self.bias,
            batch_size, in_channels, self.conv3d.out_channels,
            height, width, depth,
            kernel_size, stride, padding, dilation, groups)
