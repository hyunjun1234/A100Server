import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void conv_kernel(const float* input, const float* weight, float* output, int N, int C, int H, int W, int K, int S) {
    int b = blockIdx.x;
    int c = blockIdx.y;
    int h = blockIdx.z;
    int w = threadIdx.x;

    float sum = 0.0f;
    for (int kc = 0; kc < C; ++kc) {
        for (int kh = 0; kh < K; ++kh) {
            for (int kw = 0; kw < K; ++kw) {
                int in_h = h * S + kh;
                int in_w = w * S + kw;
                if (in_h >= 0 && in_h < H && in_w >= 0 && in_w < W) {
                    sum += input[b * C * H * W + kc * H * W + in_h * W + in_w] * weight[c * C * K * K + kc * K * K + kh * K + kw];
                }
            }
        }
    }
    output[b * N * H * W / S / S + c * H * W / S / S + h * W / S + w] = sum;
}

__global__ void avg_pool_kernel(const float* input, float* output, int N, int C, int H, int W, int P) {
    int b = blockIdx.x;
    int c = blockIdx.y;
    int h = blockIdx.z;
    int w = threadIdx.x;

    float sum = 0.0f;
    for (int ph = 0; ph < P; ++ph) {
        for (int pw = 0; pw < P; ++pw) {
            int in_h = h * P + ph;
            int in_w = w * P + pw;
            if (in_h >= 0 && in_h < H && in_w >= 0 && in_w < W) {
                sum += input[b * C * H * W + c * H * W + in_h * W + in_w];
            }
        }
    }
    output[b * C * H * W / P / P + c * H * W / P / P + h * W / P + w] = sum / (P * P);
}

__global__ void sigmoid_kernel(float* input, int N) {
    for (int i = blockIdx.x * blockDim.x + threadIdx.x; i < N; i += gridDim.x * blockDim.x) {
        input[i] = 1.0f / (1.0f + expf(-input[i]));
    }
}

__global__ void sum_kernel(const float* input, float* output, int N) {
    extern __shared__ float sdata[];
    unsigned int tid = threadIdx.x;
    unsigned int i = blockIdx.x * blockDim.x + threadIdx.x;
    sdata[tid] = (i < N) ? input[i] : 0.0f;
    __syncthreads();

    for (unsigned int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) {
            sdata[tid] += sdata[tid + s];
        }
        __syncthreads();
    }

    if (tid == 0) {
        output[blockIdx.x] = sdata[0];
    }
}

torch::Tensor conv_avg_pool_sigmoid_sum_cuda(torch::Tensor input, torch::Tensor weight, int kernel_size, int pool_kernel_size) {
    int N = input.size(0);
    int C = input.size(1);
    int H = input.size(2);
    int W = input.size(3);
    int K = kernel_size;
    int P = pool_kernel_size;
    int out_H = (H - K + 1) / 1;
    int out_W = (W - K + 1) / 1;
    int pool_out_H = out_H / P;
    int pool_out_W = out_W / P;

    auto conv_output = torch::empty({N, C, out_H, out_W}, input.options());
    auto pool_output = torch::empty({N, C, pool_out_H, pool_out_W}, input.options());
    auto sigmoid_output = torch::empty_like(pool_output);
    auto sum_output = torch::empty({N}, input.options());

    dim3 threads(256);
    dim3 blocks(N, C, pool_out_H);

    conv_kernel<<<blocks, threads>>>(input.data_ptr<float>(), weight.data_ptr<float>(), conv_output.data_ptr<float>(), N, C, H, W, K, 1);
    avg_pool_kernel<<<blocks, threads>>>(conv_output.data_ptr<float>(), pool_output.data_ptr<float>(), N, C, out_H, out_W, P);
    sigmoid_kernel<<<blocks, threads>>>(pool_output.data_ptr<float>(), N * C * pool_out_H * pool_out_W);
    sum_kernel<<<(N + 255) / 256, 256, sizeof(float) * 256>>>(sigmoid_output.data_ptr<float>(), sum_output.data_ptr<float>(), N * C * pool_out_H * pool_out_W);

    return sum_output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_avg_pool_sigmoid_sum_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, pool_kernel_size):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size)
        self.pool_kernel_size = pool_kernel_size

    def forward(self, x):
        weight = self.conv.weight.view(self.conv.out_channels, self.conv.in_channels, self.conv.kernel_size[0], self.conv.kernel_size[1])
        return _get_mod().conv_avg_pool_sigmoid_sum_cuda(x, weight, self.conv.kernel_size[0], self.pool_kernel_size)
