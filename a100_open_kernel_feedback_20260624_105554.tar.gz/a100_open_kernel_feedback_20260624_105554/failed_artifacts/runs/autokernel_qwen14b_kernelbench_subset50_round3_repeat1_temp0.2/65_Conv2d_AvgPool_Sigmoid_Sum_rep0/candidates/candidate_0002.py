import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>
#include <cmath>

__global__ void conv_kernel(const float* input, const float* weight, float* output, int N, int C, int H, int W, int K, int S) {
    int n = blockIdx.x;
    int c = blockIdx.y;
    int h = blockIdx.z;
    int w = threadIdx.x;

    if (n < N && c < C && h < H && w < W) {
        float sum = 0.0f;
        for (int kc = 0; kc < C; ++kc) {
            for (int kh = 0; kh < K; ++kh) {
                for (int kw = 0; kw < K; ++kw) {
                    int in_h = h * S + kh;
                    int in_w = w * S + kw;
                    if (in_h >= 0 && in_h < H && in_w >= 0 && in_w < W) {
                        sum += input[n * C * H * W + kc * H * W + in_h * W + in_w] * weight[c * C * K * K + kc * K * K + kh * K + kw];
                    }
                }
            }
        }
        output[n * C * H * W / (S * S) + c * H * W / (S * S) + h * W / S + w] = sum;
    }
}

__global__ void avg_pool_kernel(const float* input, float* output, int N, int C, int H, int W, int K, int S) {
    int n = blockIdx.x;
    int c = blockIdx.y;
    int h = blockIdx.z;
    int w = threadIdx.x;

    if (n < N && c < C && h < H && w < W) {
        float sum = 0.0f;
        for (int kh = 0; kh < K; ++kh) {
            for (int kw = 0; kw < K; ++kw) {
                int in_h = h * S + kh;
                int in_w = w * S + kw;
                if (in_h >= 0 && in_h < H && in_w >= 0 && in_w < W) {
                    sum += input[n * C * H * W + c * H * W + in_h * W + in_w];
                }
            }
        }
        output[n * C * H * W / (S * S) + c * H * W / (S * S) + h * W / S + w] = sum / (K * K);
    }
}

__global__ void sigmoid_kernel(const float* input, float* output, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        output[idx] = 1.0f / (1.0f + expf(-input[idx]));
    }
}

__global__ void sum_kernel(const float* input, float* output, int N) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < N) {
        atomicAdd(output, input[idx]);
    }
}

torch::Tensor conv_avg_pool_sigmoid_sum_cuda(torch::Tensor input, torch::Tensor weight, int N, int C, int H, int W, int K, int S) {
    auto output = torch::empty({N, C, H / S, W / S}, input.options());
    conv_kernel<<<dim3(N, C, H / S), W>>>(input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(), N, C, H, W, K, S);
    auto pooled_output = torch::empty({N, C, H / S / K, W / S / K}, input.options());
    avg_pool_kernel<<<dim3(N, C, H / S / K), W / K>>>(output.data_ptr<float>(), pooled_output.data_ptr<float>(), N, C, H / S, W / S, K, S);
    auto sigmoid_output = torch::empty_like(pooled_output);
    sigmoid_kernel<<<(N * C * H / S / K * W / S / K + 255) / 256, 256>>>(pooled_output.data_ptr<float>(), sigmoid_output.data_ptr<float>(), N * C * H / S / K * W / S / K);
    auto sum_output = torch::zeros({N}, input.options());
    sum_kernel<<<(N * C * H / S / K * W / S / K + 255) / 256, 256>>>(sigmoid_output.data_ptr<float>(), sum_output.data_ptr<float>(), N * C * H / S / K * W / S / K);
    return sum_output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_avg_pool_sigmoid_sum_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, pool_kernel_size):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size)
        self.avg_pool = nn.AvgPool2d(pool_kernel_size)

    def forward(self, x):
        weight = self.conv.weight.view(self.conv.out_channels, self.conv.in_channels, self.conv.kernel_size[0], self.conv.kernel_size[1])
        N, C, H, W = x.size()
        K, S = self.conv.kernel_size[0], self.conv.stride[0]
        return _get_mod().conv_avg_pool_sigmoid_sum_cuda(x, weight, N, C, H, W, K, S)
