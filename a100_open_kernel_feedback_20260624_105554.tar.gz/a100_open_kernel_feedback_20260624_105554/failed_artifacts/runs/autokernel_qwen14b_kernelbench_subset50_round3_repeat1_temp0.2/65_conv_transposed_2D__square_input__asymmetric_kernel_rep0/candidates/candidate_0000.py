import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose2d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels,
    int height, int width, int kernel_height, int kernel_width,
    int stride, int padding, int output_padding, int groups) {
    
    int b = blockIdx.x / (out_channels * (height + 2 * output_padding));
    int oc = (blockIdx.x / (height + 2 * output_padding)) % out_channels;
    int oy = blockIdx.x % (height + 2 * output_padding);

    int ix = oy * stride - padding;
    int iy = blockIdx.y * blockDim.x + threadIdx.x;

    if (iy < width + 2 * output_padding) {
        float sum = 0.0f;
        for (int ic = 0; ic < in_channels; ic++) {
            for (int kh = 0; kh < kernel_height; kh++) {
                for (int kw = 0; kw < kernel_width; kw++) {
                    int wx = ix + kw;
                    int wy = iy + kh;
                    if (wx >= 0 && wx < width && wy >= 0 && wy < height) {
                        int input_idx = b * in_channels * height * width + ic * height * width + wy * width + wx;
                        int weight_idx = oc * in_channels * kernel_height * kernel_width + ic * kernel_height * kernel_width + kh * kernel_width + kw;
                        sum += input[input_idx] * weight[weight_idx];
                    }
                }
            }
        }
        if (bias != nullptr) {
            sum += bias[oc];
        }
        int output_idx = b * out_channels * (height + 2 * output_padding) * (width + 2 * output_padding) + oc * (height + 2 * output_padding) * (width + 2 * output_padding) + oy * (width + 2 * output_padding) + iy;
        output[output_idx] = sum;
    }
}

torch::Tensor conv_transpose2d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int batch_size, int in_channels, int out_channels,
    int height, int width, int kernel_height, int kernel_width,
    int stride, int padding, int output_padding, int groups) {
    
    auto output = torch::zeros({batch_size, out_channels, height + 2 * output_padding, width + 2 * output_padding}, input.options());
    int threads = 256;
    int blocks_x = (out_channels * (height + 2 * output_padding) + threads - 1) / threads;
    int blocks_y = (width + 2 * output_padding + threads - 1) / threads;
    dim3 blocks(blocks_x, blocks_y);
    dim3 threads_per_block(threads);

    conv_transpose2d_kernel<<<blocks, threads_per_block>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels,
        height, width, kernel_height, kernel_width,
        stride, padding, output_padding, groups);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose2d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: int = 1, padding: int = 0, output_padding: int = 0, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv_transpose2d = nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, output_padding=output_padding, groups=groups, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.conv_transpose2d.weight
        bias = self.conv_transpose2d.bias if self.conv_transpose2d.bias is not None else torch.zeros(out_channels, device=x.device)
        batch_size, in_channels, height, width = x.size()
        kernel_height, kernel_width = self.conv_transpose2d.kernel_size
        stride = self.conv_transpose2d.stride[0]
        padding = self.conv_transpose2d.padding[0]
        output_padding = self.conv_transpose2d.output_padding[0]
        groups = self.conv_transpose2d.groups
        
        return _get_mod().conv_transpose2d_cuda(
            x, weight, bias,
            batch_size, in_channels, out_channels,
            height, width, kernel_height, kernel_width,
            stride, padding, output_padding, groups)
