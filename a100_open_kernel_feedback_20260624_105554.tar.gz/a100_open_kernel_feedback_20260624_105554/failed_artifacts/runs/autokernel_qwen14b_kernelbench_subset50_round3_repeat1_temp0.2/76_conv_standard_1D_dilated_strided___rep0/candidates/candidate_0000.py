import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv1d_kernel(
    const float* input, const float* weight, float* output,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int dilation
) {
    int b = blockIdx.x / (out_channels * ((length - kernel_size * dilation) / stride + 1));
    int oc = (blockIdx.x % (out_channels * ((length - kernel_size * dilation) / stride + 1))) / ((length - kernel_size * dilation) / stride + 1);
    int ow = blockIdx.x % ((length - kernel_size * dilation) / stride + 1);

    float sum = 0.0f;
    for (int ic = 0; ic < in_channels; ++ic) {
        for (int k = 0; k < kernel_size; ++k) {
            int iw = ow * stride + k * dilation;
            if (iw >= 0 && iw < length) {
                sum += input[b * in_channels * length + ic * length + iw] * weight[oc * in_channels * kernel_size + ic * kernel_size + k];
            }
        }
    }

    output[b * out_channels * ((length - kernel_size * dilation) / stride + 1) + oc * ((length - kernel_size * dilation) / stride + 1) + ow] = sum;
}

torch::Tensor conv1d_cuda(
    torch::Tensor input, torch::Tensor weight,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int dilation
) {
    auto output = torch::empty({batch_size, out_channels, (length - kernel_size * dilation) / stride + 1}, input.options());
    int num_threads = 256;
    int num_blocks = (batch_size * out_channels * ((length - kernel_size * dilation) / stride + 1) + num_threads - 1) / num_threads;
    conv1d_kernel<<<num_blocks, num_threads>>>(
        input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(),
        batch_size, in_channels, out_channels, length, kernel_size, stride, dilation
    );
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv1d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, dilation: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        self.conv1d = nn.Conv1d(in_channels, out_channels, kernel_size, stride=stride, dilation=dilation, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        try:
            weight = self.conv1d.weight.contiguous()
            bias = self.conv1d.bias.contiguous() if self.conv1d.bias is not None else None
            batch_size, in_channels, length = x.size()
            out_channels = self.conv1d.out_channels
            kernel_size = self.conv1d.kernel_size[0]
            stride = self.conv1d.stride[0]
            dilation = self.conv1d.dilation[0]
            
            output = _get_mod().conv1d_cuda(
                x, weight,
                batch_size, in_channels, out_channels, length,
                kernel_size, stride, dilation
            )
            
            if bias is not None:
                output += bias.view(1, -1, 1).expand_as(output)
            
            return output
        except Exception as e:
            print(f"CUDA kernel failed: {e}")
            return self.conv1d(x)
