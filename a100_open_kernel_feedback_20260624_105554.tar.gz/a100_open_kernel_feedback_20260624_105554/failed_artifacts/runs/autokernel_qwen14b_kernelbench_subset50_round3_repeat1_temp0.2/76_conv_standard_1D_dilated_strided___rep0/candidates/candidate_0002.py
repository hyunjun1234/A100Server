import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv1d_kernel(const float* input, const float* weight, float* output, int batch_size, int in_channels, int out_channels, int length, int kernel_size, int stride, int dilation) {
    int batch = blockIdx.x / (out_channels * ((length - kernel_size * dilation) / stride + 1));
    int out_channel = (blockIdx.x % (out_channels * ((length - kernel_size * dilation) / stride + 1))) / ((length - kernel_size * dilation) / stride + 1);
    int out_pos = blockIdx.x % ((length - kernel_size * dilation) / stride + 1);

    int in_start = out_pos * stride;
    float sum = 0.0f;

    for (int k = 0; k < kernel_size; ++k) {
        int in_pos = in_start + k * dilation;
        if (in_pos >= 0 && in_pos < length) {
            for (int c = 0; c < in_channels; ++c) {
                sum += input[batch * in_channels * length + c * length + in_pos] * weight[out_channel * in_channels * kernel_size + c * kernel_size + k];
            }
        }
    }

    output[batch * out_channels * ((length - kernel_size * dilation) / stride + 1) + out_channel * ((length - kernel_size * dilation) / stride + 1) + out_pos] = sum;
}

torch::Tensor conv1d_cuda(torch::Tensor input, torch::Tensor weight, int out_channels, int kernel_size, int stride, int dilation) {
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int length = input.size(2);
    int output_length = (length - kernel_size * dilation) / stride + 1;

    auto output = torch::zeros({batch_size, out_channels, output_length}, input.options());

    dim3 threads(256);
    dim3 blocks((batch_size * out_channels * output_length + threads.x - 1) / threads.x);

    conv1d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), weight.data_ptr<float>(), output.data_ptr<float>(),
        batch_size, in_channels, out_channels, length, kernel_size, stride, dilation);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv1d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, dilation: int = 1, bias: bool = False):
        super().__init__()
        self.conv1d = nn.Conv1d(in_channels, out_channels, kernel_size, stride=stride, dilation=dilation, bias=bias)
        self.weight = self.conv1d.weight.clone().detach().requires_grad_(False)
        if bias:
            self.bias = self.conv1d.bias.clone().detach().requires_grad_(False)
        else:
            self.bias = None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        output = _get_mod().conv1d_cuda(x, self.weight, self.conv1d.out_channels, self.conv1d.kernel_size[0], self.conv1d.stride[0], self.conv1d.dilation[0])
        if self.bias is not None:
            output += self.bias.view(1, -1, 1).expand_as(output)
        return output
