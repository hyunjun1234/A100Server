import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void conv_transpose1d_kernel(
    const float* input, float* output,
    const float* weight, const float* bias,
    int batch_size, int in_channels, int out_channels, int length,
    int kernel_size, int stride, int padding, int dilation) {
    
    int b = blockIdx.z;
    int c = blockIdx.y;
    int t = blockIdx.x * blockDim.x + threadIdx.x;

    if (t >= length) return;

    float sum = 0.0f;
    for (int k = 0; k < kernel_size; ++k) {
        int in_t = (t - padding - k * dilation) / stride;
        if (in_t >= 0 && in_t < length) {
            sum += input[b * in_channels * length + c * length + in_t] * weight[c * in_channels * kernel_size + k * in_channels + blockIdx.y];
        }
    }

    output[b * out_channels * length + c * length + t] = sum + (bias ? bias[c] : 0.0f);
}

torch::Tensor conv_transpose1d_cuda(
    torch::Tensor input, torch::Tensor weight, torch::Tensor bias,
    int kernel_size, int stride, int padding, int dilation) {
    
    auto output = torch::zeros_like(input, torch::dtype(torch::kFloat32));
    int batch_size = input.size(0);
    int in_channels = input.size(1);
    int out_channels = weight.size(0);
    int length = input.size(2);

    dim3 threads(256);
    dim3 blocks((length + threads.x - 1) / threads.x, out_channels, batch_size);

    conv_transpose1d_kernel<<<blocks, threads>>>(
        input.data_ptr<float>(), output.data_ptr<float>(),
        weight.data_ptr<float>(), bias.data_ptr<float>(),
        batch_size, in_channels, out_channels, length,
        kernel_size, stride, padding, dilation);

    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "conv_transpose1d_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, dilation: int = 1, bias: bool = False):
        super().__init__()
        self.conv1d_transpose = nn.ConvTranspose1d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, dilation=dilation, bias=bias)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if not x.is_cuda:
            return self.conv1d_transpose(x)
        
        weight = self.conv1d_transpose.weight
        bias = self.conv1d_transpose.bias if self.conv1d_transpose.bias is not None else torch.zeros(weight.size(0), device=x.device)
        return _get_mod().conv_transpose1d_cuda(x, weight, bias, self.conv1d_transpose.kernel_size[0], self.conv1d_transpose.stride[0], self.conv1d_transpose.padding[0], self.conv1d_transpose.dilation[0])
