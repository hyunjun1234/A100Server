import torch
import torch.nn as nn
from kernels.cuda._compile import compile_cuda

CUDA_SRC = r"""
#include <torch/extension.h>
#include <cuda_runtime.h>

__global__ void cumsum_kernel(const float* input, float* output, int N, int dim, int stride) {
    extern __shared__ float shared[];
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    int row = idx / stride;
    int col = idx % stride;

    if (col < stride) {
        shared[threadIdx.x] = (row < N) ? input[row * stride + col] : 0.0f;
    }
    __syncthreads();

    for (int s = 1; s < blockDim.x; s *= 2) {
        int index = threadIdx.x - s;
        if (index >= 0) {
            shared[threadIdx.x] += shared[index];
        }
        __syncthreads();
    }

    if (col < stride) {
        output[row * stride + col] = shared[threadIdx.x];
    }
}

torch::Tensor cumsum_cuda(torch::Tensor input, int dim) {
    int N = input.size(0);
    int stride = input.size(1);
    auto output = torch::empty_like(input);
    cumsum_kernel<<<(N * stride + 255) / 256, 256, 256 * sizeof(float)>>>(
        input.data_ptr<float>(), output.data_ptr<float>(), N, dim, stride);
    return output;
}
"""

_mod = None
def _get_mod():
    global _mod
    if _mod is None:
        _mod = compile_cuda(CUDA_SRC, "cumsum_cuda")
    return _mod

class ModelNew(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, x):
        if self.dim == 1:
            return _get_mod().cumsum_cuda(x, self.dim)
        else:
            return torch.cumsum(x, dim=self.dim)
