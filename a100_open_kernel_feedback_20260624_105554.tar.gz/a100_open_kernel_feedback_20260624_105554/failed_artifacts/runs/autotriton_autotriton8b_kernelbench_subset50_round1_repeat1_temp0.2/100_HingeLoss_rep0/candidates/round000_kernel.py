class ModelNew(torch.nn.Module):
         def __init__(self):
             super().__init__()

         def forward(self, predictions, targets):
             # Ensure inputs are contiguous and on the same device
             predictions = predictions.contiguous()
             targets = targets.contiguous()
             n_elements = predictions.numel()

             # If there are no elements, return 0
             if n_elements == 0:
                 return torch.tensor(0.0, device=predictions.device)

             # Allocate output tensor for the total sum (scalar)
             total_sum = torch.zeros(1, device=predictions.device, dtype=torch.float32)

             # Define the block size. We can choose 1024 as a common block size.
             BLOCK_SIZE = 1024
             grid = lambda meta: (triton.cdiv(n_elements, meta['BLOCK_SIZE']),)

             # Launch the kernel
             triton_hing
