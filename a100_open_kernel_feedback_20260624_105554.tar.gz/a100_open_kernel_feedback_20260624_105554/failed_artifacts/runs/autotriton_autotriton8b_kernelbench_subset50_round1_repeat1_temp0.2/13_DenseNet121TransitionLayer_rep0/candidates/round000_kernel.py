import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

@triton.jit
def avg_pool2d_kernel(
    input_ptr, output_ptr,
    input_batch_stride, input_channel_stride, input_height_stride, input_width_stride,
    output_batch_stride, output_channel_stride, output_height_stride, output_width_stride,
    input_channel, input_height, input_width,
    output_channel, output_height, output_width,
    BLOCK_SIZE: tl.constexpr
):
    pid = tl.program_id(0)
    num_pid_channels = tl.cdiv(input_channel, BLOCK_SIZE)
    pid_channel = pid // (output_height * output_width)
    pid_batch = (pid // (output_channel * output_height * output_width)) % BLOCK_SIZE
    pid_hw = pid % (output_height * output_width)
    pid_h = pid_hw // output_width
    pid_w = pid_hw % output_width

    c_offset = pid_channel * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    c_mask = c_offset < input_channel
    h_offset = (pid_h * 2 + tl.arange(0, 2)) % input_height
    w_offset = (pid_w * 2 + tl.arange(0, 2)) % input_width

    input_offsets = (
        (pid_batch * input_batch_stride + c_offset[:, None, None] * input_channel_stride +
         h_offset[None, :, None] * input_height_stride +
         w_offset[None, None, :] * input_width_stride)
    )
    input_values = tl.load(input_ptr + input_offsets, mask=c_mask[:, None, None], other=0.0)
    sum_values = tl.sum(input_values, axis=(1, 2))
    output_value = sum_values / 4.0

    output_offset = (
        pid_batch * output_batch_stride +
        c_offset * output_channel_stride +
        pid_h * output_height_stride +
        pid_w * output_width_stride
    )
    tl.store(output_ptr + output_offset, output_value, mask=c_mask)

class ModelNew(nn.Module):
    def __init__(self, num_input_features: int, num_output_features: int):
        super(ModelNew, self).__init__()
        self.transition = nn.Sequential(
            nn.BatchNorm2d(num_input_features),
            nn.ReLU(inplace=True),
            nn.Conv2d(num_input_features, num_output_features, kernel_size=1, bias=False),
        )
        self.num_input_features = num_input_features
        self.num_output_features = num_output_features

    def forward(self, x):
        batch_size, _, height, width = x.shape
        x = self.transition[0](x)
        x = self.transition[1](x)
        x = self.transition[2](x)
        
        output_height, output_width = height // 2, width // 2
        output = torch.empty((batch_size, self.num_output_features, output_height, output_width), device=x.device, dtype=x.dtype)
        
        grid = lambda meta: (batch_size * self.num_output_features * output_height * output_width,)
        avg_pool2d_kernel[grid](
            x, output,
            x.stride(0), x.stride(1), x.stride(2), x.stride(3),
            output.stride(0), output.stride(1), output.stride(2), output.stride(3),
            self.num_output_features, height, width,
            self.num_output_features, output_height, output_width,
            BLOCK_SIZE=16
        )
        return output
