class ModelNew". We are allowed to have helper functions.

  However, the problem says "Use CUDA/Triton/custom kernels if useful". It doesn't say we must replace the entire model with Triton. Only the mean operation? But the mean operation is the critical part.

  Alternatively, we can use a single kernel that does the entire reduction for each row in one block? But that would require the row length to be <= 1024. Which is not the case (49152). So we cannot.

  Therefore, we break the problem:

  Step 1: Flatten the input to (batch_size, N) where N = out_channels * D * H * W.
  Step 2: Allocate two arrays: `partial_sums` of shape (batch_size, num_blocks) and `partial_counts` of shape (batch_size, num_blocks), where num_blocks is the number of blocks we launch for the reduction. We choose num_blocks such that each block handles a chunk of size `BLOCK_SIZE = 1024` (or another power of two) except the last which might be smaller.

  Step 3: Launch kernel1 that each block i (for a given batch index b) computes the sum of a chunk of the row b and stores it in partial_sums[b, i] and the count (which is the number of elements in the chunk, i.e., BLOCK_SIZE except for the last) in partial_counts[b, i].

  Step 4: Launch kernel2 that for each batch index b, sums up all the partial_sums[b, :] and partial_counts[b, :] to get total_sum and total_count, then computes mean = total_sum / total_count.

  But note: kernel2 would be launched with batch_size blocks, each block handling one row. And each block would reduce num_blocks elements. If num_blocks is large (e.g., 49152/1024 ~ 48) then each block would have
