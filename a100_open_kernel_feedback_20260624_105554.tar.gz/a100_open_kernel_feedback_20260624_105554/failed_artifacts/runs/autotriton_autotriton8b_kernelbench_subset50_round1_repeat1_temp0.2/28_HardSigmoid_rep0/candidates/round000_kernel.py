import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_hardsigmoid(x_ptrs, out_ptrs, xnumel, XBLOCK : tl.constexpr):
    pid = tl.program_id(0) 
    offsets = pid * XBLOCK + tl.arange(0, XBLOCK)[:]
    x_mask = offsets < xnumel
    x = tl.load(x_ptrs + offsets, mask=x_mask)
    zero = 0.0
    three = 3.0
    six = 6.0
    x_plus_three = x + three
    clamped = tl.maximum(tl.minimum(x_plus_three / six, one := 1.0), zero)
    tl.store(out_ptrs + offsets, clamped, mask=x_mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        output = torch.empty_like(x)
        XBLOCK = 1024
        grid = (triton.cdiv(x.numel(), XBLOCK),)
        triton_hardsigmoid[grid](x, output, x.numel(), XBLOCK)
        return output

batch_size = 4096
dim = 393216

def get_inputs():
    x = torch.rand(batch_size, dim)
    return [x]

def get_init_inputs():
    return []
