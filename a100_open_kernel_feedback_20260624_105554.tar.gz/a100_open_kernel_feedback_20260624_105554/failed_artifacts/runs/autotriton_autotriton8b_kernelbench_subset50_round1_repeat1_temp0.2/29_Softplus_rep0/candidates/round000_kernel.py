import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def softplus_kernel(
    input_ptr,
    output_ptr,
    num_elements,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    block_start = pid * BLOCK_SIZE
    offsets = block_start + tl.arange(0, BLOCK_SIZE)
    mask = offsets < num_elements
    x = tl.load(input_ptr + offsets, mask=mask)
    threshold = 20.0
    y = tl.where(x > threshold, x, tl.log(1.0 + tl.exp(x)))
    tl.store(output_ptr + offsets, y, mask=mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_contig = x.contiguous()
        output = torch.empty_like(x_contig)
        num_elements = output.numel()
        if num_elements == 0:
            return output
        BLOCK_SIZE = 1024
        grid = lambda meta: (triton.cdiv(num_elements, meta['BLOCK_SIZE']),)
        softplus_kernel[grid](x_contig, output, num_elements, BLOCK_SIZE=BLOCK_SIZE)
        return output
