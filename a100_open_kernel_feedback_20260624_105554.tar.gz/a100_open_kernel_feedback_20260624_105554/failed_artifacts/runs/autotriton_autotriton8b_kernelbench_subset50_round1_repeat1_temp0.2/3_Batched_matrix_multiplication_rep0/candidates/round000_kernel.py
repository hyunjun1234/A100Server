pid_batch = tl.program_id(0)
pid_m = tl.program_id(1)
pid_n = tl.program_id(2)

# Check if batch index is within batch_size
if pid_batch >= batch_size:
    return

rm = pid_m * BLOCK_SIZE_M
rn = pid_n * BLOCK_SIZE_N
