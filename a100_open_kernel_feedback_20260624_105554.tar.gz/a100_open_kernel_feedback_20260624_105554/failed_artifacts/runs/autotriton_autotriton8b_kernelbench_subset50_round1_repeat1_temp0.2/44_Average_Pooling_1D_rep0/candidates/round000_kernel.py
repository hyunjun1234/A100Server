import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_avg_pool1d(x_ptrs, out_ptrs, ks0, ks1, ks2, ks3, xnumel, XBLOCK : tl.constexpr):
    pid = tl.program_id(0) 
    offsets = pid * XBLOCK + tl.arange(0, XBLOCK)[:]
    x_mask = offsets < xnumel
    x2 = offsets
    x1 = x2 // ks0
    x0 = x2 % ks0
    output_index = x0
    batch_index = x1 // ks0
    channel_index = x1 % ks0
    start = output_index * ks2 - ks3
    end = start + ks1
    sum_value = tl.zeros((XBLOCK,), dtype=tl.float32)
    for i in range(0, ks1):
        pos = start + i
        valid = (pos >= 0) & (pos < ks0)
        index = batch_index * ks0 * ks0 + channel_index * ks0 + tl.where(valid, pos, 0)
        value = tl.load(x_ptrs + index, mask=valid & x_mask, other=0.0)
        sum_value += value
    avg_value = sum_value / ks1
    output_offset = batch_index * ks0 * ks0 + channel_index * ks0 + output_index
    tl.store(out_ptrs + output_offset, avg_value, mask=x_mask)

class ModelNew(nn.Module):
    """
    Custom 1D Average Pooling layer implemented using Triton.
    """
    def __init__(self, kernel_size: int, stride: int = 1, padding: int = 0):
        """
        Initializes the 1D Average Pooling layer.

        Args:
            kernel_size (int): Size of the pooling window.
            stride (int, optional): Stride of the pooling operation. Defaults to 1.
            padding (int, optional): Padding applied to the input tensor. Defaults to 0.
        """
        super(ModelNew, self).__init__()
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Applies 1D Average Pooling to the input tensor using a Triton kernel.

        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, in_channels, input_length).

        Returns:
            torch.Tensor: Output tensor with 1D Average Pooling applied, shape (batch_size, in_channels, output_length).
        """
        batch_size, in_channels, input_length = x.shape
        output_length = (input_length + 2 * self.padding - self.kernel_size) // self.stride + 1
        output = torch.empty((batch_size, in_channels, output_length), device=x.device, dtype=x.dtype)
        xnumel = batch_size * in_channels * output_length
        XBLOCK = 1024
        grid = (triton.cdiv(xnumel, XBLOCK),)
        triton_avg_pool1d[grid](
            x, output, input_length, self.kernel_size, self.stride, self.padding, xnumel, XBLOCK
        )
        return output
