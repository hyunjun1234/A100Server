import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_scale(x_ptrs, out_ptrs, xnumel, scalar, XBLOCK : tl.constexpr):
    pid = tl.program_id(0) 
    offsets = pid * XBLOCK + tl.arange(0, XBLOCK)[:]
    x_mask = offsets < xnumel
    x = tl.load(x_ptrs + offsets, mask=x_mask)
    out = x * scalar
    tl.store(out_ptrs + offsets, out, mask=x_mask)

def triton_scale_func(x, scalar):
    if not x.is_cuda:
        return x * scalar
    output = torch.empty_like(x)
    XBLOCK = 1024
    grid = (triton.cdiv(x.numel(), XBLOCK),)
    triton_scale[grid](x, output, x.numel(), scalar, XBLOCK)
    return output

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scaling_factor, hardtanh_min, hardtanh_max):
        super(ModelNew, self).__init__()
        self.gemm = nn.Linear(in_features, out_features)
        self.scaling_factor = scaling_factor
        self.hardtanh = nn.Hardtanh(min_val=hardtanh_min, max_val=hardtanh_max)
        self.gelu = nn.GELU()

    def forward(self, x):
        x = self.gemm(x)
        x = triton_scale_func(x, self.scaling_factor)
        x = self.hardtanh(x)
        x = self.gelu(x)
        return x

batch_size = 2048
in_features = 8192
out_features = 8192
scaling_factor = 0.5
hardtanh_min = -2
hardtanh_max = 2

def get_inputs():
    return [torch.rand(batch_size, in_features)]

def get_init_inputs():
    return [in_features, out_features, scaling_factor, hardtanh_min, hardtanh_max]
