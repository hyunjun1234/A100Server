import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_conv_transpose2d(
    in_ptr, weight_ptr, out_ptr,
    ks0, ks1,
    in_channels, out_channels, kernel_size,
    input_height, input_width,
    output_height, output_width,
    XBLOCK: tl.constexpr
):
    pid = tl.program_id(0)
    num_pid = tl.num_programs(0)
    total_elements = out_channels * output_height * output_width
    start_idx = pid * XBLOCK
    offsets = start_idx + tl.arange(0, XBLOCK)
    mask = offsets < total_elements
    
    c_out = offsets // (output_height * output_width)
    spatial_idx = offsets % (output_height * output_width)
    y = spatial_idx // output_width
    x = spatial_idx % output_width
    
    acc = tl.zeros((XBLOCK,), dtype=tl.float32)
    for i in range(0, kernel_size):
        for j in range(0, kernel_size):
            wy = kernel_size - 1 - i
            wx = kernel_size - 1 - j
            up_y = y + i - ks0
            up_x = x + j - ks1
            if up_y >= 0 and up_x >= 0 and up_y < input_height and up_x < input_width:
                for ic in range(0, in_channels):
                    in_offset = (c_out * in_channels + ic) * input_height * input_width + up_y * input_width + up_x
                    weight_offset = (c_out * kernel_size * kernel_size + wy * kernel_size + wx) * in_channels + ic
                    in_val = tl.load(in_ptr + in_offset, mask=mask, other=0.0)
                    weight_val = tl.load(weight_ptr + weight_offset, mask=mask, other=0.0)
                    acc += in_val * weight_val
    
    out_offset = offsets
    tl.store(out_ptr + out_offset, acc, mask=mask)

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int, stride: int = 1, padding: int = 0, output_padding: int = 0, groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        if groups != 1:
            raise ValueError("This implementation only supports groups=1")
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.output_padding = output_padding
        self.groups = groups
        self.bias = bias
        
        self.weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size, kernel_size))
        if bias:
            self.bias_param = nn.Parameter(torch.randn(out_channels))
        else:
            self.bias_param = None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        input_height, input_width = x.shape[2], x.shape[3]
        output_height = self.stride * (input_height - 1) - 2 * self.padding + self.kernel_size + self.output
