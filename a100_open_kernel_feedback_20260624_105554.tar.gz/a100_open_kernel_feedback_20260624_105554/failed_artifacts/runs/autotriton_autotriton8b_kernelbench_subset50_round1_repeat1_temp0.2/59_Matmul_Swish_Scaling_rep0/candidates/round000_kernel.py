import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_swish_scale(x_ptrs, out_ptrs, xnumel, scaling_factor, XBLOCK : tl.constexpr):
    pid = tl.program_id(0) 
    offsets = pid * XBLOCK + tl.arange(0, XBLOCK)[:]
    x_mask = offsets < xnumel
    x = tl.load(x_ptrs + offsets, mask=x_mask)
    swish = x * tl.sigmoid(x)
    out = swish * scaling_factor
    tl.store(out_ptrs + offsets, out, mask=x_mask)

class ModelNew(nn.Module):
    def __init__(self, in_features, out_features, scaling_factor):
        super(ModelNew, self).__init__()
        self.matmul = nn.Linear(in_features, out_features)
        self.scaling_factor = scaling_factor

    def forward(self, x):
        x = self.matmul(x)
        x = x.contiguous()
        output = torch.empty_like(x)
        XBLOCK = 1024
        grid = (triton.cdiv(x.numel(), XBLOCK),)
        triton_swish_scale[grid](x, output, x.numel(), self.scaling_factor, XBLOCK)
        return output
