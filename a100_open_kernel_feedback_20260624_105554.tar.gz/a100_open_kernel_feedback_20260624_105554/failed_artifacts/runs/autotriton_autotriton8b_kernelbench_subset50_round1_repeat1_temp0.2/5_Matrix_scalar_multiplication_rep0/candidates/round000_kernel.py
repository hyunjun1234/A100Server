import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_mul_kernel(
    a_ptr,
    c_ptr,
    s,
    numel,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < numel
    a = tl.load(a_ptr + offsets, mask=mask)
    c = a * s
    tl.store(c_ptr + offsets, c, mask=mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, s: float) -> torch.Tensor:
        assert A.is_cuda, "Input tensor A must be on CUDA device"
        C = torch.empty_like(A)
        numel = A.numel()
        grid = lambda meta: (triton.cdiv(numel, meta['BLOCK_SIZE']),)
        triton_mul_kernel[grid](
            A, C, float(s), numel, BLOCK_SIZE=1024
        )
        return C
