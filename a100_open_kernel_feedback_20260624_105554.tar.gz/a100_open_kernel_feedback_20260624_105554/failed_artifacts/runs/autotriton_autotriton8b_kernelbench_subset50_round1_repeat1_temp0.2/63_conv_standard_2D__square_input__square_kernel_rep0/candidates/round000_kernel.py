import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def conv2d_kernel(
    input_ptr, weight_ptr, output_ptr,
    batch_size, in_channels, out_channels,
    height, width, kernel_size,
    height_out, width_out,
    input_batch_stride, input_channel_stride, input_height_stride, input_width_stride,
    weight_out_channel_stride, weight_in_channel_stride, weight_height_stride, weight_width_stride,
    output_batch_stride, output_channel_stride, output_height_stride, output_width_stride,
    BLOCK_SIZE: tl.constexpr
):
    pid = tl.program_id(0)
    num_pid = tl.num_programs(0)
    total_elements = batch_size * out_channels * height_out * width_out
    # Each program handles BLOCK_SIZE elements, but we can also have each program handle one element for simplicity if total_elements is large.
    # Instead, we use a grid stride loop.
    for idx in range(pid * BLOCK_SIZE, total_elements, num_pid * BLOCK_SIZE):
        if idx >= total_elements:
            break
        # Decode idx into b, c_out, h_out, w_out
        tmp = idx
        w_out = tmp % width_out
        tmp //= width_out
        h_out = tmp % height_out
        tmp //= height_out
        c_out = tmp % out_channels
        b = tmp // out_channels
        
        # Compute the start indices in the input for this output element
        h_start = h_out
        w_start = w_out
        acc = 0.0
        for c_in in range(in_channels):
            for kh in range(kernel_size):
                for kw in range(kernel_size):
                    h_in = h_start + kh
                    w_in = w_start + kw
                    if h_in < height and w_in < width:
                        input_offset = b * input_batch_stride + c_in * input_channel_stride + h_in * input_height_stride + w_in * input_width_stride
                        weight_offset = c_out * weight_out_channel_stride + c_in * weight_in_channel_stride + kh * weight_height_stride + kw * weight_width_stride
                        input_val = tl.load(input_ptr + input_offset)
                        weight_val = tl.load(weight_ptr + weight_offset)
                        acc += input_val * weight_val
        # Add bias if needed (but we are not handling bias in the kernel, so we assume bias is added later)
        # Instead, we'll handle bias outside the kernel in the forward pass.
        output_offset = b * output_batch_stride + c_out * output_channel_stride + h_out * output_height_stride + w_out * output_width_stride
        tl.store(output_ptr + output_offset, acc)
