import torch
import torch.nn as nn
import torch.nn.functional as F
import triton
import triton.language as tl

@triton.jit
def upsample_kernel(
    input_ptr, output_ptr,
    input_batch_stride, input_channel_stride, input_height_stride, input_width_stride,
    output_batch_stride, output_channel_stride, output_height_stride, output_width_stride,
    batch_size, in_channels, height_in, width_in,
    stride_h, stride_w,
    BLOCK_SIZE: tl.constexpr
):
    pid = tl.program_id(0)
    num_pid_h = tl.cdiv(height_in, BLOCK_SIZE)
    num_pid_w = tl.cdiv(width_in, BLOCK_SIZE)
    pid_batch = pid // (num_pid_h * num_pid_w)
    remainder = pid % (num_pid_h * num_pid_w)
    pid_h = remainder // num_pid_w
    pid_w = remainder % num_pid_w

    offs_h = pid_h * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    offs_w = pid_w * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask_h = offs_h < height_in
    mask_w = offs_w < width_in
    mask = mask_h[:, None] & mask_w[None, :]

    input_offsets = (
        pid_batch * input_batch_stride +
        offs_h[:, None] * input_height_stride +
        offs_w[None, :] * input_width_stride
    )
    input_values = tl.load(input_ptr + input_offsets, mask=mask, other=0.0)

    output_offsets_base = (
        pid_batch * output_batch_stride +
        offs_h[:, None] * stride_h * output_height_stride +
        offs_w[None, :] * stride_w * output_width_stride
    )
    output_offsets = output_offsets_base[:, :, None] + output_channel_stride * tl.arange(0, in_channels)[None, None, :]

    for c in range(in_channels):
        output_offset = output_offsets[:, :, c]
        tl.store(output_ptr + output_offset, input_values, mask=mask)

class ModelNew(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: tuple, stride: tuple = (1, 1), padding: tuple = (0, 0), output_padding: tuple = (0, 0), dilation: tuple = (1, 1), groups: int = 1, bias: bool = False):
        super(ModelNew, self).__init__()
        assert groups == 1, "Groups > 1 is not supported in this implementation"
        assert dilation == (1, 1), "Dilation != (1, 1) is not supported in this implementation"
        
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.output_padding = output_padding
        self.dilation = dilation
        self.groups = groups
        
        self.weight = nn.Parameter(torch.Tensor(out_channels, in_channels // groups, *kernel_size))
        if bias:
            self.bias = nn.Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=5**0.5)
        if self.bias is not None:
            fan_in, _ = nn.init
