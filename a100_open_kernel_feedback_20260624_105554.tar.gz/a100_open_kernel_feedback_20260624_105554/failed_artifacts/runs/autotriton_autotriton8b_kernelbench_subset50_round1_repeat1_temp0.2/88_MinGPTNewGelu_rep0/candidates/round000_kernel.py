import torch
import torch.nn as nn
import triton
import triton.language as tl
from triton.language.extra import libdevice

@triton.jit
def triton_gelu_kernel(
    x_ptr,
    output_ptr,
    n_elements,
    XBLOCK: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    block_start = pid * XBLOCK
    offsets = block_start + tl.arange(0, XBLOCK)
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask)
    
    c0 = 0.5
    c1 = 0.7978845608028654
    c2 = 0.044715
    
    x_cubed = x * x * x
    temp = x + c2 * x_cubed
    temp = c1 * temp
    temp = libdevice.tanh(temp)
    output = c0 * x * (1.0 + temp)
    
    tl.store(output_ptr + offsets, output, mask=mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, x):
        output = torch.empty_like(x)
        n_elements = output.numel()
        grid = lambda meta: (triton.cdiv(n_elements, meta['XBLOCK']),)
        triton_gelu_kernel[grid](x, output, n_elements, XBLOCK=1024)
        return output
