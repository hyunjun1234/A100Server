import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def matmul_kernel(
    a_ptr, b_ptr, c_ptr,
    M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    BLOCK_SIZE_M: tl.constexpr, BLOCK_SIZE_N: tl.constexpr, BLOCK_SIZE_K: tl.constexpr
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    
    offs_m = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_n = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    
    a_mask = (offs_m[:, None] < M) & (offs_k[None, :] < K)
    b_mask = (offs_k[:, None] < K) & (offs_n[None, :] < N)
    c_mask = (offs_m[:, None] < M) & (offs_n[None, :] < N)
    
    acc = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        a = tl.load(
            a_ptr + (offs_m[:, None] * stride_am + (k * BLOCK_SIZE_K + offs_k[None, :]) * stride_ak),
            mask=a_mask, other=0.0
        )
        b = tl.load(
            b_ptr + ((k * BLOCK_SIZE_K + offs_k[:, None]) * stride_bk + offs_n[None, :] * stride_bn),
            mask=b_mask, other=0.0
        )
        acc += tl.dot(a, b, allow_tf32=True)
    
    c = tl.where(c_mask, acc, 0.0)
    tl.store(
        c_ptr + (offs_m[:, None] * stride_cm + offs_n[None, :] * stride_cn),
        c, mask=c_mask
    )

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        assert A.is_cuda and B.is_cuda, "Inputs must be on CUDA"
        M, K = A.shape
        K_, N = B.shape
        assert K == K_, "Incompatible dimensions for matrix multiplication"
        
        C = torch.empty((M, N), device=A.device, dtype=A.dtype)
        
        BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K = 64, 64, 32
        grid = (
            triton.cdiv(M, BLOCK_SIZE_M),
            triton.cdiv(N, BLOCK_SIZE_N)
        )
        
        matmul_kernel[grid](
            A, B, C,
            M, N, K,
            A.stride(0), A.stride(1),
            B.stride(0), B.stride(1),
            C.stride(0), C.stride(1),
            BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K
        )
        return C
