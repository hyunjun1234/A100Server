import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def bmm_kernel(
    a_ptr, b_ptr, c_ptr,
    batch_size, m, k, n,
    stride_Ab, stride_Ak,
    stride_Bk, stride_Bn,
    stride_Cb, stride_Cm, stride_Cn,
    M: tl.constexpr, N: tl.constexpr, K: tl.constexpr
):
    pid_batch = tl.program_id(0)
    pid_m = tl.program_id(1)
    pid_n = tl.program_id(2)
    
    offs_batch = pid_batch
    offs_m = pid_m * M + tl.arange(0, M)[:, None]
    offs_n = pid_n * N + tl.arange(0, N)[None, :]
    offs_k = tl.arange(0, K)
    
    a_ptrs = a_ptr + offs_batch * stride_Ab + (offs_m[:, None] * stride_Ak + offs_k[None, :, None])
    b_ptrs = b_ptr + offs_batch * stride_Bk + (offs_k[:, None] * stride_Bn + offs_n[None, :])
    
    accumulator = tl.zeros((M, N), dtype=tl.float32)
    for k_idx in range(0, k, K):
        k_remaining = k - k_idx
        k_step = min(K, k_remaining)
        a = tl.load(a_ptrs, mask=offs_k[None, :k_step, None] < k_remaining, other=0.0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        accumulator += tl.dot(a, b, allow_tf32=True)
        a_ptrs += K * stride_Ak
        b_ptrs += K * stride_Bn
    
    c_ptrs = c_ptr + offs_batch * stride_Cb + (offs_m[:, None] * stride_Cm + offs_n[None, :])
    c_mask = (offs_m < m)[:, None] & (offs_n < n)[None, :]
    tl.store(c_ptrs, accumulator, mask=c_mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        batch_size, m, k = A.shape
        _, k_, n = B.shape
        assert k == k_, "Incompatible dimensions for matrix multiplication"
        C = torch.empty((batch_size, m, n), device=A.device, dtype=A.dtype)
        
        M = 64
        N = 64
        K = 32
        grid = (
            batch_size,
            triton.cdiv(m, M),
            triton.cdiv(n, N)
        )
        
        bmm_kernel[grid](
            A, B, C,
            batch_size, m, k, n,
            A.stride(0), A.stride(1),
            B.stride(0), B.stride(1),
            C.stride(0), C.stride(1), C.stride(2),
            M, N, K
        )
        return C
