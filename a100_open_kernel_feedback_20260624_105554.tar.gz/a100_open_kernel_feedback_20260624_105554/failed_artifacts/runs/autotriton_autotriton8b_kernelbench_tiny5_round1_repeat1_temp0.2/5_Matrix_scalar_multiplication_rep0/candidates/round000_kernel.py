import torch
import torch.nn as nn
import triton
import triton.language as tl

@triton.jit
def triton_mat_scalar_mul(A, C, s, numel, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(0)
    start_idx = pid * BLOCK_SIZE
    offsets = start_idx + tl.arange(0, BLOCK_SIZE)
    mask = offsets < numel
    a = tl.load(A + offsets, mask=mask)
    c = a * s
    tl.store(C + offsets, c, mask=mask)

class ModelNew(nn.Module):
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, s: float) -> torch.Tensor:
        assert A.is_cuda, "Input tensor A must be on CUDA device"
        numel = A.numel()
        C = torch.empty_like(A)
        grid = lambda meta: (triton.cdiv(numel, meta['BLOCK_SIZE']),)
        triton_mat_scalar_mul[grid](A, C, s, numel, BLOCK_SIZE=1024)
        return C

def get_inputs():
    M = 16384 * 4
    N = 4096 * 4
    A = torch.rand(M, N, device='cuda')
    s = 3.14
    return [A, s]

def get_init_inputs():
    return []
