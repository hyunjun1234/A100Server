import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs a HardSigmoid activation.
    """
    def __init__(self):
        super(ModelNew, self).__init__()
        self.activation = nn.Hardsigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Applies HardSigmoid activation to the input tensor.

        Args:
            x (torch.Tensor): Input tensor of any shape.

        Returns:
            torch.Tensor: Output tensor with HardSigmoid applied, same shape as input.
        """
        return self.activation(x)

batch_size = 4096
dim = 393216

def get_inputs():
    x = torch.rand(batch_size, dim)
    return [x]

def get_init_inputs():
    return []  # No special initialization inputs needed