import torch
import torch.nn as nn

class ModelNew(nn.Module):
    """
    Optimized model that performs a single matrix multiplication (C = A * B) with a small K dimension.
    This version includes some optimizations for better performance.
    """
    def __init__(self):
        super(ModelNew, self).__init__()
    
    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs matrix multiplication.

        Args:
            A: Input tensor of shape (M, K).
            B: Input tensor of shape (K, N).

        Returns:
            Output tensor of shape (M, N).
        """
        # Ensure tensors are on the same device
        A, B = A.to(B.device), B.to(A.device)
        
        # Perform matrix multiplication
        return torch.matmul(A, B)

M = 16384 * 2
N = 16384 * 2
K = 32 * 2

def get_inputs():
    A = torch.rand(M, K)
    B = torch.rand(K, N)
    return [A, B]

def get_init_inputs():
    return []  # No special initialization inputs needed