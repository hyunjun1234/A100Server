import torch
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import grid
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import torch.nn as nn
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor


@triton.jit
def triton_poi_fused__unsafe_view_clone_0(in_ptr0, out_ptr0, ynumel, xnumel,
    YBLOCK: tl.constexpr, XBLOCK: tl.constexpr):
    ynumel = 256
    xnumel = 8192
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[None, :]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    x1 = xindex
    y0 = yindex
    tmp0 = tl.load(in_ptr0 + (8192 * (y0 // 8192) + 32768 * (x1 // 2048) +
        262144 * (y0 % 8192) + x1 % 2048), xmask & ymask,
        eviction_policy='evict_last')
    tl.store(out_ptr0 + (x1 + 8192 * y0), tmp0, xmask & ymask)


def call(args):
    arg0_1, arg1_1 = args
    args.clear()
    assert_size_stride(arg0_1, (32768, 8192), (8192, 1))
    assert_size_stride(arg1_1, (65536, 8192), (8192, 1))
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        buf0 = empty_strided_cuda((256, 8192), (8192, 1), torch.float32)
        get_raw_stream(0)
        triton_poi_fused__unsafe_view_clone_0[grid(256, 8192)](arg0_1,
            buf0, 256, 8192, XBLOCK=1024, YBLOCK=1, num_warps=4, num_stages=1)
        del arg0_1
        buf1 = empty_strided_cuda((256, 65536), (65536, 1), torch.float32)
        extern_kernels.mm(buf0, reinterpret_tensor(arg1_1, (8192, 65536), (
            1, 8192), 0), out=buf1)
        del arg1_1
        del buf0
    return reinterpret_tensor(buf1, (1024, 64, 64), (4096, 64, 1), 0),


class ModelNew(nn.Module):
    """
    Simple model that performs a single matrix multiplication (C = A * B)
    """
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, arg0_1, arg1_1):
        arg0_1 = torch.ops.aten._linalg_slogdet.default(arg0_1)
        del arg0_1
        arg2_1 = arg1_1
        del arg1_1
        output = call([arg2_1])
        del arg2_1
    return output[0]
