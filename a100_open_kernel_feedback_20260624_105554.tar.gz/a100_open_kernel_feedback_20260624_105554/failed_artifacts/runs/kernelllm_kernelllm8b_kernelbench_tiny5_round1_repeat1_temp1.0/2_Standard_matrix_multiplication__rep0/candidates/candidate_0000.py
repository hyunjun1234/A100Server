import torch
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import grid
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import torch.nn as nn
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor


@triton.jit
def triton_poi_fused_clone_0(in_ptr0, out_ptr0, ynumel, xnumel, YBLOCK: tl.
    constexpr, XBLOCK: tl.constexpr):
    ynumel = 1024
    xnumel = 4096
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[None, :]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    x1 = xindex
    y0 = yindex
    tmp0 = tl.load(in_ptr0 + (y0 + 1024 * x1), xmask & ymask,
        eviction_policy='evict_last')
    tl.store(out_ptr0 + (x1 + 4096 * y0), tmp0, xmask & ymask)


@triton.jit
def triton_poi_fused__unsafe_view_clone_1(in_ptr0, out_ptr0, xnumel, XBLOCK:
    tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    tl.full([XBLOCK], True, tl.int1)
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (4096 * (x0 // 4096) + x0 % 4096), None)
    tl.store(out_ptr0 + x0, tmp0, None)


def call(args):
    arg0_1, arg1_1 = args
    args.clear()
    assert_size_stride(arg0_1, (1024, 4096), (4096, 1))
    assert_size_stride(arg1_1, (4096, 2048), (2048, 1))
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        buf0 = empty_strided_cuda((1024, 4096), (4096, 1), torch.float32)
        get_raw_stream(0)
        triton_poi_fused_clone_0[grid(1024, 4096)](arg0_1, buf0, 1024, 4096,
            XBLOCK=32, YBLOCK=32, num_warps=4, num_stages=1)
        del arg0_1
        buf1 = empty_strided_cuda((1048576, 2048), (2048, 1), torch.float32)
        triton_poi_fused__unsafe_view_clone_1[grid(2097152)](buf0, buf1, 
            2097152, XBLOCK=1024, num_warps=4, num_stages=1)
        del buf0
        buf2 = empty_strided_cuda((1048576, 2048), (2048, 1), torch.float32)
        extern_kernels.mm(buf1, arg1_1, out=buf2)
        del arg1_1
        del buf1
    return reinterpret_tensor(buf2, (1024, 2048, 2048), (4194304, 2048, 1), 0),


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, arg0_1, arg1_1):
        arg0_1 = torch._C._dynamo.guards._reinterpret_tensor(arg0_1, (1024, 
            4096), (4096, 1), 0)
        del arg0_1
        arg1_1 = torch._C._dynamo.guards._reinterpret_tensor(arg1_1, (4096, 
            2048), (1, 4096), 0)
        del arg1_1
        buf2 = empty_strided_cuda((1024, 2048, 2048), (4194304, 2048, 1),
            torch.float32)
        get_raw_stream(0)
        triton_poi_fused_clone_0[grid(1024, 4096)](arg0_1, buf2, 1024, 4096,
            XBLOCK=32, YBLOCK=32, num_warps=4, num_stages=1)
        del arg0_1
        buf1 = empty_strided_cuda((1048576, 2048), (2048, 1), torch.float32)
        triton_poi_fused__unsafe_view_clone_1[grid(2097152)](buf2, buf1, 
            2097152, XBLOCK=1024, num_warps=4, num_stages=1)
        del buf2
        buf3 = empty_strided_cuda((1048576, 2048), (2048, 1), torch.float32)
        extern_kernels.mm(buf1, arg1_1, out=buf3)
        del arg1_1
        del buf1
    return reinterpret_tensor(buf3, (1024, 2048, 2048), (4194304, 2048, 1), 0),


class SynthModel_Matmul_UpsamplingNearest2d_1(nn.Module):
    """
    A model that performs matrix multiplication followed by upsampling.
    """

    def __init__(self, in_features, out_features, scale_factor):
        super(SynthModel_Matmul_UpsamplingNearest2d_1, self).__init__()
        self.weight = nn.Parameter(torch.randn(out_features, in_features))
        self.scale_factor = scale_factor

    def forward(self, x):
        x = x @ self.weight.T
        x = x.view(x.shape[0], x.shape[1], 1, 1)
        x = nn.UpsamplingNearest2d(scale_factor=self.scale_factor)(x)
        return x


def get_inputs():
    batch_size = 32
    in_features = 10
    return [torch.randn(batch_size, in_features)]


def get_init_inputs():
    in_features = 10
    out_features = 20
    scale_factor = 2
    return [[in_features, out_features, scale_factor], {}]

Output:
