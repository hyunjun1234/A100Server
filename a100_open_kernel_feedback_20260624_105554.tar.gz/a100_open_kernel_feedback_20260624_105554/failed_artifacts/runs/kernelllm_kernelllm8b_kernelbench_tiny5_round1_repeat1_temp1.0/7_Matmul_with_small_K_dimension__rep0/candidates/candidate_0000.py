import torch
from torch._inductor.runtime import triton_helpers
import triton
import triton.language as tl
from torch._inductor.runtime.triton_helpers import libdevice
import torch.nn as nn
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor


@triton.jit
def triton_poi_fused__to_copy__unsafe_index_add_arange_clamp_elu_mul_sub_0(
    in_out_ptr1, in_ptr0, xnumel, XBLOCK: tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    tl.full([XBLOCK], True, tl.int1)
    x1 = xindex // 32 % 32
    x0 = xindex % 32
    x2 = xindex // 1024
    x3 = xindex
    tmp0 = x1
    tmp1 = tmp0.to(tl.float32)
    tmp2 = 0.4838709677419355
    tmp3 = tmp1 * tmp2
    tmp4 = 0.0
    tmp5 = triton_helpers.maximum(tmp3, tmp4)
    tmp6 = tmp5.to(tl.int32)
    tmp7 = tl.full([1], 1, tl.int64)
    tmp8 = tmp6 + tmp7
    tmp9 = tl.full([1], 15, tl.int64)
    tmp10 = triton_helpers.minimum(tmp8, tmp9)
    tmp11 = x0
    tmp12 = tmp11.to(tl.float32)
    tmp13 = tmp12 * tmp2
    tmp14 = triton_helpers.maximum(tmp13, tmp4)
    tmp15 = tmp14.to(tl.int32)
    tmp16 = tl.load(in_ptr0 + (tmp15 + 16 * tmp10 + 256 * x2), None,
        eviction_policy='evict_last')
    tmp17 = tmp15 + tmp7
    tmp18 = triton_helpers.minimum(tmp17, tmp9)
    tmp19 = tl.load(in_ptr0 + (tmp18 + 16 * tmp10 + 256 * x2), None,
        eviction_policy='evict_last')
    tmp20 = tmp19 - tmp16
    tmp21 = tmp15.to(tl.float32)
    tmp22 = tmp14 - tmp21
    tmp23 = triton_helpers.maximum(tmp22, tmp4)
    tmp24 = 1.0
    tmp25 = triton_helpers.minimum(tmp23, tmp24)
    tmp26 = tmp20 * tmp25
    tmp27 = tmp16 + tmp26
    tmp28 = tl.load(in_ptr0 + (tmp15 + 16 * tmp6 + 256 * x2), None,
        eviction_policy='evict_last')
    tmp29 = tl.load(in_ptr0 + (tmp18 + 16 * tmp6 + 256 * x2), None,
        eviction_policy='evict_last')
    tmp30 = tmp29 - tmp28
    tmp31 = tmp30 * tmp25
    tmp32 = tmp28 + tmp31
    tmp33 = tmp27 - tmp32
    tmp34 = tmp6.to(tl.float32)
    tmp35 = tmp5 - tmp34
    tmp36 = triton_helpers.maximum(tmp35, tmp4)
    tmp37 = triton_helpers.minimum(tmp36, tmp24)
    tmp38 = tmp33 * tmp37
    tmp39 = tmp32 + tmp38
    tmp40 = tmp39 > tmp4
    tmp41 = 1.0
    tmp42 = tmp39 * tmp41
    tmp43 = libdevice.expm1(tmp42)
    tmp44 = tmp43 * tmp41
    tmp45 = tl.where(tmp40, tmp42, tmp44)
    tl.store(in_out_ptr1 + x3, tmp45, None)


def call(args):
    arg0_1 = args[0]
    del args
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        buf0 = empty_strided_cuda((32768, 32768), (32768, 1), torch.float32)
        extern_kernels.mm(arg0_1, reinterpret_tensor(arg0_1, (32768, 32768),
            (1, 32768), 0), out=buf0)
        del arg0_1
        buf4 = empty_strided_cuda((32, 32, 32, 32), (32768, 1024, 32, 1),
            torch.float32)
        buf5 = buf4
        del buf4
        buf9 = buf5
        del buf5
        buf10 = buf9
        del buf9
        triton_poi_fused__to_copy__unsafe_index_add_arange_clamp_elu_mul_sub_0[
            grid(1048576)](buf10, buf0, 1048576, XBLOCK=1024, num_warps=4,
            num_stages=1)
        del buf0
    return buf10,


class ModelNew(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, input_0):
        arg0_1 = input_0
        output = call([arg0_1])
        return output[0]
