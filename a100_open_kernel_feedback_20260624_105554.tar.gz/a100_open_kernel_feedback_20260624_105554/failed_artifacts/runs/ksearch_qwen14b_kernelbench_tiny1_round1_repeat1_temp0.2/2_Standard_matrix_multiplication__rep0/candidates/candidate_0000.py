import torch
import torch.nn as nn
import torch.cuda.cudart as cudart
from torch.utils.cpp_extension import load_inline

# Inline CUDA code for matrix multiplication
cuda_code = """
__global__ void matrixMultiplyKernel(float* C, const float* A, const float* B, int M, int K, int N) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += A[row * K + k] * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}
"""

# Load the CUDA kernel
matrix_multiply_module = load_inline(
    name="matrix_multiply_module",
    sources=[cuda_code],
    verbose=True
)

class ModelNew(nn.Module):
    """
    Optimized model that performs a single matrix multiplication (C = A * B)
    using a custom CUDA kernel.
    """
    def __init__(self):
        super(ModelNew, self).__init__()

    def forward(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """
        Performs matrix multiplication using the custom CUDA kernel.

        Args:
            A: Input tensor of shape (M, K).
            B: Input tensor of shape (K, N).

        Returns:
            Output tensor of shape (M, N).
        """
        M, K = A.shape
        _, N = B.shape

        # Allocate output tensor
        C = torch.empty((M, N), dtype=torch.float32, device='cuda')

        # Launch the CUDA kernel
        block_size = (16, 16, 1)
        grid_size = ((N + block_size[0] - 1) // block_size[0], (M + block_size[1] - 1) // block_size[1], 1)
        matrix_multiply_module.matrixMultiplyKernel[C.data_ptr(), A.data_ptr(), B.data_ptr(), M, K, N, block=block_size, grid=grid_size]

        return C

M = 1024 * 2
K = 4096 * 2
N = 2048 * 2

def get_inputs():
    A = torch.rand(M, K).cuda()
    B = torch.rand(K, N).cuda()
    return [A, B]

def get_init_inputs():
    return []  # No special initialization inputs needed