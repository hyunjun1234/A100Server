# A100 Open Kernel Suite v3

`/home/jun/unified_bench` 위에 설치하는 NVIDIA A100 80GB x2용 실행·계측·오류수집 overlay입니다.

## v3에서 실제 feedback을 바탕으로 수정한 문제

- `benchmark_config.env`의 RTX PRO 6000 / server GPU 0 잔존값을 A100 / server GPU 1로 자동 수정
- 잘못된 system Python과 CUDA 11.5 `nvcc`를 잡던 doctor를 실제 `/home/jun/llm_run/.venv` + CUDA 12.x 환경으로 수정
- HF server의 `dtype` crash를 `torch_dtype` 기반 runtime으로 교체
- task별 결과가 과거 run과 섞이지 않도록 campaign 디렉터리로 격리
- candidate timing을 5 batch로 반복하고 CV·극단 speedup을 검사하여 `validated_speedup` 별도 생성
- 정상 로그를 오류로 세던 error summarizer를 구조화된 실제 오류 중심으로 교체
- KernelLLM을 공식 prompt template + raw completion + 독립 sample 방식으로 수정
- CUDA-L2의 A100 cuBLASLt auto-tuning failure를 공식 run과 compatibility retry로 분리
- QiMeng-GEMM의 `ratio=`를 파싱하고 shape/repeat 확장
- QiMeng-Attention을 A100 `sm_80` best-effort build/probe로 확장
- KernelAgent 공식 `Fuser.auto_agent` workflow adapter 추가
- 실패 candidate, raw reply, prompt, verdict, GPU/time telemetry를 campaign별 feedback archive에 포함

## 설치

```bash
cd /home/jun
unzip a100_open_kernel_suite_v3.zip

bash a100_open_kernel_suite_v3/scripts/install.sh \
  /home/jun/unified_bench

cd /home/jun/unified_bench
```

설치기는 교체 대상 파일을 다음 위치에 백업합니다.

```text
/home/jun/unified_bench/.open_suite_backups/<timestamp>/
```

## GPU 배치

```text
GPU 0: kernel compile / correctness / latency measurement
GPU 1: local LLM server
```

## 최초 준비

```bash
./run_a100_open_suite.sh clone
./run_a100_open_suite.sh patch
./run_a100_open_suite.sh doctor
./run_a100_open_suite.sh plan
```

`doctor`에서 확인할 핵심:

```text
python_executable = /home/jun/llm_run/.venv/bin/python3
nvcc = CUDA 12.x
torch.cuda.is_available() = true
gpu_count = 2
```

## 권장 확장 실험 순서

### 1. 수정 검증 tiny5

```bash
nohup ./run_a100_open_suite.sh fix_smoke \
  > logs/v3_fix_smoke.out 2>&1 &
```

```bash
tail -f logs/v3_fix_smoke.out
```

기본 campaign ID:

```text
a100_fix_smoke_v3
```

### 2. 핵심 5개 system × subset50 × 3 rounds

대상:

```text
cudaforge autokernel cuda_l1 autotriton drkernel
```

```bash
nohup ./run_a100_open_suite.sh core50_r3 \
  > logs/v3_core50_r3.out 2>&1 &
```

기본 campaign ID:

```text
a100_core50_r3_rep1_v3
```

### 3. repeat 3 통계 실험

```bash
nohup ./run_a100_open_suite.sh core50_r3_rep3 \
  > logs/v3_core50_r3_rep3.out 2>&1 &
```

기본 campaign ID:

```text
a100_core50_r3_rep3_v3
```

### 4. KernelLLM 공식 decoding, Level-1 25개, pass@10

```bash
nohup ./run_a100_open_suite.sh kernelllm_l1_sample25_pass10 \
  > logs/v3_kernelllm_l1_sample25_pass10.out 2>&1 &
```

- checkpoint: `facebook/KernelLLM`
- temperature: `1.0`
- top-p: `0.97`
- independent candidates per task: `10`
- A100 결과는 원 H100 설정과 분리된 transfer evaluation

### 5. native/open artifact 확장

```bash
nohup ./run_a100_open_suite.sh native_expand \
  > logs/v3_native_expand.out 2>&1 &
```

포함:

- QiMeng-GEMM: 여러 square/rectangular shape, 5 repeats
- CUDA-L2: A100 HGEMM 여러 shape, official run + 필요 시 별도 compat retry
- QiMeng-Attention: repo probe, configured command 또는 `sm_80` best-effort build
- QiMeng-Kernel: 공식 scripts/checkpoint/dataset이 있을 때만 실행, 아니면 명시적 skip

## 선택 실험

전체 KernelBench 250개, 1 round:

```bash
nohup ./run_a100_open_suite.sh core250_r1 \
  > logs/v3_core250_r1.out 2>&1 &
```

KernelAgent 공식 workflow tiny1/tiny5:

```bash
nohup ./run_a100_open_suite.sh kernelagent_tiny1 \
  > logs/v3_kernelagent_tiny1.out 2>&1 &
```

```bash
nohup ./run_a100_open_suite.sh kernelagent_tiny5 \
  > logs/v3_kernelagent_tiny5.out 2>&1 &
```

공개 방법 전체 연결 smoke:

```bash
nohup ./run_a100_open_suite.sh all_methods_smoke \
  > logs/v3_all_methods_smoke.out 2>&1 &
```

공식 환경/모델이 없는 항목은 점수를 임의 생성하지 않고 skip reason을 남깁니다.

## 재개

각 mode는 고정 campaign ID를 사용합니다. 같은 명령을 다시 실행하면 `summary.json`이 존재하는 완료 task는 건너뜁니다.

```bash
nohup ./run_a100_open_suite.sh core50_r3 \
  > logs/v3_core50_r3_resume.out 2>&1 &
```

사용자 지정 campaign:

```bash
CAMPAIGN_ID=my_a100_trial \
nohup ./run_a100_open_suite.sh core50_r3 \
  > logs/my_a100_trial.out 2>&1 &
```

## 기록 metric

### correctness / performance

- compile/correct candidate 수와 비율
- task compile/correct/faster success
- pass@1 및 analytic pass@k
- reference/candidate latency raw samples
- raw speedup과 timing validation을 통과한 speedup
- timing batch CV, timing suspect reason

### search efficiency

- kernel task별 LLM call 수
- 첫 correct까지 추정 LLM call 수
- prompt/completion token 수
- compile attempts
- correctness trials
- profiling runs
- time-to-first-correct 추정

### 병목 timing

- LLM wait
- generation non-LLM time
- JIT/import compile
- correctness
- benchmark
- model initialization
- 전체 task wall time
- dominant bottleneck와 비율
- generation/eval CPU time 및 max RSS

### resource

- GPU utilization
- max memory
- temperature
- average/max power
- power sampling 기반 energy estimate

정의는 `METRICS.md`에 있습니다.

## campaign 결과

```text
runs/campaigns/<CAMPAIGN_ID>/
logs/campaigns/<CAMPAIGN_ID>/
results/campaigns/<CAMPAIGN_ID>/
```

분석:

```bash
./run_a100_open_suite.sh summary a100_core50_r3_rep1_v3
./run_a100_open_suite.sh compare
```

주요 파일:

```text
results/campaigns/<ID>/telemetry/telemetry_per_task.csv
results/campaigns/<ID>/telemetry/telemetry_summary.csv
results/campaigns/<ID>/telemetry/bottlenecks.csv
results/campaigns/<ID>/telemetry/llm_calls.jsonl
results/campaigns/<ID>/campaign_manifest.json
```

## 오류/피드백 자료

특정 campaign 분석 자료 생성:

```bash
./run_a100_open_suite.sh feedback a100_core50_r3_rep1_v3
```

생성 파일 예:

```text
/home/jun/unified_bench/a100_open_kernel_feedback_a100_core50_r3_rep1_v3_<timestamp>.tar.gz
```

그 파일 하나를 전달하면 됩니다. 포함 항목:

- 실제 Python/CUDA/NVCC/NCU/GPU 환경
- repo commit 및 dirty status
- campaign manifest와 system config
- LLM call, timing, GPU power/utilization
- 정상 메시지를 제외한 실제 error records/clusters
- 실패 candidate, raw reply, prompt, verdict
- log tail, CPU/RSS resource timing

모델 weight/cache와 대형 build tree는 제외합니다.

## 결과 해석 원칙

- raw speedup이 아니라 `validated_speedup`을 headline에 사용합니다.
- timing suspect task는 별도 보고합니다.
- KernelBench, QiMeng-GEMM, CUDA-L2 등의 서로 다른 baseline speedup을 한 절대 순위로 합치지 않습니다.
- released artifact, live generation, official checkpoint, compatibility retry를 구분합니다.
- CUDA-L2 compat 결과는 official cuBLASLt auto-tuning 결과가 아니라 heuristic-only compatibility 결과로 표시합니다.
- AMD/ROCm-native system은 A100 공식 score를 만들지 않습니다.
