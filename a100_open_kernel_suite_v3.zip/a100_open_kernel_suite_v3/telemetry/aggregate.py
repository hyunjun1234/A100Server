#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path

KNOWN_SYSTEMS = [
    "baseline_loop",
    "cuda_agent",
    "qimeng_kernel",
    "kernelagent",
    "autotriton",
    "autokernel",
    "cudaforge",
    "cuda_l1",
    "drkernel",
    "ksearch",
    "geak",
]


def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def number(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default


def percentile(values, quantile):
    if not values:
        return 0.0

    values = sorted(values)

    if len(values) == 1:
        return values[0]

    position = (len(values) - 1) * quantile
    low = math.floor(position)
    high = math.ceil(position)

    if low == high:
        return values[low]

    return (
        values[low] * (high - position)
        + values[high] * (position - low)
    )


def task_level(task: str):
    for part in Path(task).parts:
        if part.startswith("level") and part[5:].isdigit():
            return part
    return "unknown"


def load_llm_calls(path: Path):
    grouped = defaultdict(list)

    if not path.exists():
        return grouped

    for line in path.read_text(errors="ignore").splitlines():
        try:
            record = json.loads(line)
            grouped[str(record.get("context_key", "unscoped"))].append(record)
        except Exception:
            pass

    return grouped


def gpu_stats(path: Path):
    empty = {
        "energy_wh": 0.0,
        "util_avg": 0.0,
        "util_max": 0.0,
        "mem_max": 0.0,
        "temp_max": 0.0,
    }

    if not path.exists():
        return empty

    rows = []

    try:
        with path.open() as file:
            for row in csv.DictReader(file):
                if row.get("gpu_index") != "error":
                    rows.append(row)
    except Exception:
        return empty

    by_gpu = defaultdict(list)

    for row in rows:
        by_gpu[row.get("gpu_index", "0")].append(row)

    energy_wh = 0.0

    for samples in by_gpu.values():
        samples.sort(key=lambda row: number(row.get("monotonic_s")))

        for first, second in zip(samples, samples[1:]):
            duration = max(
                0.0,
                number(second.get("monotonic_s"))
                - number(first.get("monotonic_s")),
            )
            average_power = (
                number(first.get("power_w"))
                + number(second.get("power_w"))
            ) / 2
            energy_wh += average_power * duration / 3600

    utilizations = [number(row.get("util_gpu_pct")) for row in rows]
    memories = [number(row.get("memory_used_mib")) for row in rows]
    temperatures = [number(row.get("temperature_c")) for row in rows]

    return {
        "energy_wh": energy_wh,
        "util_avg": statistics.mean(utilizations) if utilizations else 0.0,
        "util_max": max(utilizations) if utilizations else 0.0,
        "mem_max": max(memories) if memories else 0.0,
        "temp_max": max(temperatures) if temperatures else 0.0,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--task-list", default="kernelbench_subset50.txt")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    runs_dir = root / "runs"
    output_dir = root / "results" / "telemetry"
    output_dir.mkdir(parents=True, exist_ok=True)

    llm_calls_by_context = load_llm_calls(
        output_dir / "llm_calls.jsonl"
    )

    per_task_rows = []

    for meta_path in runs_dir.rglob("task_meta.json"):
        metadata = read_json(meta_path, {}) or {}
        task_dir = meta_path.parent

        summary_items = read_json(
            task_dir / "final_eval" / "summary.json",
            [],
        ) or []

        summary = summary_items[0] if summary_items else {}
        context_key = str(metadata.get("context_key", ""))

        llm_calls = sorted(
            llm_calls_by_context.get(context_key, []),
            key=lambda record: record.get("call_index", 0),
        )

        llm_latencies = [
            number(record.get("latency_s"))
            for record in llm_calls
        ]

        llm_wait = sum(llm_latencies)
        generation_wall = number(metadata.get("generation_wall_s"))
        eval_wall = number(metadata.get("eval_wall_s"))
        task_wall = number(
            metadata.get("task_wall_s"),
            generation_wall + eval_wall,
        )
        generation_non_llm = max(
            0.0,
            generation_wall - llm_wait,
        )

        compile_time = number(summary.get("compile_s"))
        correctness_time = number(summary.get("correctness_s"))
        benchmark_time = number(summary.get("benchmark_s"))
        model_init_time = number(summary.get("model_init_s"))

        stages = {
            "llm_wait": llm_wait,
            "generator_non_llm": generation_non_llm,
            "unified_compile": compile_time,
            "unified_correctness": correctness_time,
            "unified_benchmark": benchmark_time,
            "model_init": model_init_time,
        }

        bottleneck_stage, bottleneck_time = max(
            stages.items(),
            key=lambda item: item[1],
        )
        measured_stage_total = sum(stages.values())

        gpu = gpu_stats(
            task_dir / "telemetry" / "gpu.csv"
        )

        best_speedup = number(summary.get("best_score"))
        n_candidates = int(summary.get("n_candidates", 0) or 0)
        n_compiled = int(summary.get("n_compiled", 0) or 0)
        n_correct = int(summary.get("n_correct", 0) or 0)

        task_correct = int(
            n_correct > 0
            or number(summary.get("correct_rate")) > 0
        )
        task_compiled = int(
            n_compiled > 0
            or number(summary.get("runnable_rate")) > 0
        )
        task_faster = int(
            task_correct and best_speedup > 1
        )

        first_correct_index = summary.get(
            "first_correct_candidate_index"
        )

        llm_calls_to_first_correct = ""
        time_to_first_correct = ""

        if first_correct_index is not None:
            llm_calls_to_first_correct = (
                min(
                    len(llm_calls),
                    int(first_correct_index) + 1,
                )
                if llm_calls
                else int(first_correct_index) + 1
            )

            if n_candidates > 0:
                time_to_first_correct = (
                    generation_wall
                    * (int(first_correct_index) + 1)
                    / n_candidates
                )

        gain = (
            max(math.log2(best_speedup), 0.0)
            if best_speedup > 0
            else 0.0
        )

        per_task_rows.append({
            "system": metadata.get("system", "unknown"),
            "benchmark": metadata.get("benchmark", "kernelbench"),
            "level": task_level(str(metadata.get("task", ""))),
            "task": metadata.get("task", ""),
            "repeat": metadata.get("repeat", 0),
            "experiment": metadata.get("experiment", ""),
            "context_key": context_key,
            "generation_exit": metadata.get("generation_exit", ""),
            "eval_exit": metadata.get("eval_exit", ""),
            "n_candidates": n_candidates,
            "n_compiled": n_compiled,
            "n_correct": n_correct,
            "candidate_compile_rate": number(summary.get("runnable_rate")),
            "candidate_correct_rate": number(summary.get("correct_rate")),
            "task_compile_success": task_compiled,
            "task_correct_success": task_correct,
            "task_faster_success": task_faster,
            "pass_at_1": number(summary.get("pass@1")),
            "fast_at_1": number(summary.get("fast_1")),
            "best_speedup": best_speedup,
            "speedup_gmean_candidates_correct": number(
                summary.get("geomean_speedup")
            ),
            "speedup_median_candidates_correct": number(
                summary.get("median_speedup")
            ),
            "compile_attempts": int(
                summary.get("compile_attempts", n_candidates) or 0
            ),
            "correctness_trials": int(
                summary.get("correctness_trials_executed", 0) or 0
            ),
            "profile_runs": int(
                summary.get("profile_runs", 0) or 0
            ),
            "llm_calls_total": len(llm_calls),
            "llm_calls_to_first_correct_est": llm_calls_to_first_correct,
            "prompt_tokens_est_total": sum(
                int(
                    record.get("prompt_tokens_reported")
                    or record.get("prompt_tokens_est")
                    or 0
                )
                for record in llm_calls
            ),
            "completion_tokens_est_total": sum(
                int(
                    record.get("completion_tokens_reported")
                    or record.get("completion_tokens_est")
                    or 0
                )
                for record in llm_calls
            ),
            "llm_wait_s": llm_wait,
            "llm_latency_p50_s": percentile(llm_latencies, 0.5),
            "llm_latency_p95_s": percentile(llm_latencies, 0.95),
            "generation_wall_s": generation_wall,
            "generation_non_llm_s": generation_non_llm,
            "unified_compile_s": compile_time,
            "unified_correctness_s": correctness_time,
            "unified_benchmark_s": benchmark_time,
            "model_init_s": model_init_time,
            "eval_wall_s": eval_wall,
            "task_wall_s": task_wall,
            "time_to_first_correct_s_est": time_to_first_correct,
            "bottleneck_stage": bottleneck_stage,
            "bottleneck_time_s": bottleneck_time,
            "bottleneck_fraction": (
                bottleneck_time / measured_stage_total
                if measured_stage_total > 0
                else 0.0
            ),
            "gpu_energy_wh_est": gpu["energy_wh"],
            "gpu_util_avg_pct": gpu["util_avg"],
            "gpu_util_max_pct": gpu["util_max"],
            "gpu_mem_max_mib": gpu["mem_max"],
            "gpu_temp_max_c": gpu["temp_max"],
            "correct_per_call": (
                task_correct / max(len(llm_calls), 1)
            ),
            "speed_gain_per_call": (
                gain / max(len(llm_calls), 1)
            ),
            "speed_gain_per_min": (
                gain / max(task_wall / 60.0, 1e-9)
            ),
        })

    per_task_path = output_dir / "telemetry_per_task.csv"

    if per_task_rows:
        with per_task_path.open("w", newline="") as file:
            writer = csv.DictWriter(
                file,
                fieldnames=list(per_task_rows[0].keys()),
            )
            writer.writeheader()
            writer.writerows(per_task_rows)
    else:
        per_task_path.write_text("system\n")

    grouped = defaultdict(list)

    for row in per_task_rows:
        grouped[
            (
                row["system"],
                row["benchmark"],
                row["level"],
            )
        ].append(row)

    summary_rows = []

    for (system, benchmark, level), rows in sorted(grouped.items()):
        count = len(rows)

        correct_speeds = [
            row["best_speedup"]
            for row in rows
            if row["task_correct_success"]
            and row["best_speedup"] > 0
        ]

        successful_calls = [
            row["llm_calls_total"]
            for row in rows
            if row["task_correct_success"]
        ]

        bottlenecks = Counter(
            row["bottleneck_stage"]
            for row in rows
        )

        summary_rows.append({
            "system": system,
            "benchmark": benchmark,
            "level": level,
            "n_tasks": count,
            "task_compile_rate": (
                sum(row["task_compile_success"] for row in rows)
                / count
            ),
            "task_correct_rate": (
                sum(row["task_correct_success"] for row in rows)
                / count
            ),
            "task_faster_rate": (
                sum(row["task_faster_success"] for row in rows)
                / count
            ),
            "pass_at_1": (
                sum(row["pass_at_1"] for row in rows)
                / count
            ),
            "fast_at_1": (
                sum(row["fast_at_1"] for row in rows)
                / count
            ),
            "speedup_gmean_correct": (
                math.exp(
                    sum(math.log(speed) for speed in correct_speeds)
                    / len(correct_speeds)
                )
                if correct_speeds
                else 0.0
            ),
            "speedup_median_correct": (
                statistics.median(correct_speeds)
                if correct_speeds
                else 0.0
            ),
            "speedup_max_correct": (
                max(correct_speeds)
                if correct_speeds
                else 0.0
            ),
            "task_wall_mean_s": statistics.mean(
                row["task_wall_s"] for row in rows
            ),
            "task_wall_p50_s": percentile(
                [row["task_wall_s"] for row in rows],
                0.5,
            ),
            "task_wall_p95_s": percentile(
                [row["task_wall_s"] for row in rows],
                0.95,
            ),
            "llm_calls_mean_per_task": statistics.mean(
                row["llm_calls_total"] for row in rows
            ),
            "llm_calls_mean_per_success": (
                statistics.mean(successful_calls)
                if successful_calls
                else 0.0
            ),
            "llm_wait_mean_s": statistics.mean(
                row["llm_wait_s"] for row in rows
            ),
            "compile_attempts_mean": statistics.mean(
                row["compile_attempts"] for row in rows
            ),
            "profile_runs_mean": statistics.mean(
                row["profile_runs"] for row in rows
            ),
            "gpu_energy_mean_wh_est": statistics.mean(
                row["gpu_energy_wh_est"] for row in rows
            ),
            "dominant_bottleneck": (
                bottlenecks.most_common(1)[0][0]
                if bottlenecks
                else "unknown"
            ),
        })

    summary_path = output_dir / "telemetry_summary.csv"

    if summary_rows:
        with summary_path.open("w", newline="") as file:
            writer = csv.DictWriter(
                file,
                fieldnames=list(summary_rows[0].keys()),
            )
            writer.writeheader()
            writer.writerows(summary_rows)
    else:
        summary_path.write_text("system\n")

    bottleneck_path = output_dir / "bottlenecks.csv"

    bottleneck_rows = sorted(
        per_task_rows,
        key=lambda row: row["bottleneck_fraction"],
        reverse=True,
    )

    if bottleneck_rows:
        fields = [
            "system",
            "benchmark",
            "level",
            "task",
            "repeat",
            "bottleneck_stage",
            "bottleneck_time_s",
            "bottleneck_fraction",
            "task_wall_s",
            "llm_calls_total",
            "best_speedup",
            "task_correct_success",
        ]

        with bottleneck_path.open("w", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader()
            writer.writerows(
                {
                    key: row.get(key, "")
                    for key in fields
                }
                for row in bottleneck_rows
            )
    else:
        bottleneck_path.write_text("system\n")

    print("per-task:", per_task_path)
    print("summary:", summary_path)
    print("bottlenecks:", bottleneck_path)

    for row in summary_rows:
        print(row)


if __name__ == "__main__":
    main()
