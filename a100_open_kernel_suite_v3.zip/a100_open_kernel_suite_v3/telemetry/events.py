#!/usr/bin/env python3
import argparse
import json
import os
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--file", required=True)
parser.add_argument("--context-key", required=True)
parser.add_argument("--system", required=True)
parser.add_argument("--benchmark", required=True)
parser.add_argument("--task", required=True)
parser.add_argument("--repeat", type=int, default=0)
parser.add_argument("--stage", required=True)
parser.add_argument("--event", choices=["start", "end", "info"], required=True)
parser.add_argument("--status", default="")
parser.add_argument("--extra-json", default="{}")
args = parser.parse_args()

try:
    extra = json.loads(args.extra_json)
except Exception:
    extra = {"raw_extra": args.extra_json}

record = {
    "epoch": time.time(),
    "monotonic_ns": time.monotonic_ns(),
    "pid": os.getpid(),
    "context_key": args.context_key,
    "system": args.system,
    "benchmark": args.benchmark,
    "task": args.task,
    "repeat": args.repeat,
    "stage": args.stage,
    "event": args.event,
    "status": args.status,
    **extra,
}
path = Path(args.file)
path.parent.mkdir(parents=True, exist_ok=True)
with path.open("a", encoding="utf-8") as file:
    file.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
