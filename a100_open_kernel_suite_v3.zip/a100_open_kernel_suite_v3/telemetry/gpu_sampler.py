#!/usr/bin/env python3
import argparse
import csv
import signal
import subprocess
import time
from pathlib import Path

STOP = False

def stop(*_):
    global STOP
    STOP = True

signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)

parser = argparse.ArgumentParser()
parser.add_argument("--output", required=True)
parser.add_argument("--gpus", default="0")
parser.add_argument("--interval", type=float, default=0.5)
args = parser.parse_args()

selected = {value.strip() for value in args.gpus.split(",") if value.strip()}
output = Path(args.output)
output.parent.mkdir(parents=True, exist_ok=True)
fields = [
    "epoch", "monotonic_s", "gpu_index", "name", "util_gpu_pct",
    "memory_used_mib", "memory_total_mib", "temperature_c", "power_w",
    "power_limit_w", "sm_clock_mhz", "mem_clock_mhz",
]
query = (
    "index,name,utilization.gpu,memory.used,memory.total,temperature.gpu,"
    "power.draw,power.limit,clocks.sm,clocks.mem"
)

with output.open("w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=fields)
    writer.writeheader()
    file.flush()
    while not STOP:
        epoch = time.time()
        monotonic = time.monotonic()
        try:
            process = subprocess.run(
                ["nvidia-smi", f"--query-gpu={query}", "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=10, check=True,
            )
            for line in process.stdout.splitlines():
                values = [value.strip() for value in line.split(",")]
                if len(values) != 10 or values[0] not in selected:
                    continue
                row = dict(zip(fields[2:], values))
                row["epoch"] = epoch
                row["monotonic_s"] = monotonic
                writer.writerow(row)
            file.flush()
        except Exception as exc:
            writer.writerow({"epoch": epoch, "monotonic_s": monotonic, "gpu_index": "error", "name": repr(exc)})
            file.flush()
        time.sleep(max(args.interval, 0.1))
