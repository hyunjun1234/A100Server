#!/usr/bin/env bash
set -o pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

[ -f benchmark_config.env ] && source benchmark_config.env
[ -f open_suite_config.env ] && source open_suite_config.env

ROUNDS=${1:-${ROUNDS:-3}}
REPEAT=${2:-${REPEAT:-1}}
TEMP=${3:-${TEMPERATURE:-0.2}}
TASK_TIMEOUT=${4:-${TASK_TIMEOUT:-1800}}

TASK_LIST=${TASK_LIST:-kernelbench_subset50.txt}
SYSTEMS=${SYSTEMS:-${OFFICIAL5_SYSTEMS:-"cudaforge autokernel cuda_l1 autotriton drkernel"}}

SERVER_HOST=${SERVER_HOST:-127.0.0.1}
BACKEND_PORT=${BACKEND_PORT:-8000}
PROXY_PORT=${PROXY_PORT:-8100}
SERVER_CUDA_VISIBLE_DEVICES=${SERVER_CUDA_VISIBLE_DEVICES:-${SERVER_GPU:-1}}
BENCH_CUDA_VISIBLE_DEVICES=${BENCH_CUDA_VISIBLE_DEVICES:-${BENCH_GPU:-0}}
TELEMETRY_DIR=${TELEMETRY_DIR:-results/telemetry}
PYTHON_BIN=${PYTHON_BIN:-$(command -v python3)}

mkdir -p \
  "${RUNS_DIR:-runs}" \
  "${RESULTS_DIR:-results}" \
  "${LOGS_DIR:-logs}" \
  models \
  third_party \
  "$TELEMETRY_DIR"

start_proxy() {
  if curl -sf "http://127.0.0.1:${PROXY_PORT}/health" >/dev/null 2>&1; then
    echo "Telemetry proxy already running on ${PROXY_PORT}"
    return
  fi

  echo "Starting telemetry proxy ${PROXY_PORT} -> backend ${BACKEND_PORT}"

  nohup "$PYTHON_BIN" telemetry/openai_proxy.py \
    --backend "http://${SERVER_HOST}:${BACKEND_PORT}" \
    --host 127.0.0.1 \
    --port "$PROXY_PORT" \
    --log "${TELEMETRY_DIR}/llm_calls.jsonl" \
    > "${LOGS_DIR:-logs}/telemetry_proxy.out" 2>&1 &

  echo $! > "${TELEMETRY_DIR}/proxy.pid"

  for _ in $(seq 1 60); do
    curl -sf "http://127.0.0.1:${PROXY_PORT}/health" >/dev/null && return
    sleep 1
  done

  echo "ERROR: telemetry proxy failed"
  tail -100 "${LOGS_DIR:-logs}/telemetry_proxy.out" || true
  exit 1
}

stop_backend() {
  pkill -f "hf_openai_server.py" 2>/dev/null || true
  sleep 3
}

start_backend() {
  local model_path="$1"
  local alias="$2"
  local server_log="${LOGS_DIR:-logs}/hf_server_${alias}_temp${TEMP}.out"

  stop_backend

  echo "Starting backend model=$model_path alias=$alias GPU=$SERVER_CUDA_VISIBLE_DEVICES"

  CUDA_VISIBLE_DEVICES="$SERVER_CUDA_VISIBLE_DEVICES" \
  nohup "$PYTHON_BIN" hf_openai_server.py \
    --model_id "$model_path" \
    --host "$SERVER_HOST" \
    --port "$BACKEND_PORT" \
    --max_new_tokens "${MAX_NEW_TOKENS:-1024}" \
    --temperature "$TEMP" \
    --top_p "${TOP_P:-0.95}" \
    > "$server_log" 2>&1 &

  for index in $(seq 1 300); do
    curl -sf "http://${SERVER_HOST}:${BACKEND_PORT}/health" >/dev/null && {
      echo "backend ready"
      return
    }

    if [ "$index" -eq 300 ]; then
      echo "ERROR: backend server failed: $server_log"
      tail -100 "$server_log" || true
      exit 1
    fi

    sleep 2
  done
}

resolve_model() {
  local model="$1"
  local alias="$2"

  "$PYTHON_BIN" scripts/resolve_model.py \
    --model "$model" \
    --dest "models/$alias"
}

if [ -x ./clone_repos.sh ]; then
  ./clone_repos.sh || true
fi

if [ -x ./scripts/clone_all_open.sh ]; then
  ./scripts/clone_all_open.sh || true
fi

if [ ! -f "$TASK_LIST" ]; then
  if [[ "$TASK_LIST" == *subset50* ]] && [ -f make_subset_tasklist.py ]; then
    "$PYTHON_BIN" make_subset_tasklist.py
  else
    echo "ERROR: task list not found: $TASK_LIST"
    exit 1
  fi
fi

start_proxy

CURRENT_MODEL=""
SKIP_LOG="${TELEMETRY_DIR}/method_skips.jsonl"

for SYSTEM in $SYSTEMS; do
  if [ ! -f "systems/${SYSTEM}.env" ]; then
    printf '{"system":"%s","reason":"systems env missing"}\n' \
      "$SYSTEM" >> "$SKIP_LOG"
    echo "[SKIP] $SYSTEM: systems/${SYSTEM}.env missing"
    continue
  fi

  source "systems/${SYSTEM}.env"

  if [ -n "${OFFICIAL_UNAVAILABLE_REASON:-}" ]; then
    printf '{"system":"%s","reason":"%s"}\n' "$SYSTEM" "$OFFICIAL_UNAVAILABLE_REASON" >> "$SKIP_LOG"
    echo "[SKIP] $SYSTEM: $OFFICIAL_UNAVAILABLE_REASON"
    unset OFFICIAL_UNAVAILABLE_REASON
    continue
  fi

  if [ -n "${SYSTEM_MODEL_HF_ID:-}" ]; then
    WANTED_MODEL="$SYSTEM_MODEL_HF_ID"
    ALIAS="${SYSTEM_MODEL_ALIAS:-$SYSTEM}"
  elif [ -n "${KERNEL_ARTIFACT_DIR:-}" ]; then
    WANTED_MODEL="__artifact__"
    ALIAS="artifact"
  else
    WANTED_MODEL="${MODEL_ID:-Qwen/Qwen2.5-Coder-14B-Instruct}"
    ALIAS="${MODEL_ALIAS:-qwen14b}_${MODEL_SIZE_TAG:-14B}"
  fi

  if [ -z "$WANTED_MODEL" ]; then
    printf '{"system":"%s","reason":"official checkpoint/model ID missing"}\n' \
      "$SYSTEM" >> "$SKIP_LOG"
    echo "[SKIP] $SYSTEM: model/checkpoint missing"
  else
    if [ "$WANTED_MODEL" != "__artifact__" ] && \
       [ "$WANTED_MODEL" != "$CURRENT_MODEL" ]; then

      LOCAL_MODEL=$(resolve_model "$WANTED_MODEL" "$ALIAS")
      start_backend "$LOCAL_MODEL" "$ALIAS"
      CURRENT_MODEL="$WANTED_MODEL"
    fi

    BENCHMARK_NAME=kernelbench \
    PROXY_PORT="$PROXY_PORT" \
    BENCH_CUDA_VISIBLE_DEVICES="$BENCH_CUDA_VISIBLE_DEVICES" \
    telemetry/instrumented_run_system.sh \
      "$SYSTEM" \
      "$TASK_LIST" \
      "$ROUNDS" \
      "$REPEAT" \
      "$TEMP" \
      "$TASK_TIMEOUT"
  fi

  unset \
    SYSTEM_MODEL_HF_ID \
    SYSTEM_MODEL_ALIAS \
    SYSTEM_MODEL_LOCAL_DIR \
    KERNEL_ARTIFACT_DIR \
    SYSTEM_CWD \
    SYSTEM_CMD \
    CANDIDATE_GLOB \
    AUTOKERNEL_REPO \
    OFFICIAL_UNAVAILABLE_REASON
done

MANIFEST="${TASK_LIST%.txt}.csv"

if [ -f collect_results.py ] && [ -f "$MANIFEST" ]; then
  "$PYTHON_BIN" collect_results.py \
    --runs_dir "${RUNS_DIR:-runs}" \
    --manifest "$MANIFEST" \
    --out "${RESULTS_DIR:-results}/unified_summary.csv" || true
fi

"$PYTHON_BIN" telemetry/aggregate.py \
  --root "$ROOT" \
  --task-list "$TASK_LIST" || true

echo "DONE"
echo "Standard results: ${RESULTS_DIR:-results}/unified_summary.csv"
echo "Telemetry results: ${TELEMETRY_DIR}/telemetry_summary.csv"
