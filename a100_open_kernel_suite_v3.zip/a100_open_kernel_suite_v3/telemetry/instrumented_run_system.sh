#!/usr/bin/env bash
set -o pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

[ -f benchmark_config.env ] && source benchmark_config.env
[ -f open_suite_config.env ] && source open_suite_config.env

SYSTEM=${1:?usage: instrumented_run_system.sh SYSTEM [TASK_LIST] [ROUNDS] [REPEAT] [TEMP] [TIMEOUT]}
TASK_LIST=${2:-kernelbench_subset50.txt}
ROUNDS=${3:-3}
REPEAT=${4:-1}
TEMP=${5:-0.2}
TASK_TIMEOUT=${6:-1800}

BENCHMARK_NAME=${BENCHMARK_NAME:-kernelbench}
PROXY_PORT=${PROXY_PORT:-8100}
BENCH_CUDA_VISIBLE_DEVICES=${BENCH_CUDA_VISIBLE_DEVICES:-${BENCH_GPU:-0}}
GPU_SAMPLE_INTERVAL=${GPU_SAMPLE_INTERVAL:-0.5}
TELEMETRY_DIR=${TELEMETRY_DIR:-results/telemetry}
PYTHON_BIN=${PYTHON_BIN:-$(command -v python3)}

SYSTEM_ENV="systems/${SYSTEM}.env"
[ -f "$SYSTEM_ENV" ] || { echo "ERROR: $SYSTEM_ENV not found"; exit 1; }
source "$SYSTEM_ENV"

EVAL_MODEL_NAME=${SYSTEM_MODEL_ALIAS:-${MODEL_ALIAS:-default}}
BASE_NAME="$(basename "$TASK_LIST" .txt)"
EXPERIMENT="${SYSTEM}_${EVAL_MODEL_NAME}_${BASE_NAME}_round${ROUNDS}_repeat${REPEAT}_temp${TEMP}"
WORK_DIR="${ROOT}/${RUNS_DIR:-runs}/${EXPERIMENT}"
LOG_DIR="${ROOT}/${LOGS_DIR:-logs}/${EXPERIMENT}"
STATUS_CSV="${WORK_DIR}/task_status.csv"

mkdir -p "$WORK_DIR" "$LOG_DIR" "$TELEMETRY_DIR"
[ -f "$STATUS_CSV" ] || \
  echo "task_path,repeat,gen_exit,eval_exit,log_path,start_epoch,end_epoch,total_wall_s,context_key" \
  > "$STATUS_CSV"

export ROOT_SEED NUM_CORRECTNESS_TRIALS ATOL RTOL EVAL_WARMUP EVAL_TIMING_ITERS EVAL_TIMEOUT_SEC
export OPENAI_BASE_URL="http://127.0.0.1:${PROXY_PORT}/v1"
export OPENAI_API_BASE="$OPENAI_BASE_URL"
export LLM_API_BASE="$OPENAI_BASE_URL"
export VLLM_API_BASE="$OPENAI_BASE_URL"
export OPENAI_API_KEY="EMPTY"
# Commands that use SERVER_HOST/SERVER_PORT instead of OPENAI_BASE_URL
# are also routed through the telemetry proxy.
export SERVER_HOST="127.0.0.1"
export SERVER_PORT="$PROXY_PORT"
export EVAL_MODEL="$EVAL_MODEL_NAME"
export TOP_P MAX_NEW_TOKENS

echo "=========================================="
echo "Instrumented System: $SYSTEM"
echo "Experiment: $EXPERIMENT"
echo "Benchmark GPU(s): $BENCH_CUDA_VISIBLE_DEVICES"
echo "LLM endpoint: $OPENAI_BASE_URL"
echo "=========================================="

curl -sf "http://127.0.0.1:${PROXY_PORT}/health" >/dev/null || {
  echo "ERROR: telemetry proxy not running on port ${PROXY_PORT}"
  exit 1
}

has_summary() {
  [ -f "${WORK_DIR}/$(basename "$1" .py)_rep$2/final_eval/summary.json" ]
}

while IFS= read -r task; do
  [ -z "$task" ] && continue
  if [[ "$task" = /* ]]; then
    task_abs="$task"
  else
    task_abs="${ROOT}/${task}"
  fi

  name=$(basename "$task" .py)
  LEVEL=$(echo "$task" | grep -o 'level[0-9]' | grep -o '[0-9]' || true)
  PROBLEM=$(echo "$name" | grep -o '^[0-9]*' || true)

  for rep in $(seq 0 $((REPEAT - 1))); do
    if has_summary "$task" "$rep"; then
      echo "SKIP completed: $task (rep $rep)"
      continue
    fi

    TASK_DIR="${WORK_DIR}/${name}_rep${rep}"
    CAND_DIR="${TASK_DIR}/candidates"
    EVAL_DIR="${TASK_DIR}/final_eval"
    TELEMETRY_TASK_DIR="${TASK_DIR}/telemetry"
    mkdir -p "$CAND_DIR" "$EVAL_DIR" "$TELEMETRY_TASK_DIR"

    log_path="${LOG_DIR}/${SYSTEM}_${name}_rep${rep}.out"
    SEED=$(( ${ROOT_SEED:-20260611} + rep ))
    CONTEXT_KEY="${SYSTEM}|${BENCHMARK_NAME}|${name}|rep${rep}|${EXPERIMENT}"
    start_epoch=$(date +%s.%N)

    echo "=========================================="
    echo "Running $task (rep $rep), seed=$SEED"
    echo "context=$CONTEXT_KEY"
    echo "=========================================="

    "$PYTHON_BIN" telemetry/set_context.py \
      --url "http://127.0.0.1:${PROXY_PORT}/telemetry/context" \
      --context-key "$CONTEXT_KEY" \
      --system "$SYSTEM" \
      --benchmark "$BENCHMARK_NAME" \
      --task "$task" \
      --repeat "$rep" >/dev/null

    "$PYTHON_BIN" telemetry/gpu_sampler.py \
      --output "$TELEMETRY_TASK_DIR/gpu.csv" \
      --gpus "$BENCH_CUDA_VISIBLE_DEVICES" \
      --interval "$GPU_SAMPLE_INTERVAL" \
      > "$TELEMETRY_TASK_DIR/gpu_sampler.out" 2>&1 &
    GPU_SAMPLER_PID=$!

    export TORCH_EXTENSIONS_DIR="${TELEMETRY_TASK_DIR}/torch_extensions"
    export TMPDIR="${TELEMETRY_TASK_DIR}/tmp"
    mkdir -p "$TORCH_EXTENSIONS_DIR" "$TMPDIR"

    COMMAND=${SYSTEM_CMD//\{TASK\}/"$task_abs"}
    COMMAND=${COMMAND//\{CAND_DIR\}/"$CAND_DIR"}
    COMMAND=${COMMAND//\{ROUNDS\}/"$ROUNDS"}
    COMMAND=${COMMAND//\{SEED\}/"$SEED"}
    COMMAND=${COMMAND//\{TEMP\}/"$TEMP"}
    COMMAND=${COMMAND//\{LEVEL\}/"$LEVEL"}
    COMMAND=${COMMAND//\{PROBLEM\}/"$PROBLEM"}

    "$PYTHON_BIN" telemetry/events.py \
      --file "$TELEMETRY_TASK_DIR/events.jsonl" \
      --context-key "$CONTEXT_KEY" \
      --system "$SYSTEM" \
      --benchmark "$BENCHMARK_NAME" \
      --task "$task" \
      --repeat "$rep" \
      --stage generation \
      --event start

    generation_start=$(date +%s.%N)

    if [ -n "${KERNEL_ARTIFACT_DIR:-}" ] && [ -z "${SYSTEM_MODEL_HF_ID:-}" ]; then
      {
        echo "[artifact mode] ${KERNEL_ARTIFACT_DIR}"
        find "${ROOT}/${KERNEL_ARTIFACT_DIR}" \
          -name "*${name}*" -name "*.py" \
          -exec cp -v {} "$CAND_DIR/" \;
      } > "$log_path" 2>&1
      generation_exit=$?
    else
      CWD="$ROOT"
      [ -n "${SYSTEM_CWD:-}" ] && CWD="${ROOT}/${SYSTEM_CWD}"

      if [ -x /usr/bin/time ]; then
        (
          cd "$CWD" || exit 1
          CUDA_VISIBLE_DEVICES="$BENCH_CUDA_VISIBLE_DEVICES" \
          /usr/bin/time -v \
            -o "$TELEMETRY_TASK_DIR/generation_resource.txt" \
          timeout --kill-after=60s "$TASK_TIMEOUT" \
            bash -c "$COMMAND"
        ) > "$log_path" 2>&1
      else
        (
          cd "$CWD" || exit 1
          CUDA_VISIBLE_DEVICES="$BENCH_CUDA_VISIBLE_DEVICES" \
          timeout --kill-after=60s "$TASK_TIMEOUT" \
            bash -c "$COMMAND"
        ) > "$log_path" 2>&1
      fi
      generation_exit=$?
    fi

    generation_end=$(date +%s.%N)
    generation_wall=$(awk -v s="$generation_start" -v e="$generation_end" \
      'BEGIN{printf "%.6f", e-s}')

    "$PYTHON_BIN" telemetry/events.py \
      --file "$TELEMETRY_TASK_DIR/events.jsonl" \
      --context-key "$CONTEXT_KEY" \
      --system "$SYSTEM" \
      --benchmark "$BENCHMARK_NAME" \
      --task "$task" \
      --repeat "$rep" \
      --stage generation \
      --event end \
      --status "$generation_exit" \
      --extra-json "{\"wall_s\":$generation_wall}"

    "$PYTHON_BIN" telemetry/events.py \
      --file "$TELEMETRY_TASK_DIR/events.jsonl" \
      --context-key "$CONTEXT_KEY" \
      --system "$SYSTEM" \
      --benchmark "$BENCHMARK_NAME" \
      --task "$task" \
      --repeat "$rep" \
      --stage unified_eval \
      --event start

    eval_start=$(date +%s.%N)

    if [ -x /usr/bin/time ]; then
      CUDA_VISIBLE_DEVICES="$BENCH_CUDA_VISIBLE_DEVICES" \
      /usr/bin/time -v \
        -o "$TELEMETRY_TASK_DIR/eval_resource.txt" \
      timeout --kill-after=60s "$TASK_TIMEOUT" \
        "$PYTHON_BIN" telemetry/instrumented_final_eval.py \
          --task "$task_abs" \
          --cand_dir "$CAND_DIR" \
          --glob "${CANDIDATE_GLOB:-round*_kernel.py}" \
          --task_work_dir "$EVAL_DIR" \
          >> "$log_path" 2>&1
    else
      CUDA_VISIBLE_DEVICES="$BENCH_CUDA_VISIBLE_DEVICES" \
      timeout --kill-after=60s "$TASK_TIMEOUT" \
        "$PYTHON_BIN" telemetry/instrumented_final_eval.py \
          --task "$task_abs" \
          --cand_dir "$CAND_DIR" \
          --glob "${CANDIDATE_GLOB:-round*_kernel.py}" \
          --task_work_dir "$EVAL_DIR" \
          >> "$log_path" 2>&1
    fi
    eval_exit=$?

    eval_end=$(date +%s.%N)
    eval_wall=$(awk -v s="$eval_start" -v e="$eval_end" \
      'BEGIN{printf "%.6f", e-s}')

    "$PYTHON_BIN" telemetry/events.py \
      --file "$TELEMETRY_TASK_DIR/events.jsonl" \
      --context-key "$CONTEXT_KEY" \
      --system "$SYSTEM" \
      --benchmark "$BENCHMARK_NAME" \
      --task "$task" \
      --repeat "$rep" \
      --stage unified_eval \
      --event end \
      --status "$eval_exit" \
      --extra-json "{\"wall_s\":$eval_wall}"

    kill "$GPU_SAMPLER_PID" 2>/dev/null || true
    wait "$GPU_SAMPLER_PID" 2>/dev/null || true

    end_epoch=$(date +%s.%N)
    total_wall=$(awk -v s="$start_epoch" -v e="$end_epoch" \
      'BEGIN{printf "%.6f", e-s}')

    "$PYTHON_BIN" - "$TASK_DIR/task_meta.json" <<PY
import json
from pathlib import Path

Path("$TASK_DIR/task_meta.json").write_text(json.dumps({
  "context_key": "$CONTEXT_KEY",
  "system": "$SYSTEM",
  "benchmark": "$BENCHMARK_NAME",
  "task": "$task",
  "task_abs": "$task_abs",
  "repeat": $rep,
  "experiment": "$EXPERIMENT",
  "generation_exit": $generation_exit,
  "eval_exit": $eval_exit,
  "generation_wall_s": float("$generation_wall"),
  "eval_wall_s": float("$eval_wall"),
  "task_wall_s": float("$total_wall"),
  "start_epoch": float("$start_epoch"),
  "end_epoch": float("$end_epoch"),
  "log_path": "$log_path"
}, indent=2))
PY

    echo "\"$task\",$rep,$generation_exit,$eval_exit,\"$log_path\",$start_epoch,$end_epoch,$total_wall,\"$CONTEXT_KEY\"" \
      >> "$STATUS_CSV"

    echo "Finished $task rep$rep (gen=$generation_exit eval=$eval_exit total=${total_wall}s)"

    if [ "$eval_exit" -ne 0 ] || [ "$generation_exit" -ne 0 ]; then
      grep -i \
        "traceback\|error\|failed\|timeout\|cuda out\|killed" \
        "$log_path" | tail -20 || true
    fi
  done
done < "${ROOT}/${TASK_LIST}"

echo "All tasks finished for system: $SYSTEM"
