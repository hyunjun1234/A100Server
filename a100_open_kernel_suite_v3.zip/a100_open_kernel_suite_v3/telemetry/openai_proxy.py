#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

import httpx
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse


def estimate_tokens(text: str) -> int:
    return max(0, round(len(text) / 4))


def prompt_text(payload: dict[str, Any]) -> str:
    if isinstance(payload.get("messages"), list):
        parts: list[str] = []
        for message in payload["messages"]:
            if isinstance(message, dict):
                content = message.get("content", "")
                parts.append(content if isinstance(content, str) else json.dumps(content, ensure_ascii=False))
        return "\n".join(parts)
    prompt = payload.get("prompt", "")
    return prompt if isinstance(prompt, str) else json.dumps(prompt, ensure_ascii=False)


class State:
    def __init__(self, backend: str, log_path: Path):
        self.backend = backend.rstrip("/")
        self.log_path = log_path
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.context: dict[str, Any] = {
            "context_key": "unscoped",
            "system": "unknown",
            "benchmark": "unknown",
            "task": "unknown",
            "repeat": 0,
        }
        self.context_lock = asyncio.Lock()
        self.write_lock = asyncio.Lock()
        self.call_counts: defaultdict[str, int] = defaultdict(int)

    async def set_context(self, data: dict[str, Any]) -> dict[str, Any]:
        async with self.context_lock:
            self.context = {**self.context, **data}
            key = str(self.context.get("context_key", "unscoped"))
            self.call_counts[key] = 0
            return dict(self.context)

    async def snapshot(self, request: Request) -> tuple[dict[str, Any], int]:
        async with self.context_lock:
            context = dict(self.context)
        header_context = request.headers.get("x-bench-context")
        if header_context:
            try:
                context.update(json.loads(header_context))
            except Exception:
                context["context_key"] = header_context
        key = str(context.get("context_key", "unscoped"))
        self.call_counts[key] += 1
        return context, self.call_counts[key]

    async def append(self, record: dict[str, Any]) -> None:
        line = json.dumps(record, ensure_ascii=False, sort_keys=True)
        async with self.write_lock:
            with self.log_path.open("a", encoding="utf-8") as file:
                file.write(line + "\n")


def build_app(state: State) -> FastAPI:
    app = FastAPI(title="Kernel LLM Telemetry Proxy")

    @app.get("/health")
    async def health() -> dict[str, Any]:
        backend_ok = False
        payload: Any = None
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(state.backend + "/health")
                backend_ok = response.status_code < 400
                try:
                    payload = response.json()
                except Exception:
                    payload = response.text[:500]
        except Exception as exc:
            payload = repr(exc)
        return {
            "status": "ok",
            "proxy": True,
            "backend": state.backend,
            "backend_ok": backend_ok,
            "backend_payload": payload,
            "context": state.context,
        }

    @app.post("/telemetry/context")
    async def set_context(request: Request) -> dict[str, Any]:
        return {"status": "ok", "context": await state.set_context(await request.json())}

    @app.get("/telemetry/context")
    async def get_context() -> dict[str, Any]:
        return {"status": "ok", "context": state.context}

    async def proxy_post(request: Request, route: str):
        payload = await request.json()
        context, call_index = await state.snapshot(request)
        prompt = prompt_text(payload)
        start_epoch = time.time()
        start_mono = time.monotonic()
        model = payload.get("model", "")
        stream = bool(payload.get("stream", False))
        backend_url = state.backend + route
        headers = {
            key: value
            for key, value in request.headers.items()
            if key.lower() not in {"host", "content-length", "connection"}
        }

        if stream:
            async def iterator():
                chunks: list[bytes] = []
                status_code = 500
                error = None
                try:
                    async with httpx.AsyncClient(timeout=None) as client:
                        async with client.stream("POST", backend_url, json=payload, headers=headers) as response:
                            status_code = response.status_code
                            async for chunk in response.aiter_bytes():
                                chunks.append(chunk)
                                yield chunk
                except Exception as exc:
                    error = repr(exc)
                    yield json.dumps({"error": error}).encode()
                finally:
                    body = b"".join(chunks).decode(errors="ignore")
                    await state.append({
                        **context,
                        "call_index": call_index,
                        "route": route,
                        "model": model,
                        "stream": True,
                        "started_epoch": start_epoch,
                        "ended_epoch": time.time(),
                        "latency_s": time.monotonic() - start_mono,
                        "status_code": status_code,
                        "prompt_chars": len(prompt),
                        "prompt_tokens_est": estimate_tokens(prompt),
                        "response_chars": len(body),
                        "completion_tokens_est": estimate_tokens(body),
                        "error": error,
                    })
            return StreamingResponse(iterator(), media_type="text/event-stream")

        status_code = 500
        raw = b""
        error = None
        response_headers: dict[str, str] = {}
        try:
            async with httpx.AsyncClient(timeout=None) as client:
                response = await client.post(backend_url, json=payload, headers=headers)
                status_code = response.status_code
                raw = response.content
                response_headers = {
                    key: value
                    for key, value in response.headers.items()
                    if key.lower() not in {"content-length", "transfer-encoding", "connection"}
                }
        except Exception as exc:
            error = repr(exc)
            raw = json.dumps({"error": error}).encode()

        response_text = raw.decode(errors="ignore")
        usage: dict[str, Any] = {}
        finish_reason = None
        try:
            obj = json.loads(response_text)
            usage = obj.get("usage") or {}
            choices = obj.get("choices") or []
            if choices:
                finish_reason = choices[0].get("finish_reason")
        except Exception:
            pass

        await state.append({
            **context,
            "call_index": call_index,
            "route": route,
            "model": model,
            "stream": False,
            "started_epoch": start_epoch,
            "ended_epoch": time.time(),
            "latency_s": time.monotonic() - start_mono,
            "status_code": status_code,
            "prompt_chars": len(prompt),
            "prompt_tokens_reported": usage.get("prompt_tokens"),
            "completion_tokens_reported": usage.get("completion_tokens"),
            "total_tokens_reported": usage.get("total_tokens"),
            "prompt_tokens_est": estimate_tokens(prompt),
            "response_chars": len(response_text),
            "completion_tokens_est": estimate_tokens(response_text),
            "finish_reason": finish_reason,
            "error": error,
        })
        return Response(content=raw, status_code=status_code, headers=response_headers, media_type="application/json")

    @app.post("/v1/chat/completions")
    async def chat(request: Request):
        return await proxy_post(request, "/v1/chat/completions")

    @app.post("/v1/completions")
    async def completions(request: Request):
        return await proxy_post(request, "/v1/completions")

    @app.get("/v1/models")
    async def models():
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.get(state.backend + "/v1/models")
                return Response(response.content, status_code=response.status_code, media_type="application/json")
        except Exception as exc:
            return JSONResponse({"error": repr(exc)}, status_code=502)

    return app


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", default="http://127.0.0.1:8000")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8100)
    parser.add_argument("--log", default="results/telemetry/llm_calls.jsonl")
    args = parser.parse_args()
    uvicorn.run(build_app(State(args.backend, Path(args.log).resolve())), host=args.host, port=args.port)


if __name__ == "__main__":
    main()
