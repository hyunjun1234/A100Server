#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from pathlib import Path

import requests


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--system", required=True)
    parser.add_argument("--benchmark", required=True)
    parser.add_argument("--task", default="native_suite")
    parser.add_argument("--repeat", type=int, default=0)
    parser.add_argument("--command", required=True)
    parser.add_argument("--cwd", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--proxy-port", type=int, default=8100)
    parser.add_argument("--bench-gpus", default="0")
    parser.add_argument("--timeout", type=int, default=7200)
    args = parser.parse_args()

    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    context_key = (
        f"{args.system}|{args.benchmark}|{args.task}|"
        f"rep{args.repeat}|native"
    )

    try:
        requests.post(
            f"http://127.0.0.1:{args.proxy_port}/telemetry/context",
            json={
                "context_key": context_key,
                "system": args.system,
                "benchmark": args.benchmark,
                "task": args.task,
                "repeat": args.repeat,
            },
            timeout=10,
        ).raise_for_status()
    except Exception:
        # Native benchmark commands may not use an LLM at all.
        pass

    sampler = subprocess.Popen([
        os.environ.get("PYTHON", "python3"),
        str(Path(__file__).resolve().parent / "gpu_sampler.py"),
        "--output",
        str(output_dir / "gpu.csv"),
        "--gpus",
        args.bench_gpus,
        "--interval",
        os.environ.get("GPU_SAMPLE_INTERVAL", "0.5"),
    ])

    environment = os.environ.copy()
    environment["CUDA_VISIBLE_DEVICES"] = args.bench_gpus
    environment["OPENAI_BASE_URL"] = (
        f"http://127.0.0.1:{args.proxy_port}/v1"
    )
    environment["OPENAI_API_KEY"] = "EMPTY"

    start_epoch = time.time()
    start = time.perf_counter()
    exit_code = -1
    error = None

    try:
        process = subprocess.run(
            ["bash", "-lc", args.command],
            cwd=args.cwd,
            env=environment,
            timeout=args.timeout,
            capture_output=True,
            text=True,
        )
        exit_code = process.returncode
        (output_dir / "stdout.txt").write_text(
            process.stdout,
            errors="ignore",
        )
        (output_dir / "stderr.txt").write_text(
            process.stderr,
            errors="ignore",
        )
    except subprocess.TimeoutExpired as exc:
        exit_code = 124
        error = "timeout"
        (output_dir / "stdout.txt").write_text(
            (exc.stdout or "")
            if isinstance(exc.stdout, str)
            else (exc.stdout or b"").decode(errors="ignore")
        )
        (output_dir / "stderr.txt").write_text(
            (exc.stderr or "")
            if isinstance(exc.stderr, str)
            else (exc.stderr or b"").decode(errors="ignore")
        )
    finally:
        sampler.terminate()
        try:
            sampler.wait(timeout=10)
        except Exception:
            sampler.kill()

    record = {
        "context_key": context_key,
        "system": args.system,
        "benchmark": args.benchmark,
        "task": args.task,
        "repeat": args.repeat,
        "command": args.command,
        "cwd": str(Path(args.cwd).resolve()),
        "start_epoch": start_epoch,
        "end_epoch": time.time(),
        "wall_s": time.perf_counter() - start,
        "exit_code": exit_code,
        "error": error,
    }

    (output_dir / "native_result.json").write_text(
        json.dumps(record, indent=2),
        encoding="utf-8",
    )

    print(json.dumps(record, indent=2))
    raise SystemExit(0 if exit_code == 0 else exit_code)


if __name__ == "__main__":
    main()
