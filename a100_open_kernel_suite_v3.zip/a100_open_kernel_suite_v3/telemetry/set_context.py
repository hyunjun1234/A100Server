#!/usr/bin/env python3
import argparse
import json
import requests

parser = argparse.ArgumentParser()
parser.add_argument("--url", default="http://127.0.0.1:8100/telemetry/context")
parser.add_argument("--context-key", required=True)
parser.add_argument("--system", required=True)
parser.add_argument("--benchmark", required=True)
parser.add_argument("--task", required=True)
parser.add_argument("--repeat", type=int, default=0)
args = parser.parse_args()

response = requests.post(args.url, json={
    "context_key": args.context_key,
    "system": args.system,
    "benchmark": args.benchmark,
    "task": args.task,
    "repeat": args.repeat,
}, timeout=10)
response.raise_for_status()
print(json.dumps(response.json(), ensure_ascii=False))
